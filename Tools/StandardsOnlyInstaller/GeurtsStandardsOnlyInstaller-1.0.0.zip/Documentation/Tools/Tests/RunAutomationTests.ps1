# RunAutomationTests.ps1
# Version: 0.61.1

[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [ValidateSet("Text", "Json")]
    [string]$OutputFormat = "Text"
)

$ErrorActionPreference = "Stop"
$script:Passed = 0
$script:Failed = 0
$script:FailureMessages = New-Object System.Collections.Generic.List[string]
$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

function Assert-True([bool]$Condition, [string]$Name) {
    if ($Condition) {
        $script:Passed++
        if ($OutputFormat -eq "Text") { Write-Host "PASS: $Name" -ForegroundColor Green }
    }
    else {
        $script:Failed++
        $script:FailureMessages.Add($Name) | Out-Null
        if ($OutputFormat -eq "Text") { Write-Host "FAIL: $Name" -ForegroundColor Red }
    }
}

function Write-Utf8([string]$Path, [string]$Text) {
    $directory = Split-Path -Parent $Path
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) { New-Item -ItemType Directory -Path $directory -Force | Out-Null }
    [System.IO.File]::WriteAllText($Path, $Text, $utf8NoBom)
}

function Get-FileSha([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return $null }
    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()
}

function Test-BytePrefix([byte[]]$Bytes, [byte[]]$Expected) {
    if ($Bytes.Length -lt $Expected.Length) { return $false }
    for ($index = 0; $index -lt $Expected.Length; $index++) {
        if ($Bytes[$index] -ne $Expected[$index]) { return $false }
    }
    return $true
}

function Test-ByteSuffix([byte[]]$Bytes, [byte[]]$Expected) {
    if ($Bytes.Length -lt $Expected.Length) { return $false }
    $offset = $Bytes.Length - $Expected.Length
    for ($index = 0; $index -lt $Expected.Length; $index++) {
        if ($Bytes[$offset + $index] -ne $Expected[$index]) { return $false }
    }
    return $true
}

function Test-CrLfOnly([string]$Text) {
    if (-not $Text.Contains("`r`n")) { return $false }
    $withoutCrLf = $Text.Replace("`r`n", "")
    return -not $withoutCrLf.Contains("`r") -and -not $withoutCrLf.Contains("`n")
}

function Get-GitIgnorePayloadInfo([string]$Path) {
    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) { return [pscustomobject]@{ Valid = $false } }
    $text = [System.IO.File]::ReadAllText($Path)
    $pattern = '(?ms)^<!-- GEURTS-GITIGNORE-BEGIN version="(?<Version>[0-9]+\.[0-9]+\.[0-9]+)" target="(?<Target>[^"]+)" sha256="(?<Hash>[0-9a-f]{64})" -->\r?\n```gitignore\r?\n(?<Payload>.*?)^```\r?\n<!-- GEURTS-GITIGNORE-END -->(?:\r?\n)?\z'
    $matches = @([regex]::Matches($text, $pattern))
    if ($matches.Count -ne 1 -or [regex]::Matches($text, 'GEURTS-GITIGNORE-BEGIN').Count -ne 1 -or [regex]::Matches($text, 'GEURTS-GITIGNORE-END').Count -ne 1) { return [pscustomobject]@{ Valid = $false } }
    $match = $matches[0]
    $payload = $match.Groups["Payload"].Value -replace "`r`n", "`n" -replace "`r", "`n"
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { $actualHash = ([System.BitConverter]::ToString($sha.ComputeHash($utf8NoBom.GetBytes($payload)))).Replace("-", "").ToLowerInvariant() }
    finally { $sha.Dispose() }
    return [pscustomobject]@{
        Valid = ($match.Groups["Version"].Value -ceq "1.0.1" -and $match.Groups["Target"].Value -ceq ".gitignore" -and $match.Groups["Hash"].Value -ceq $actualHash -and $actualHash -ceq "4d9408d141d128225e02615c7e72031d53153f5dfcc9427305a6c651689008d4" -and [regex]::Matches($payload, "`n").Count -eq 404 -and $payload.EndsWith("`n") -and -not $payload.EndsWith("`n`n"))
        Hash = $actualHash
        LineCount = [regex]::Matches($payload, "`n").Count
        EndsWithOneLf = ($payload.EndsWith("`n") -and -not $payload.EndsWith("`n`n"))
    }
}

function Invoke-TestScript([string]$Path, [string[]]$Arguments) {
    $hostPath = (Get-Process -Id $PID).Path
    $hostArguments = @("-NoProfile")
    if ((Split-Path -Leaf $hostPath) -like "powershell*") { $hostArguments += @("-ExecutionPolicy", "Bypass") }
    $hostArguments += @("-File", $Path)
    $hostArguments += $Arguments
    $output = @(& $hostPath @hostArguments 2>&1)
    return [pscustomobject]@{ Code = $LASTEXITCODE; Output = ($output -join [Environment]::NewLine) }
}

function Start-TestScriptAtBarrier([string]$Path, [string[]]$Arguments, [string]$BarrierPath, [string]$TargetPath) {
    foreach ($suffix in @(".ready", ".continue", ".stdout", ".stderr")) { Remove-Item -LiteralPath ($BarrierPath + $suffix) -Force -ErrorAction SilentlyContinue }
    $hostPath = (Get-Process -Id $PID).Path
    $hostArguments = @("-NoProfile")
    if ((Split-Path -Leaf $hostPath) -like "powershell*") { $hostArguments += @("-ExecutionPolicy", "Bypass") }
    $hostArguments += @("-File", $Path)
    $hostArguments += $Arguments
    $quotedArguments = @($hostArguments | ForEach-Object { '"' + ([string]$_).Replace('"', '\"') + '"' })
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $hostPath
    $startInfo.Arguments = $quotedArguments -join " "
    $startInfo.UseShellExecute = $false
    $startInfo.CreateNoWindow = $true
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $startInfo.EnvironmentVariables["GEURTS_TEST_WRITE_BARRIER_PATH"] = [System.IO.Path]::GetFullPath($BarrierPath)
    $startInfo.EnvironmentVariables["GEURTS_TEST_WRITE_BARRIER_TARGET"] = [System.IO.Path]::GetFullPath($TargetPath)
    $process = New-Object System.Diagnostics.Process
    $process.StartInfo = $startInfo
    if (-not $process.Start()) { throw "Unable to start barrier test process." }
    return [pscustomobject]@{ Process = $process; Barrier = [System.IO.Path]::GetFullPath($BarrierPath); Target = [System.IO.Path]::GetFullPath($TargetPath); Disposed = $false }
}

function Close-TestScriptBarrierProcess($Run) {
    if ($null -eq $Run -or $Run.Disposed) { return }
    try {
        if ($null -ne $Run.Process) { $Run.Process.Dispose() }
    }
    finally { $Run.Disposed = $true }
}

function Stop-TestScriptBarrier($Run) {
    if ($null -eq $Run -or $Run.Disposed -or $null -eq $Run.Process) { return }
    try {
        if (-not $Run.Process.HasExited) {
            [System.IO.File]::WriteAllText(($Run.Barrier + ".continue"), "continue", $utf8NoBom)
            $Run.Process.WaitForExit()
        }
    }
    catch {
        # Cleanup is best-effort and must not replace the primary test failure.
    }
    finally {
        try { Close-TestScriptBarrierProcess -Run $Run }
        catch { }
    }
}

function Restore-TestDirectorySwap([string]$Path, [string]$ExpectedTarget, [string]$SavedPath) {
    try {
        if (Test-Path -LiteralPath $Path) {
            $item = Get-Item -LiteralPath $Path -Force
            if (($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -ne 0) {
                Remove-TestJunction -Path $Path -ExpectedTarget $ExpectedTarget
            }
            elseif (Test-Path -LiteralPath $SavedPath -PathType Container) {
                throw "Refused to restore a directory swap over a non-junction path: $Path"
            }
        }
        if (Test-Path -LiteralPath $SavedPath -PathType Container) {
            if (Test-Path -LiteralPath $Path) { throw "Refused to restore a saved directory over an existing path: $Path" }
            Move-Item -LiteralPath $SavedPath -Destination $Path
        }
    }
    catch {
        $script:Failed++
        $script:FailureMessages.Add("Barrier directory cleanup failed for '$Path': $($_.Exception.Message)") | Out-Null
        if ($OutputFormat -eq "Text") { Write-Host "BARRIER CLEANUP ERROR: $($_.Exception.Message)" -ForegroundColor Red }
    }
}

function Wait-TestScriptBarrier($Run) {
    $readyPath = $Run.Barrier + ".ready"
    $deadline = [DateTime]::UtcNow.AddSeconds(20)
    while (-not (Test-Path -LiteralPath $readyPath -PathType Leaf)) {
        if ($Run.Process.HasExited) {
            $output = $Run.Process.StandardOutput.ReadToEnd() + $Run.Process.StandardError.ReadToEnd()
            $code = $Run.Process.ExitCode
            Close-TestScriptBarrierProcess -Run $Run
            throw "Barrier test process exited before its write boundary (code $code): $output"
        }
        if ([DateTime]::UtcNow -ge $deadline) { throw "Timed out waiting for the deterministic write barrier." }
        Start-Sleep -Milliseconds 20
    }
}

function Complete-TestScriptBarrier($Run) {
    if ($null -eq $Run -or $Run.Disposed -or $null -eq $Run.Process) { throw "Barrier test process is no longer available for completion." }
    try {
        [System.IO.File]::WriteAllText(($Run.Barrier + ".continue"), "continue", $utf8NoBom)
        $stdout = $Run.Process.StandardOutput.ReadToEnd()
        $stderr = $Run.Process.StandardError.ReadToEnd()
        $Run.Process.WaitForExit()
        $code = $Run.Process.ExitCode
        return [pscustomobject]@{ Code = $code; Output = (($stdout + $stderr).TrimEnd()) }
    }
    finally { Close-TestScriptBarrierProcess -Run $Run }
}

function Get-HistoricalFile([string]$Specification) {
    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = "git"
    $startInfo.Arguments = "show $Specification"
    $startInfo.WorkingDirectory = $RepositoryRoot
    $startInfo.UseShellExecute = $false
    $startInfo.RedirectStandardOutput = $true
    $startInfo.RedirectStandardError = $true
    $process = [System.Diagnostics.Process]::Start($startInfo)
    $stdout = $process.StandardOutput.ReadToEnd()
    $stderr = $process.StandardError.ReadToEnd()
    $process.WaitForExit()
    if ($process.ExitCode -ne 0) { throw "Unable to load historical fixture $Specification. $stderr" }
    return $stdout
}

function New-TestProject([string]$Parent, [string]$Name) {
    $path = Join-Path $Parent $Name
    New-Item -ItemType Directory -Path $path | Out-Null
    foreach ($marker in @("Assets", "Packages", "ProjectSettings")) { New-Item -ItemType Directory -Path (Join-Path $path $marker) | Out-Null }
    return $path
}

function New-StaticValidationFixture([string]$Parent, [string]$Name) {
    $path = Join-Path $Parent $Name
    New-Item -ItemType Directory -Path $path | Out-Null
    foreach ($entryName in @("AI_READ_FIRST.md", "GeurtsTechniqueManifest.md", "GeurtsTechniques", "History", "Ideas", "Migrations", "README.md", "Tools")) {
        Copy-Item -LiteralPath (Join-Path $RepositoryRoot $entryName) -Destination $path -Recurse -Force
    }
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $initOutput = @(& git -C $path init --quiet 2>&1)
        $initExitCode = $LASTEXITCODE
        $addOutput = @(& git -C $path add --all 2>&1)
        $addExitCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    if ($initExitCode -ne 0) { throw "Unable to initialize a static-validation fixture repository: $path. $($initOutput -join ' ')" }
    if ($addExitCode -ne 0) { throw "Unable to stage the static-validation fixture inventory: $path. $($addOutput -join ' ')" }
    return $path
}

function Remove-TestJunction([string]$Path, [string]$ExpectedTarget) {
    if (-not (Test-Path -LiteralPath $Path)) { return }
    $item = Get-Item -LiteralPath $Path -Force
    if (-not $item.PSIsContainer -or ($item.Attributes -band [System.IO.FileAttributes]::ReparsePoint) -eq 0) {
        throw "Refused to remove a non-junction test path: $Path"
    }
    $declaredTargets = @($item.Target)
    if ($declaredTargets.Count -ne 1 -or [string]::IsNullOrWhiteSpace([string]$declaredTargets[0])) {
        throw "Refused to remove a test junction without one inspectable target: $Path"
    }
    $declaredTarget = [string]$declaredTargets[0]
    if (-not [System.IO.Path]::IsPathRooted($declaredTarget)) { $declaredTarget = Join-Path (Split-Path -Parent $Path) $declaredTarget }
    if (-not [System.IO.Path]::GetFullPath($declaredTarget).Equals([System.IO.Path]::GetFullPath($ExpectedTarget), [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "Refused to remove a test junction whose target differs from the expected disposable target: $Path"
    }
    [System.IO.Directory]::Delete([System.IO.Path]::GetFullPath($Path))
    if (Test-Path -LiteralPath $Path) { throw "Failed to remove disposable test junction: $Path" }
}

if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) { $RepositoryRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot) }
$RepositoryRoot = [System.IO.Path]::GetFullPath($RepositoryRoot)
$toolsRoot = Join-Path $RepositoryRoot "Tools"
$manageScript = Join-Path $toolsRoot "ManageGeurtsAgentInstructions.ps1"
$gddScript = Join-Path $toolsRoot "UpdateGameDesignManifest.ps1"
$folderScript = Join-Path $toolsRoot "CreateGeurtsFolderStructure.ps1"
$validatorScript = Join-Path $toolsRoot "ValidateGeurtsDocumentation.ps1"
$temporaryBase = [System.IO.Path]::GetFullPath([System.IO.Path]::GetTempPath())
$testRoot = Join-Path $temporaryBase ("ggf-automation-tests-" + [Guid]::NewGuid().ToString("N"))

try {
    New-Item -ItemType Directory -Path $testRoot | Out-Null
    $audienceResults = & (Join-Path $PSScriptRoot 'TestDocumentationAudiences.ps1') -RepositoryRoot $RepositoryRoot -OutputFormat Json | ConvertFrom-Json
    $script:Passed += $audienceResults.passed
    $script:Failed += $audienceResults.failed
    foreach ($audienceFailure in $audienceResults.failures) { $script:FailureMessages.Add("Audience: $audienceFailure") | Out-Null }

    $sourceResults = & (Join-Path $PSScriptRoot 'TestGeurtsBrickSources.ps1') -RepositoryRoot $RepositoryRoot -OutputFormat Json | ConvertFrom-Json
    $script:Passed += $sourceResults.passed
    $script:Failed += $sourceResults.failed
    foreach ($sourceFailure in $sourceResults.failures) { $script:FailureMessages.Add("Published sources: $sourceFailure") | Out-Null }

    # A standalone documentation/structure workflow must not need any Forge package.
    $standaloneProject = New-TestProject -Parent $testRoot -Name 'standards-only'
    $standaloneManifest = Join-Path $standaloneProject 'Packages/manifest.json'
    Write-Utf8 $standaloneManifest '{"dependencies":{}}'
    $standaloneManifestHash = Get-FileSha $standaloneManifest
    $standaloneReader = Invoke-TestScript -Path (Join-Path $toolsRoot 'ReadGeurtsDocumentation.ps1') -Arguments @('-RepositoryRoot', $RepositoryRoot, '-Document', 'GeurtsTechniques/GeurtsStandardsOnlyTechnique.md', '-Mode', 'GameUse', '-OutputFormat', 'Json')
    $standaloneReading = $standaloneReader.Output | ConvertFrom-Json
    Assert-True ($standaloneReader.Code -eq 0 -and $standaloneReading.skippedLines -eq 0 -and $standaloneReading.content.Contains('No Geurts Unity packages are required by StandardsOnly.')) 'StandardsOnly guidance is fully readable through the existing GameUse reader without Forge'
    $standaloneFolders = Invoke-TestScript -Path $folderScript -Arguments @('-ProjectRoot', $standaloneProject, '-DefinitionPath', (Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsFolderStructureDefinition.json'), '-OutputFormat', 'Json')
    $standaloneFolderReport = $standaloneFolders.Output | ConvertFrom-Json
    Assert-True ($standaloneFolders.Code -eq 0 -and @($standaloneFolderReport.results | Where-Object { $_.status -in @("Created", "Exists") }).Count -eq 76) 'Explicit full-profile folder setup succeeds in a project with no Forge dependencies'
    $standaloneRerun = Invoke-TestScript -Path $folderScript -Arguments @('-ProjectRoot', $standaloneProject, '-DefinitionPath', (Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsFolderStructureDefinition.json'), '-OutputFormat', 'Json')
    $standaloneRerunReport = $standaloneRerun.Output | ConvertFrom-Json
    Assert-True ($standaloneRerun.Code -eq 0 -and @($standaloneRerunReport.results | Where-Object status -eq "Created").Count -eq 0 -and (Get-FileSha $standaloneManifest) -ceq $standaloneManifestHash) 'Standalone folder setup is idempotent and preserves the empty package manifest'
    Assert-True (-not (Test-Path (Join-Path $standaloneProject 'GeurtsGameForgeCommandments')) -and -not (Test-Path (Join-Path $standaloneProject '.github')) -and -not (Test-Path (Join-Path $standaloneProject 'AGENTS.md'))) 'Reading standards and creating folders do not acquire documentation or install AI routes'

    $repositoryGitIgnorePath = Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsGitIgnoreTechnique.md"
    $repositoryGitIgnore = Get-GitIgnorePayloadInfo -Path $repositoryGitIgnorePath
    Assert-True ($repositoryGitIgnore.Valid -and $repositoryGitIgnore.LineCount -eq 404 -and $repositoryGitIgnore.EndsWithOneLf) "Approved custom .gitignore payload matches the normalized source"

    $attributesSource = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsGitAttributesTechnique.md'))
    $attributesMatch = [regex]::Match($attributesSource.Replace("`r`n", "`n"), '(?ms)^<!-- GEURTS-GITATTRIBUTES-BEGIN version="1\.0\.1" target="\.gitattributes" sha256="d051cf466ba5bffc055905a79ae76f93a60e27a3dbb8fcd16b968bb80c3e3d2d" -->\n```gitattributes\n(?<Payload>.*?)^```\n<!-- GEURTS-GITATTRIBUTES-END -->\n?\z')
    $expectedAttributes = "Assets/Plugins/FMOD/**/*.bundle text eol=lf`nAssets/Plugins/FMOD/**/Info.plist text eol=lf`n"
    Assert-True ($attributesMatch.Success -and $attributesMatch.Groups['Payload'].Value -ceq $expectedAttributes) 'FMOD template contains the exact approved two-line rule pair'
    $attributesFixture = Join-Path $testRoot 'FmodAttributes'
    [void][System.IO.Directory]::CreateDirectory($attributesFixture)
    & git -C $attributesFixture init --quiet
    if ($LASTEXITCODE -ne 0) { throw 'Cannot initialize the isolated Git attributes fixture.' }
    Write-Utf8 (Join-Path $attributesFixture '.gitattributes') ("* text=auto eol=crlf`r`n" + $attributesMatch.Groups['Payload'].Value.Replace("`n", "`r`n"))
    $attributesResult = @(& git -C $attributesFixture check-attr text eol -- Assets/Plugins/FMOD/platforms/mac/lib/fmod.bundle Assets/Plugins/FMOD/platforms/mac/lib/fmod.bundle/Contents/Info.plist Assets/_Project/Scripts/Example.cs Assets/Plugins/Other.bundle)
    Assert-True ($LASTEXITCODE -eq 0 -and ($attributesResult -join "`n").Contains('Assets/Plugins/FMOD/platforms/mac/lib/fmod.bundle: text: set') -and
        ($attributesResult -join "`n").Contains('Assets/Plugins/FMOD/platforms/mac/lib/fmod.bundle: eol: lf') -and
        ($attributesResult -join "`n").Contains('Assets/Plugins/FMOD/platforms/mac/lib/fmod.bundle/Contents/Info.plist: eol: lf')) 'Real Git applies LF to both FMOD file patterns after the Windows default'
    Assert-True (($attributesResult -join "`n").Contains('Assets/_Project/Scripts/Example.cs: eol: crlf') -and
        ($attributesResult -join "`n").Contains('Assets/Plugins/Other.bundle: eol: crlf')) 'FMOD exceptions retain the Windows default for unrelated paths'

    $draftManifestText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniqueManifest.md"))
    $draftReadmeText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "README.md"))
    $targetMigrationText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Migrations/v0.47.0.md"))
    Assert-True ($draftManifestText -match '(?im)^\*\*Version:\*\*\s*0\.61\.1\s*$' -and $draftManifestText -match '(?im)^\*\*Status:\*\*\s*Draft normative package manifest\s*$' -and $draftReadmeText -match '(?im)^\*\*Status:\*\*\s*Draft technique package\s*$' -and $targetMigrationText -match '(?i)planned transition' -and $targetMigrationText -match '(?i)target-release snapshot' -and $targetMigrationText -notmatch '(?i)(?:v0\.46\.0|package v0\.46\.0)[^\r\n]{0,80}(?:is|was|has been) released') "v0.61.1 remains a Draft target release with a planned snapshot rather than a completed-release claim"

    $gfiContractText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"))
    Assert-True ($gfiContractText -match '(?i)sole primary source and authority for all Geurts Game Forge documentation' -and $gfiContractText.Contains("<PluginPackageRoot>/Documentation~/") -and $gfiContractText -match '(?i)must not ship a bundled or fallback copy of Geurts documentation') "Frozen GFI v2 keeps this repository authoritative and plugin Documentation~ plugin-specific"
    Assert-True ($gfiContractText -match '(?i)exactly one lightweight remote metadata check' -and $gfiContractText -match '(?i)Update availability is determined only by commit identity' -and $gfiContractText -match '(?i)commit IDs are identical, do not report an Update' -and $gfiContractText -match '(?i)Package-version ordering or inequality is display-only and must not determine availability' -and $gfiContractText -match '(?i)startup comparison result is unknown' -and $gfiContractText -match '(?i)must not download documentation[^\r\n]{0,200}inspect or hash the project-local copy' -and $gfiContractText -match '(?i)performs no additional remote documentation check' -and $gfiContractText -match '(?i)Local edits[^\r\n]{0,100}do not affect update availability') "Frozen GFI v2 retains its one commit-identity-only notification check without local inspection or lifecycle work"
    Assert-True ($gfiContractText.Contains("Installed Geurts Documentation: <version | Not installed | Unknown>") -and $gfiContractText.Contains("GameForgeIntelligence Plugin: <version | Unknown>") -and $gfiContractText.Contains("Available Geurts Documentation: <version>") -and $gfiContractText -match '(?i)Never derive[^\r\n]{0,180}mutable project-local documentation files' -and $gfiContractText -match '(?i)distinct values. Never display one as another') "Frozen GFI v2 keeps documentation, available, plugin, technique, and schema versions separately labelled"
    Assert-True ($gfiContractText -match '(?i)Every successful Update receipt records the authoritative selected commit ID' -and $gfiContractText -match '(?i)Immediately before the first destructive mutation[^\r\n]{0,160}invalidate or clear the current installed receipt' -and $gfiContractText -match '(?i)historical receipt is diagnostic history only and must never drive' -and $gfiContractText -match '(?i)report success only after that receipt is written' -and $gfiContractText -match '(?i)Failure or interruption after receipt invalidation must leave the current receipt absent or invalid' -and $gfiContractText -match '(?is)destination directory is absent.{0,140}`Not installed`.{0,220}directory exists.{0,180}`Unknown`') "Frozen GFI v2 retains its destructive receipt transition and post-success selected-commit receipt"
    Assert-True ($gfiContractText -match '(?i)safe default is Cancel' -and $gfiContractText -match '(?i)Every local edit anywhere inside GeurtsGameForgeDocumentation will be overwritten and lost' -and $gfiContractText -match '(?i)no rollback' -and $gfiContractText -match '(?i)missing or incomplete') "Frozen GFI v2 retains its cancel-default destructive warning"
    Assert-True ($gfiContractText -match '(?i)complete Git-tracked source tree' -and $gfiContractText -match '(?i)detached, writable content snapshot' -and $gfiContractText -match '(?i)no `\.git` directory or file' -and $gfiContractText -match '(?i)read-only file or directory attributes must be cleared' -and $gfiContractText -match '(?i)residue must never block a later') "Frozen GFI v2 retains its detached complete-tree snapshot contract"
    Assert-True ($gfiContractText -match '(?i)only project path this documentation Update may delete or replace' -and $gfiContractText -match '(?i)Every file and byte there[^\r\n]{0,160}must remain untouched' -and $gfiContractText -match '(?i)must not invoke native-entry setup') "Frozen GFI v2 retains its historical documentation-only boundary and leaves GDD and generic-tool subjects untouched"
    Assert-True ($gfiContractText -match '(?i)must not create or require an automatic documentation downloader or installer' -and $gfiContractText -match '(?i)Do not recreate any of those mechanisms under different terminology' -and $gfiContractText -match '(?i)legacy evidence[^\r\n]{0,60}untouched' -and $gfiContractText -match '(?i)must not consult it, depend on it, or allow it to block') "Frozen GFI v2 keeps discarded transaction/recovery machinery forbidden and legacy Library evidence non-blocking"

    $companionTechniqueText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"))
    $companionContract = Get-Content -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json") -Raw | ConvertFrom-Json
    $expectedCompanionValidationEntries = @(
        "AI_READ_FIRST.md",
        "GeurtsTechniqueManifest.md",
        "GeurtsTechniques/GeurtsStandardsOnlyTechnique.md",
        "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md",
        "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json",
        "Tools/AIAgentInstructionTemplates/copilot-instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md",
        "GeurtsTechniques/GeurtsAgentTechnique.md",
        "GeurtsTechniques/GeurtsEditorUIThemeTechnique.md",
        "GeurtsTechniques/GeurtsNamingTechnique.md",
        "GeurtsTechniques/GeurtsEditorAppearanceTechnique.md",
        "GeurtsTechniques/GeurtsForgeSetupTechnique.md",
        "GeurtsTechniques/GeurtsForgeSetupContract.json",
        "GeurtsTechniques/GeurtsSteamIntegrationTechnique.md"
    )
    $expectedCompanionRoutes = @(
        "Tools/AIAgentInstructionTemplates/copilot-instructions.md|.github/copilot-instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md|.github/instructions/geurts-unity.instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md|.github/instructions/geurts-game-design.instructions.md"
    )
    $actualCompanionRoutes = @($companionContract.routeMappings | ForEach-Object { "{0}|{1}" -f [string]$_.template, [string]$_.target })
    $actualConfirmationTargets = @($companionContract.updateUi.confirmationTargets | ForEach-Object { "{0}|{1}" -f [string]$_.path, [string]$_.effect })
    $expectedConfirmationTargets = @(
        "GeurtsGameForgeCommandments|replace-complete-directory",
        ".github/copilot-instructions.md|replace-complete-file",
        ".github/instructions/geurts-unity.instructions.md|replace-complete-file",
        ".github/instructions/geurts-game-design.instructions.md|replace-complete-file"
    )
    Assert-True ([string]$companionContract.schemaVersion -ceq "3.0.0" -and [string]$companionContract.packageVersion -ceq "0.61.1" -and [string]$companionContract.source.repository -ceq "https://github.com/Geurtsy/GeurtsGameForge_Commandments.git" -and [string]$companionContract.source.branch -ceq "main" -and [string]$companionContract.source.selection -ceq "exact-resolved-head-commit-archive") "Companion contract identifies schema 3.0.0, package v0.61.1, and the official exact-main-commit archive source"
    Assert-True ([string]$companionContract.destination.projectRelativePath -ceq "GeurtsGameForgeCommandments" -and [string]$companionContract.destination.replacement -ceq "complete-directory" -and [string]$companionContract.destination.access -ceq "logically-read-only") "Companion contract names the one logically-read-only complete documentation destination"
    Assert-True ((@($companionContract.validationEntries) -join "|") -ceq ($expectedCompanionValidationEntries -join "|") -and @($companionContract.validationEntries | Select-Object -Unique).Count -eq 15) "Current companion contract names the exact fifteen unique package-v0.61.1 source-validation entries"
    Assert-True (($actualCompanionRoutes -join "|") -ceq ($expectedCompanionRoutes -join "|") -and ($actualConfirmationTargets -join "|") -ceq ($expectedConfirmationTargets -join "|") -and [string]$companionContract.updateUi.actionLabel -ceq "Update Geurts Game Forge Commandments" -and [string]$companionContract.updateUi.confirmationDefault -ceq "cancel" -and [string]$companionContract.updateUi.cancelResult -ceq "no-network-or-filesystem-change") "Companion contract fixes three template routes and one cancel-default four-target Update confirmation"
    Assert-True ($companionTechniqueText -match '(?i)one confirmation dialog' -and $companionTechniqueText -match '(?i)no earlier preview, dry run[^\r\n]{0,100}second confirmation' -and $companionTechniqueText -match '(?i)confirmation occurs before archive acquisition' -and $companionTechniqueText -match '(?i)earlier approval does not authorize a changed or expanded managed target set') "Confirmation uses the built-in schema-3.0.0 target set before acquisition and cannot authorize a changed downloaded target set"
    Assert-True ($companionTechniqueText -match '(?i)`packageVersion` is source-release metadata, not a companion compatibility gate' -and $companionTechniqueText -match '(?i)later package version alone must not require a companion release' -and $companionTechniqueText -match '(?i)schema-3\.0\.0 consumer may read a later list rather than pinning v0\.11\.0' -and $companionTechniqueText -match '(?i)every entry must be unique, safe, readable, and archive-root-relative') "Schema 3.0.0 keeps package versions and safe validation entries forward-compatible while mutation routes remain fixed"
    Assert-True ($companionTechniqueText -match '(?i)must not enumerate, inspect, create, validate, hash, modify, or delete anything under' -and $companionTechniqueText.Contains("<ProjectRoot>/Docs/GameDesign/") -and $companionTechniqueText -match '(?i)scan for or execute `\.bat`, `\.cmd`, `\.ps1`' -and $companionTechniqueText -match '(?i)copied as inert content') "Companion never inspects Docs/GameDesign, scans for setup work, or executes documentation/project scripts"
    Assert-True ($companionTechniqueText -match '(?i)must not check remote metadata' -and $companionTechniqueText -match '(?i)last-successful-installed commit value for this Unity project' -and $companionTechniqueText -match '(?i)value for one project must never suppress availability in another') "Companion startup stays offline and explicit checks keep external state isolated per Unity project"
    Assert-True ($companionTechniqueText -match '(?i)reports failure plainly and never reports partial completion as success' -and $companionTechniqueText -match '(?i)After every managed-target verification passes, report the content Update as successful and attempt to write' -and $companionTechniqueText -match '(?i)comparison-state write fails, report a warning[^\r\n]{0,160}do not reclassify, undo, or repair the successful four-target replacement' -and $companionTechniqueText -match '(?i)no automatic repair or recovery flow') "Companion reports content success after all four targets and treats later comparison-state persistence failure as a non-destructive warning"
    Assert-True ($companionTechniqueText -match '(?i)AI tool must support the applicable native instruction file or be explicitly instructed to read and follow `AI_READ_FIRST\.md`' -and $companionTechniqueText -match '(?i)must not claim universal AI control or compliance') "Companion states the native AI-routing support limitation without claiming universal control"

    $expectedProjectRouteText = 'Before any Geurts Game Forge project work, read and follow `GeurtsGameForgeCommandments/AI_READ_FIRST.md`; it routes to the installed, manifest-selected documentation. Treat that documentation as the source of truth for the work.'
    $nativeTemplateExpectations = @(
        @{ Path = "Tools/AIAgentInstructionTemplates/copilot-instructions.md"; Markers = @('id="copilot-body" version="1.3.0" sha256="92e4a7ae1ff00f20480b217108a028bce40276a97d4caa3b614588fdf75874bc"') },
        @{ Path = "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md"; Markers = @('id="unity-frontmatter" version="1.3.0" sha256="98e4fd786bbd1474e28d3800b91d749c29ff2acf94b89ef821d6860645829688"', 'id="unity-body" version="1.3.0" sha256="206ef83ff9c5aa0ba24b363a8c6a5735793cb697435dbeb2dce90b8a117bef91"') },
        @{ Path = "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"; Markers = @('id="game-design-frontmatter" version="1.3.0" sha256="334b60274fe81a1891e1500785d29a249a0d4e32957bb665a770402163fa2cd4"', 'id="game-design-body" version="1.3.0" sha256="069e94f46d2860a040a8f9bbd5aa7a21e5bc888a38990c5e7d74a6b79d4982e4"') }
    )
    foreach ($templateExpectation in $nativeTemplateExpectations) {
        $templateText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $templateExpectation.Path))
        $missingMarkers = @($templateExpectation.Markers | Where-Object { -not $templateText.Contains([string]$_) })
        Assert-True ([regex]::Matches($templateText, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and $missingMarkers.Count -eq 0 -and -not $templateText.Contains('version="0.9.0"')) "$($templateExpectation.Path) has the exact v1.3.0 project-wide route and approved managed-region hashes"
    }

    # Project-mutating tools copied inside the documentation container must never infer that container as a Unity root.
    $rootSafetyProject = New-TestProject -Parent $testRoot -Name "explicit-root-safety"
    $copiedDocumentationRoot = Join-Path $rootSafetyProject "GeurtsGameForgeCommandments"
    $copiedToolsRoot = Join-Path $copiedDocumentationRoot "Tools"
    New-Item -ItemType Directory -Path $copiedToolsRoot -Force | Out-Null
    foreach ($marker in @("Assets", "Packages", "ProjectSettings")) { New-Item -ItemType Directory -Path (Join-Path $copiedDocumentationRoot $marker) | Out-Null }
    foreach ($toolName in @("ManageGeurtsAgentInstructions.ps1", "CreateGeurtsFolderStructure.ps1", "UpdateGameDesignManifest.ps1")) {
        Copy-Item -LiteralPath (Join-Path $toolsRoot $toolName) -Destination (Join-Path $copiedToolsRoot $toolName)
    }
    $omittedRootRuns = @(
        (Invoke-TestScript -Path (Join-Path $copiedToolsRoot "ManageGeurtsAgentInstructions.ps1") -Arguments @()),
        (Invoke-TestScript -Path (Join-Path $copiedToolsRoot "CreateGeurtsFolderStructure.ps1") -Arguments @()),
        (Invoke-TestScript -Path (Join-Path $copiedToolsRoot "UpdateGameDesignManifest.ps1") -Arguments @())
    )
    $containerRootRuns = @(
        (Invoke-TestScript -Path (Join-Path $copiedToolsRoot "ManageGeurtsAgentInstructions.ps1") -Arguments @("-ProjectRoot", $copiedDocumentationRoot)),
        (Invoke-TestScript -Path (Join-Path $copiedToolsRoot "CreateGeurtsFolderStructure.ps1") -Arguments @("-ProjectRoot", $copiedDocumentationRoot)),
        (Invoke-TestScript -Path (Join-Path $copiedToolsRoot "UpdateGameDesignManifest.ps1") -Arguments @("-ProjectRoot", $copiedDocumentationRoot))
    )
    $unsafeNestedWrites = @("Docs", "GeurtsGameForgeCommandments", ".github", "Assets/_Project") | Where-Object { Test-Path -LiteralPath (Join-Path $copiedDocumentationRoot $_) }
    $markerChildren = @(@("Assets", "Packages", "ProjectSettings") | ForEach-Object { Get-ChildItem -LiteralPath (Join-Path $copiedDocumentationRoot $_) -Force })
    Assert-True (@($omittedRootRuns | Where-Object { $_.Code -eq 0 -or $_.Output -notmatch '(?i)ProjectRoot is required' }).Count -eq 0 -and @($containerRootRuns | Where-Object { $_.Code -eq 0 -or $_.Output -notmatch '(?i)documentation source or project-local fetched documentation copy' }).Count -eq 0 -and @($unsafeNestedWrites).Count -eq 0 -and $markerChildren.Count -eq 0) "Copied project-mutating tools reject the project-local fetched documentation copy even with fake Unity markers and never create nested project or native-entry content"

    $junctionRootTarget = New-TestProject -Parent $testRoot -Name "junction-unity-target"
    $junctionRootPath = Join-Path $testRoot "junction-unity-root"
    New-Item -ItemType Junction -Path $junctionRootPath -Target $junctionRootTarget | Out-Null
    try { $junctionRootRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $junctionRootPath, "-DefinitionPath", (Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureDefinition.json")) }
    finally { Remove-TestJunction -Path $junctionRootPath -ExpectedTarget $junctionRootTarget }
    Assert-True ($junctionRootRun.Code -ne 0 -and $junctionRootRun.Output -match '(?i)project root.*reparse point' -and -not (Test-Path -LiteralPath (Join-Path $junctionRootTarget "Assets/_Project"))) "Folder creation rejects a Unity project root that is itself a junction before any managed directory mutation"

    $managerDirectorySwapProject = New-TestProject -Parent $testRoot -Name "manager-directory-parent-swap"
    $managerDirectorySwapTarget = Join-Path $managerDirectorySwapProject ".github/instructions"
    $managerDirectorySwapBarrier = Join-Path $testRoot "barrier-manager-directory-swap"
    $managerDirectorySwapProcess = Start-TestScriptAtBarrier -Path $manageScript -Arguments @("-ProjectRoot", $managerDirectorySwapProject) -BarrierPath $managerDirectorySwapBarrier -TargetPath $managerDirectorySwapTarget
    $managerDirectorySwapGitHub = Join-Path $managerDirectorySwapProject ".github"
    $managerDirectorySwapSaved = Join-Path $managerDirectorySwapProject ".github-before-swap"
    $managerDirectorySwapOutside = Join-Path $testRoot "manager-directory-swap-outside"
    $managerDirectorySwapSentinel = Join-Path $managerDirectorySwapOutside "user-sentinel.txt"
    $managerDirectorySwapRun = $null
    try {
        Wait-TestScriptBarrier -Run $managerDirectorySwapProcess
        New-Item -ItemType Directory -Path $managerDirectorySwapOutside | Out-Null
        Write-Utf8 -Path $managerDirectorySwapSentinel -Text "Outside directory content must remain untouched.`n"
        $managerDirectorySwapSentinelHash = Get-FileSha -Path $managerDirectorySwapSentinel
        Move-Item -LiteralPath $managerDirectorySwapGitHub -Destination $managerDirectorySwapSaved
        New-Item -ItemType Junction -Path $managerDirectorySwapGitHub -Target $managerDirectorySwapOutside | Out-Null
        $managerDirectorySwapRun = Complete-TestScriptBarrier -Run $managerDirectorySwapProcess
        $managerDirectorySwapProcess = $null
    }
    finally {
        Stop-TestScriptBarrier -Run $managerDirectorySwapProcess
        Restore-TestDirectorySwap -Path $managerDirectorySwapGitHub -ExpectedTarget $managerDirectorySwapOutside -SavedPath $managerDirectorySwapSaved
    }
    Assert-True ($managerDirectorySwapRun -and $managerDirectorySwapRun.Code -ne 0 -and $managerDirectorySwapRun.Output -match '(?i)reparse point immediately before acceptance or creation' -and (Get-FileSha -Path $managerDirectorySwapSentinel) -eq $managerDirectorySwapSentinelHash -and -not (Test-Path -LiteralPath (Join-Path $managerDirectorySwapOutside "instructions")) -and -not (Test-Path -LiteralPath (Join-Path $managerDirectorySwapProject "AGENTS.md"))) "Native manager rejects a parent junction introduced at the final directory boundary without creating descendants outside the project"

    # Native creation is the safe default; GDD scaffolding requires separate explicit authorization.
    $nativeOnly = New-TestProject -Parent $testRoot -Name "native-only"
    $nativeOnlyRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $nativeOnly)
    Assert-True ($nativeOnlyRun.Code -eq 0 -and (Test-Path -LiteralPath (Join-Path $nativeOnly ".github/copilot-instructions.md") -PathType Leaf) -and (Test-Path -LiteralPath (Join-Path $nativeOnly ".github/instructions/geurts-unity.instructions.md") -PathType Leaf) -and -not (Test-Path -LiteralPath (Join-Path $nativeOnly "Docs")) -and -not (Test-Path -LiteralPath (Join-Path $nativeOnly ".geurts")) -and $nativeOnlyRun.Output.IndexOf("documentation operation", [System.StringComparison]::OrdinalIgnoreCase) -lt 0) "Bare managed setup changes native discovery entries only, without GDD or documentation/network state"

    # Explicitly authorized GDD scaffolding, outside-marker preservation, and idempotence.
    $codexPreservation = New-TestProject -Parent $testRoot -Name "codex-guide-preservation"
    $codexPath = Join-Path $codexPreservation "AGENTS.md"
    Write-Utf8 -Path $codexPath -Text "User-owned Codex guidance"
    $codexHash = Get-FileSha -Path $codexPath
    $codexRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $codexPreservation)
    Assert-True ($codexRun.Code -eq 0 -and (Get-FileSha -Path $codexPath) -eq $codexHash -and -not (Test-Path -LiteralPath (Join-Path $nativeOnly "AGENTS.md"))) "Manual setup preserves an existing Codex guide and does not create a missing root guide"

    $fresh = New-TestProject -Parent $testRoot -Name "fresh"
    $firstSetup = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $fresh, "-IncludeGameDesignScaffolding")
    Assert-True ($firstSetup.Code -eq 0) "Fresh setup succeeds without network access"
    Assert-True ($firstSetup.Output.Contains("Created: .github") -and $firstSetup.Output.Contains("Created: Docs/GameDesign")) "Fresh setup reports managed native-entry and GDD directories"
    Assert-True ($firstSetup.Output.IndexOf("Game Design Manifest summary", [System.StringComparison]::OrdinalIgnoreCase) -lt 0) "GDD scaffolding alone does not implicitly run manifest maintenance"
    foreach ($relative in @(".github/copilot-instructions.md", ".github/instructions/geurts-unity.instructions.md", ".github/instructions/geurts-game-design.instructions.md", "Docs/GameDesign/README.md", "Docs/GameDesign/GameDesignManifest.md")) {
        Assert-True (Test-Path -LiteralPath (Join-Path $fresh $relative) -PathType Leaf) "Fresh setup creates $relative"
    }
    $freshAgentsText = [System.IO.File]::ReadAllText((Join-Path $fresh ".github/copilot-instructions.md"))
    Assert-True ($freshAgentsText.Contains('version="1.3.0"') -and [regex]::Matches($freshAgentsText, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and -not $freshAgentsText.Contains("GeurtsGameForgeCommandments/AGENTS.md") -and -not $freshAgentsText.Contains("Docs/GameDesign/")) "Global Copilot instructions use the exact v1.3.0 direct documentation entry"
    foreach ($relative in @(".github/copilot-instructions.md", ".github/instructions/geurts-unity.instructions.md", ".github/instructions/geurts-game-design.instructions.md")) {
        $nativeRouteText = [System.IO.File]::ReadAllText((Join-Path $fresh $relative))
        Assert-True ($nativeRouteText.Contains('version="1.3.0"') -and [regex]::Matches($nativeRouteText, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and -not $nativeRouteText.Contains("owns the complete documentation chain") -and -not $nativeRouteText.Contains("GeurtsGameForgeCommandments/AGENTS.md") -and -not $nativeRouteText.Contains("network efficiency")) "$relative is the exact concise v1.3.0 project-wide route through AI_READ_FIRST.md into the installed manifest-selected documentation"
    }
    $freshGddReadmeText = [System.IO.File]::ReadAllText((Join-Path $fresh "Docs/GameDesign/README.md"))
    Assert-True ($freshGddReadmeText -match '(?i)project-local fetched Geurts documentation copy' -and $freshGddReadmeText -match '(?i)missing information would establish or change player-facing design intent' -and $freshGddReadmeText -match '(?i)reversible technical details that do not create or overwrite design facts' -and $freshGddReadmeText.Contains('GEURTS-SCAFFOLD-BEGIN version="0.11.0"')) "Managed GDD README remains separate from the fetched copy, stops for missing design intent, and permits only reversible non-design assumptions"
    $trackedFiles = @(".github/copilot-instructions.md", ".github/instructions/geurts-unity.instructions.md", ".github/instructions/geurts-game-design.instructions.md", "Docs/GameDesign/README.md", "Docs/GameDesign/GameDesignManifest.md")
    $before = @{}
    foreach ($relative in $trackedFiles) { $before[$relative] = Get-FileSha -Path (Join-Path $fresh $relative) }
    $secondSetup = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $fresh, "-IncludeGameDesignScaffolding")
    Assert-True ($secondSetup.Code -eq 0) "Second setup succeeds"
    foreach ($relative in $trackedFiles) { Assert-True ((Get-FileSha -Path (Join-Path $fresh $relative)) -eq $before[$relative]) "Second setup leaves $relative byte-identical" }
    $jsonSetupRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $fresh, "-IncludeGameDesignScaffolding", "-UpdateGameDesignManifest", "-OutputFormat", "Json")
    $jsonSetupObject = $null
    try { $jsonSetupObject = $jsonSetupRun.Output | ConvertFrom-Json }
    catch { }
    Assert-True ($jsonSetupRun.Code -eq 0 -and $jsonSetupObject -and $jsonSetupObject.status -eq "OK" -and $jsonSetupObject.gameDesignManifest.status -eq "UPDATED") "First separately authorized manifest update indexes the new GDD scaffold in one parseable JSON result"
    $jsonSetupAgainRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $fresh, "-UpdateGameDesignManifest", "-OutputFormat", "Json")
    $jsonSetupAgainObject = $null
    try { $jsonSetupAgainObject = $jsonSetupAgainRun.Output | ConvertFrom-Json }
    catch { }
    Assert-True ($jsonSetupAgainRun.Code -eq 0 -and $jsonSetupAgainObject -and $jsonSetupAgainObject.status -eq "OK" -and $jsonSetupAgainObject.gameDesignManifest.status -eq "UNCHANGED") "Repeated standalone manifest maintenance is parseable and idempotent"

    $agentsPath = Join-Path $fresh ".github/copilot-instructions.md"
    [System.IO.File]::AppendAllText($agentsPath, "`nUser-owned note outside the managed block.`n", $utf8NoBom)
    $outsideHash = Get-FileSha -Path $agentsPath
    $outsideRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $fresh, "-IncludeGameDesignScaffolding")
    Assert-True ($outsideRun.Code -eq 0 -and (Get-FileSha -Path $agentsPath) -eq $outsideHash) "Content outside managed markers is preserved"

    $managedV07 = New-TestProject -Parent $testRoot -Name "managed-v07-agents"
    $managedV07Path = Join-Path $managedV07 ".github/copilot-instructions.md"
    $managedV07Base = Get-HistoricalFile -Specification "5f51965:Tools/AIAgentInstructionTemplates/copilot-instructions.md"
    $managedV07WithEndWhitespace = $managedV07Base.Replace('<!-- GEURTS-MANAGED-END id="copilot-body" -->', '<!-- GEURTS-MANAGED-END id="copilot-body" -->   ')
    $managedV07CrLf = ((($managedV07WithEndWhitespace -replace "`r`n", "`n") -replace "`r", "`n").Replace("`n", "`r`n"))
    $managedV07Text = $managedV07Base + "`nUser-owned content outside the managed region.`n"
    Write-Utf8 -Path $managedV07Path -Text $managedV07Text
    $managedV07Run = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $managedV07)
    $managedV10Text = [System.IO.File]::ReadAllText($managedV07Path)
    Assert-True ($managedV07Run.Code -eq 0 -and $managedV10Text.Contains('version="1.3.0"') -and [regex]::Matches($managedV10Text, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and -not $managedV10Text.Contains("GeurtsGameForgeCommandments/AGENTS.md") -and $managedV10Text.Contains("User-owned content outside the managed region.")) "Valid managed v0.7 Copilot upgrades to the exact v1.3.0 project-wide shim while preserving outside content"

    # The last released routes must upgrade without losing user text or changing their CRLF bytes outside markers.
    $previousRoutes = New-TestProject -Parent $testRoot -Name "managed-v12-routes"
    $previousRouteHashes = @{}
    $routeTargets = @(".github/copilot-instructions.md", ".github/instructions/geurts-unity.instructions.md", ".github/instructions/geurts-game-design.instructions.md")
    foreach ($relative in $routeTargets) {
        $sourceRelative = "Tools/AIAgentInstructionTemplates/" + $relative.Substring(".github/".Length)
        $previousText = Get-HistoricalFile -Specification ("29c923404d21515410285568d191a4a1c4c0a601:" + $sourceRelative)
        $previousText = ($previousText -replace "`r`n", "`n").Replace("`n", "`r`n")
        $previousText += "`r`nUser-owned v1.2 route suffix.`r`n"
        Write-Utf8 -Path (Join-Path $previousRoutes $relative) -Text $previousText
        $previousRouteHashes[$relative] = Get-FileSha -Path (Join-Path $previousRoutes $relative)
    }
    $previousRoutesRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $previousRoutes)
    $upgradedRouteHashes = @{}
    foreach ($relative in $routeTargets) {
        $targetPath = Join-Path $previousRoutes $relative
        $upgradedText = [System.IO.File]::ReadAllText($targetPath)
        Assert-True ($previousRoutesRun.Code -eq 0 -and $upgradedText.Contains('version="1.3.0"') -and [regex]::Matches($upgradedText, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and $upgradedText.EndsWith("`r`nUser-owned v1.2 route suffix.`r`n") -and (Test-CrLfOnly -Text $upgradedText) -and (Get-FileSha -Path ($targetPath + ".pre-v0.9.0.bak")) -eq $previousRouteHashes[$relative]) "$relative upgrades released v1.2.0 to all-project-work routing with CRLF, outside content and a byte-identical backup preserved"
        $upgradedRouteHashes[$relative] = Get-FileSha -Path $targetPath
    }
    $previousRoutesAgain = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $previousRoutes)
    foreach ($relative in $routeTargets) {
        Assert-True ($previousRoutesAgain.Code -eq 0 -and (Get-FileSha -Path (Join-Path $previousRoutes $relative)) -eq $upgradedRouteHashes[$relative]) "$relative remains byte-identical after repeating the v1.3.0 upgrade"
    }
    $modifiedPreviousRoutes = New-TestProject -Parent $testRoot -Name "modified-v12-routes"
    foreach ($relative in $routeTargets) {
        $sourceRelative = "Tools/AIAgentInstructionTemplates/" + $relative.Substring(".github/".Length)
        $modifiedText = (Get-HistoricalFile -Specification ("29c923404d21515410285568d191a4a1c4c0a601:" + $sourceRelative)).Replace("source of truth", "user-authored instructions")
        Write-Utf8 -Path (Join-Path $modifiedPreviousRoutes $relative) -Text $modifiedText
        $previousRouteHashes[$relative] = Get-FileSha -Path (Join-Path $modifiedPreviousRoutes $relative)
    }
    $modifiedPreviousRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $modifiedPreviousRoutes)
    foreach ($relative in $routeTargets) {
        $targetPath = Join-Path $modifiedPreviousRoutes $relative
        Assert-True ($modifiedPreviousRun.Code -ne 0 -and (Get-FileSha -Path $targetPath) -eq $previousRouteHashes[$relative] -and -not (Test-Path -LiteralPath ($targetPath + ".pre-v0.9.0.bak"))) "$relative rejects modified v1.2.0 managed content without mutation or a backup"
    }

    $utf8BomProject = New-TestProject -Parent $testRoot -Name "managed-utf8-bom-mixed-newlines"
    $utf8BomPath = Join-Path $utf8BomProject ".github/copilot-instructions.md"
    $utf8BomEncoding = New-Object System.Text.UTF8Encoding($true, $true)
    $utf8PrefixText = "# UTF-8 user prefix`r`nMixed newline stays`n"
    $utf8SuffixText = "`r`n`r`nUTF-8 user suffix`r`n"
    [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($utf8BomPath)) | Out-Null
    [System.IO.File]::WriteAllText($utf8BomPath, ($utf8PrefixText + $managedV07CrLf + $utf8SuffixText), $utf8BomEncoding)
    $utf8BeforeHash = Get-FileSha -Path $utf8BomPath
    $utf8Run = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $utf8BomProject)
    $utf8AfterBytes = [System.IO.File]::ReadAllBytes($utf8BomPath)
    $utf8AfterText = $utf8BomEncoding.GetString($utf8AfterBytes, 3, $utf8AfterBytes.Length - 3)
    $utf8ManagedRegion = [regex]::Match($utf8AfterText, '(?ms)^<!--\s*GEURTS-MANAGED-BEGIN.*?^<!--\s*GEURTS-MANAGED-END[^\r\n]*')
    $utf8ExpectedPrefix = [byte[]](@($utf8BomEncoding.GetPreamble()) + @($utf8BomEncoding.GetBytes($utf8PrefixText)))
    $utf8ExpectedSuffix = [byte[]]($utf8BomEncoding.GetBytes($utf8SuffixText))
    Assert-True ($utf8Run.Code -eq 0 -and (Test-BytePrefix -Bytes $utf8AfterBytes -Expected $utf8ExpectedPrefix) -and (Test-ByteSuffix -Bytes $utf8AfterBytes -Expected $utf8ExpectedSuffix) -and $utf8ManagedRegion.Success -and (Test-CrLfOnly -Text $utf8ManagedRegion.Value) -and (Get-FileSha -Path ($utf8BomPath + ".pre-v0.9.0.bak")) -eq $utf8BeforeHash) "Managed UTF-8 BOM update preserves exact outside bytes and the CRLF managed-region convention with a byte-identical backup"

    $utf16Project = New-TestProject -Parent $testRoot -Name "managed-utf16"
    $utf16Path = Join-Path $utf16Project ".github/copilot-instructions.md"
    $utf16Encoding = New-Object System.Text.UnicodeEncoding($false, $true, $true)
    $utf16PrefixText = "# UTF-16 user prefix`r`n"
    $utf16SuffixText = "`r`nUTF-16 user suffix`n"
    [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($utf16Path)) | Out-Null
    [System.IO.File]::WriteAllText($utf16Path, ($utf16PrefixText + $managedV07CrLf + $utf16SuffixText), $utf16Encoding)
    $utf16BeforeHash = Get-FileSha -Path $utf16Path
    $utf16Run = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $utf16Project)
    $utf16AfterBytes = [System.IO.File]::ReadAllBytes($utf16Path)
    $utf16AfterText = $utf16Encoding.GetString($utf16AfterBytes, 2, $utf16AfterBytes.Length - 2)
    $utf16ManagedRegion = [regex]::Match($utf16AfterText, '(?ms)^<!--\s*GEURTS-MANAGED-BEGIN.*?^<!--\s*GEURTS-MANAGED-END[^\r\n]*')
    $utf16ExpectedPrefix = [byte[]](@($utf16Encoding.GetPreamble()) + @($utf16Encoding.GetBytes($utf16PrefixText)))
    $utf16ExpectedSuffix = [byte[]]($utf16Encoding.GetBytes($utf16SuffixText))
    Assert-True ($utf16Run.Code -eq 0 -and (Test-BytePrefix -Bytes $utf16AfterBytes -Expected $utf16ExpectedPrefix) -and (Test-ByteSuffix -Bytes $utf16AfterBytes -Expected $utf16ExpectedSuffix) -and $utf16ManagedRegion.Success -and (Test-CrLfOnly -Text $utf16ManagedRegion.Value) -and (Get-FileSha -Path ($utf16Path + ".pre-v0.9.0.bak")) -eq $utf16BeforeHash) "Managed UTF-16LE update preserves exact outside bytes, encoding, and CRLF region with a byte-identical backup"

    $utf16BeProject = New-TestProject -Parent $testRoot -Name "managed-utf16be"
    $utf16BePath = Join-Path $utf16BeProject ".github/copilot-instructions.md"
    $utf16BeEncoding = New-Object System.Text.UnicodeEncoding($true, $true, $true)
    $utf16BePrefixText = "# UTF-16BE user prefix`r`n"
    $utf16BeSuffixText = "`r`nUTF-16BE user suffix`n"
    [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($utf16BePath)) | Out-Null
    [System.IO.File]::WriteAllText($utf16BePath, ($utf16BePrefixText + $managedV07CrLf + $utf16BeSuffixText), $utf16BeEncoding)
    $utf16BeBeforeHash = Get-FileSha -Path $utf16BePath
    $utf16BeRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $utf16BeProject)
    $utf16BeAfterBytes = [System.IO.File]::ReadAllBytes($utf16BePath)
    $utf16BeExpectedPrefix = [byte[]](@($utf16BeEncoding.GetPreamble()) + @($utf16BeEncoding.GetBytes($utf16BePrefixText)))
    $utf16BeExpectedSuffix = [byte[]]($utf16BeEncoding.GetBytes($utf16BeSuffixText))
    Assert-True ($utf16BeRun.Code -eq 0 -and (Test-BytePrefix -Bytes $utf16BeAfterBytes -Expected $utf16BeExpectedPrefix) -and (Test-ByteSuffix -Bytes $utf16BeAfterBytes -Expected $utf16BeExpectedSuffix) -and (Get-FileSha -Path ($utf16BePath + ".pre-v0.9.0.bak")) -eq $utf16BeBeforeHash) "Managed UTF-16BE update preserves exact outside bytes and encoding with a byte-identical backup"

    $unsupportedEncodingProject = New-TestProject -Parent $testRoot -Name "unsupported-managed-encoding"
    $unsupportedEncodingPath = Join-Path $unsupportedEncodingProject ".github/copilot-instructions.md"
    [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($unsupportedEncodingPath)) | Out-Null
    [System.IO.File]::WriteAllBytes($unsupportedEncodingPath, [byte[]](0xFF, 0xFE, 0x00, 0x00, 0x41, 0x00, 0x00, 0x00))
    $unsupportedEncodingHash = Get-FileSha -Path $unsupportedEncodingPath
    $unsupportedEncodingRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $unsupportedEncodingProject)
    Assert-True ($unsupportedEncodingRun.Code -eq 2 -and (Get-FileSha -Path $unsupportedEncodingPath) -eq $unsupportedEncodingHash -and -not (Test-Path -LiteralPath ($unsupportedEncodingPath + ".pre-v0.9.0.bak")) -and $unsupportedEncodingRun.Output -match '(?i)unsupported UTF-32') "Unsupported managed-entry encoding conflicts without rewrite, backup, or silent UTF-8 conversion"

    $invalidUtf8Project = New-TestProject -Parent $testRoot -Name "invalid-utf8-managed-entry"
    $invalidUtf8Path = Join-Path $invalidUtf8Project ".github/copilot-instructions.md"
    [System.IO.Directory]::CreateDirectory([System.IO.Path]::GetDirectoryName($invalidUtf8Path)) | Out-Null
    [System.IO.File]::WriteAllBytes($invalidUtf8Path, [byte[]](0x23, 0x20, 0xC3, 0x28, 0x0A))
    $invalidUtf8Hash = Get-FileSha -Path $invalidUtf8Path
    $invalidUtf8Run = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $invalidUtf8Project)
    Assert-True ($invalidUtf8Run.Code -eq 2 -and (Get-FileSha -Path $invalidUtf8Path) -eq $invalidUtf8Hash -and -not (Test-Path -LiteralPath ($invalidUtf8Path + ".pre-v0.9.0.bak")) -and $invalidUtf8Run.Output -match '(?i)invalid text encoding') "Invalid BOM-less UTF-8 conflicts without rewrite, backup, or silent replacement"

    $concurrentCreateProject = New-TestProject -Parent $testRoot -Name "concurrent-native-create"
    $concurrentCreatePath = Join-Path $concurrentCreateProject ".github/copilot-instructions.md"
    $concurrentCreateBarrier = Join-Path $testRoot "barrier-native-create"
    $concurrentCreateProcess = Start-TestScriptAtBarrier -Path $manageScript -Arguments @("-ProjectRoot", $concurrentCreateProject) -BarrierPath $concurrentCreateBarrier -TargetPath $concurrentCreatePath
    Wait-TestScriptBarrier -Run $concurrentCreateProcess
    Write-Utf8 -Path $concurrentCreatePath -Text "# Concurrent user-created instructions`r`nPreserve this file.`r`n"
    $concurrentCreateHash = Get-FileSha -Path $concurrentCreatePath
    $concurrentCreateRun = Complete-TestScriptBarrier -Run $concurrentCreateProcess
    Assert-True ($concurrentCreateRun.Code -eq 2 -and (Get-FileSha -Path $concurrentCreatePath) -eq $concurrentCreateHash -and $concurrentCreateRun.Output -match '(?i)target appeared.*concurrent content was preserved') "Concurrent native-entry creation wins the absent-state race and is never overwritten"

    $concurrentManagedProject = New-TestProject -Parent $testRoot -Name "concurrent-managed-update"
    $concurrentManagedPath = Join-Path $concurrentManagedProject ".github/copilot-instructions.md"
    Write-Utf8 -Path $concurrentManagedPath -Text $managedV07Text
    $concurrentManagedOriginalHash = Get-FileSha -Path $concurrentManagedPath
    $concurrentManagedBarrier = Join-Path $testRoot "barrier-managed-update"
    $concurrentManagedProcess = Start-TestScriptAtBarrier -Path $manageScript -Arguments @("-ProjectRoot", $concurrentManagedProject) -BarrierPath $concurrentManagedBarrier -TargetPath $concurrentManagedPath
    Wait-TestScriptBarrier -Run $concurrentManagedProcess
    [System.IO.File]::AppendAllText($concurrentManagedPath, "Concurrent user edit.`r`n", $utf8NoBom)
    $concurrentManagedHash = Get-FileSha -Path $concurrentManagedPath
    $concurrentManagedRun = Complete-TestScriptBarrier -Run $concurrentManagedProcess
    Assert-True ($concurrentManagedRun.Code -eq 2 -and (Get-FileSha -Path $concurrentManagedPath) -eq $concurrentManagedHash -and (Get-FileSha -Path ($concurrentManagedPath + ".pre-v0.9.0.bak")) -eq $concurrentManagedOriginalHash -and $concurrentManagedRun.Output -match '(?i)target bytes changed.*concurrent content was preserved') "Concurrent raw-byte drift during a managed-region update is preserved and reported"

    $concurrentLegacyProject = New-TestProject -Parent $testRoot -Name "concurrent-legacy-migration"
    $concurrentLegacyPath = Join-Path $concurrentLegacyProject ".github/copilot-instructions.md"
    Write-Utf8 -Path $concurrentLegacyPath -Text (Get-HistoricalFile -Specification "544922c:Tools/AIAgentInstructionTemplates/copilot-instructions.md")
    $concurrentLegacyOriginalHash = Get-FileSha -Path $concurrentLegacyPath
    $concurrentLegacyBarrier = Join-Path $testRoot "barrier-legacy-migration"
    $concurrentLegacyProcess = Start-TestScriptAtBarrier -Path $manageScript -Arguments @("-ProjectRoot", $concurrentLegacyProject) -BarrierPath $concurrentLegacyBarrier -TargetPath $concurrentLegacyPath
    Wait-TestScriptBarrier -Run $concurrentLegacyProcess
    [System.IO.File]::AppendAllText($concurrentLegacyPath, "Concurrent legacy edit.`n", $utf8NoBom)
    $concurrentLegacyHash = Get-FileSha -Path $concurrentLegacyPath
    $concurrentLegacyRun = Complete-TestScriptBarrier -Run $concurrentLegacyProcess
    Assert-True ($concurrentLegacyRun.Code -eq 2 -and (Get-FileSha -Path $concurrentLegacyPath) -eq $concurrentLegacyHash -and (Get-FileSha -Path ($concurrentLegacyPath + ".pre-v0.9.0.bak")) -eq $concurrentLegacyOriginalHash -and $concurrentLegacyRun.Output -match '(?i)target bytes changed.*concurrent content was preserved') "Concurrent raw-byte drift during exact legacy migration is preserved and reported"

    foreach ($backupSwapCase in @(
        @{ Name = "managed"; Specification = "5f51965:Tools/AIAgentInstructionTemplates/copilot-instructions.md"; Label = "managed-region update" },
        @{ Name = "legacy"; Specification = "544922c:Tools/AIAgentInstructionTemplates/copilot-instructions.md"; Label = "exact legacy migration" }
    )) {
        $backupSwapProject = New-TestProject -Parent $testRoot -Name ("backup-parent-swap-" + $backupSwapCase.Name)
        $backupSwapGitHub = Join-Path $backupSwapProject ".github"
        New-Item -ItemType Directory -Path $backupSwapGitHub | Out-Null
        $backupSwapTarget = Join-Path $backupSwapGitHub "copilot-instructions.md"
        Write-Utf8 -Path $backupSwapTarget -Text (Get-HistoricalFile -Specification $backupSwapCase.Specification)
        $backupSwapTargetHash = Get-FileSha -Path $backupSwapTarget
        $backupSwapBackup = $backupSwapTarget + ".pre-v0.9.0.bak"
        $backupSwapBarrier = Join-Path $testRoot ("barrier-backup-parent-swap-" + $backupSwapCase.Name)
        $backupSwapProcess = Start-TestScriptAtBarrier -Path $manageScript -Arguments @("-ProjectRoot", $backupSwapProject) -BarrierPath $backupSwapBarrier -TargetPath $backupSwapBackup
        $backupSwapSaved = Join-Path $backupSwapProject ".github-before-swap"
        $backupSwapOutside = Join-Path $testRoot ("backup-parent-swap-outside-" + $backupSwapCase.Name)
        $backupSwapSentinel = Join-Path $backupSwapOutside "user-sentinel.txt"
        $backupSwapRun = $null
        try {
            Wait-TestScriptBarrier -Run $backupSwapProcess
            New-Item -ItemType Directory -Path $backupSwapOutside | Out-Null
            Write-Utf8 -Path $backupSwapSentinel -Text "Outside backup content must remain untouched.`n"
            $backupSwapSentinelHash = Get-FileSha -Path $backupSwapSentinel
            Move-Item -LiteralPath $backupSwapGitHub -Destination $backupSwapSaved
            New-Item -ItemType Junction -Path $backupSwapGitHub -Target $backupSwapOutside | Out-Null
            $backupSwapRun = Complete-TestScriptBarrier -Run $backupSwapProcess
            $backupSwapProcess = $null
        }
        finally {
            Stop-TestScriptBarrier -Run $backupSwapProcess
            Restore-TestDirectorySwap -Path $backupSwapGitHub -ExpectedTarget $backupSwapOutside -SavedPath $backupSwapSaved
        }
        $backupSwapDebris = @(
            @(Get-ChildItem -LiteralPath $backupSwapProject -Filter ".ggf-*" -Force -File -ErrorAction SilentlyContinue)
            @(Get-ChildItem -LiteralPath $backupSwapGitHub -Filter ".ggf-*" -Force -File -ErrorAction SilentlyContinue)
        )
        Assert-True ($backupSwapRun -and $backupSwapRun.Code -ne 0 -and $backupSwapRun.Output -match '(?i)backup path changed.*unsafe reparse point' -and (Get-FileSha -Path $backupSwapTarget) -eq $backupSwapTargetHash -and (Get-FileSha -Path $backupSwapSentinel) -eq $backupSwapSentinelHash -and -not (Test-Path -LiteralPath $backupSwapBackup) -and -not (Test-Path -LiteralPath (Join-Path $backupSwapOutside "copilot-instructions.md.pre-v0.9.0.bak")) -and $backupSwapDebris.Count -eq 0) "Parent swap before $($backupSwapCase.Label) backup promotion preserves target/outside bytes and leaves no backup or transaction debris"
    }

    $pathSwapProject = New-TestProject -Parent $testRoot -Name "native-parent-reparse-swap"
    $pathSwapAgents = Join-Path $pathSwapProject ".github/copilot-instructions.md"
    $pathSwapTarget = Join-Path $pathSwapProject ".github/copilot-instructions.md"
    $pathSwapBarrier = Join-Path $testRoot "barrier-native-parent-swap"
    $pathSwapProcess = Start-TestScriptAtBarrier -Path $manageScript -Arguments @("-ProjectRoot", $pathSwapProject) -BarrierPath $pathSwapBarrier -TargetPath $pathSwapTarget
    $pathSwapGitHub = Join-Path $pathSwapProject ".github"
    $pathSwapSavedGitHub = Join-Path $pathSwapProject ".github-before-swap"
    $pathSwapOutside = Join-Path $testRoot "native-parent-swap-outside"
    $pathSwapSentinel = Join-Path $pathSwapOutside "user-sentinel.txt"
    $pathSwapRun = $null
    try {
        Wait-TestScriptBarrier -Run $pathSwapProcess
        New-Item -ItemType Directory -Path $pathSwapOutside | Out-Null
        Write-Utf8 -Path $pathSwapSentinel -Text "Outside user content must remain untouched.`r`n"
        $pathSwapSentinelHash = Get-FileSha -Path $pathSwapSentinel
        Move-Item -LiteralPath $pathSwapGitHub -Destination $pathSwapSavedGitHub
        New-Item -ItemType Junction -Path $pathSwapGitHub -Target $pathSwapOutside | Out-Null
        $pathSwapRun = Complete-TestScriptBarrier -Run $pathSwapProcess
        $pathSwapProcess = $null
    }
    finally {
        Stop-TestScriptBarrier -Run $pathSwapProcess
        Restore-TestDirectorySwap -Path $pathSwapGitHub -ExpectedTarget $pathSwapOutside -SavedPath $pathSwapSavedGitHub
    }
    $pathSwapTempFiles = @(
        @(Get-ChildItem -LiteralPath $pathSwapProject -Filter ".ggf-*" -Force -File -ErrorAction SilentlyContinue)
        @(Get-ChildItem -LiteralPath $pathSwapGitHub -Filter ".ggf-*" -Force -File -ErrorAction SilentlyContinue)
    )
    Assert-True ($pathSwapRun -and $pathSwapRun.Code -ne 0 -and $pathSwapRun.Output -match '(?i)reparse point' -and (Get-FileSha -Path $pathSwapSentinel) -eq $pathSwapSentinelHash -and -not (Test-Path -LiteralPath (Join-Path $pathSwapOutside "copilot-instructions.md")) -and $pathSwapTempFiles.Count -eq 0) "Late native-entry parent reparse swap is rejected at the final guard without external writes or transaction debris"

    $unknownManagedProject = New-TestProject -Parent $testRoot -Name "unknown-product-managed-block"
    $unknownManagedPath = Join-Path $unknownManagedProject ".github/copilot-instructions.md"
    Write-Utf8 -Path $unknownManagedPath -Text "<!-- PRODUCT_POLICY_START -->`nUser or product content.`n<!-- PRODUCT_POLICY_END -->`n"
    $unknownManagedHash = Get-FileSha -Path $unknownManagedPath
    $unknownManagedRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $unknownManagedProject)
    Assert-True ($unknownManagedRun.Code -eq 2 -and (Get-FileSha -Path $unknownManagedPath) -eq $unknownManagedHash -and -not (Test-Path -LiteralPath ($unknownManagedPath + ".pre-v0.9.0.bak"))) "Unknown product- or user-owned managed blocks conflict and remain byte-identical"

    $userOwned = New-TestProject -Parent $testRoot -Name "user-owned"
    Write-Utf8 -Path (Join-Path $userOwned ".github/copilot-instructions.md") -Text "# Personal project instructions`nKeep this content.`n"
    $userHash = Get-FileSha -Path (Join-Path $userOwned ".github/copilot-instructions.md")
    $userRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $userOwned)
    Assert-True ($userRun.Code -eq 0 -and (Get-FileSha -Path (Join-Path $userOwned ".github/copilot-instructions.md")) -eq $userHash) "Unmarked user-owned native file is preserved"

    $blockedSetup = New-TestProject -Parent $testRoot -Name "blocked-setup-directory"
    Write-Utf8 -Path (Join-Path $blockedSetup ".github") -Text "user-owned blocking file`n"
    $blockedSetupHash = Get-FileSha -Path (Join-Path $blockedSetup ".github")
    $blockedSetupRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $blockedSetup)
    Assert-True ($blockedSetupRun.Code -eq 1 -and (Get-FileSha -Path (Join-Path $blockedSetup ".github")) -eq $blockedSetupHash -and -not (Test-Path -LiteralPath (Join-Path $blockedSetup ".github/copilot-instructions.md"))) "Managed setup preflights blocking directories before any file mutation"

    $malformed = New-TestProject -Parent $testRoot -Name "malformed"
    $malformedPath = Join-Path $malformed ".github/copilot-instructions.md"
    Write-Utf8 -Path $malformedPath -Text '<!-- GEURTS-MANAGED-BEGIN id="broken" version="0.7.0" sha256="0000000000000000000000000000000000000000000000000000000000000000" -->'
    $malformedHash = Get-FileSha -Path $malformedPath
    $malformedRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $malformed)
    Assert-True ($malformedRun.Code -eq 2 -and (Get-FileSha -Path $malformedPath) -eq $malformedHash) "Malformed managed markers conflict without overwriting"

    $yamlOutside = New-TestProject -Parent $testRoot -Name "yaml-outside-frontmatter"
    $yamlOutsidePath = Join-Path $yamlOutside ".github/instructions/geurts-unity.instructions.md"
    $yamlTemplateText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md"))
    $yamlRegion = [regex]::Match($yamlTemplateText, '(?ms)^#\s*GEURTS-MANAGED-BEGIN\s+id="unity-frontmatter".*?^#\s*GEURTS-MANAGED-END\s+id="unity-frontmatter"\s*$')
    if (-not $yamlRegion.Success) { throw "Unable to prepare the YAML marker boundary fixture." }
    $yamlOutsideText = $yamlTemplateText.Remove($yamlRegion.Index, $yamlRegion.Length).TrimEnd() + "`n`n" + $yamlRegion.Value + "`n"
    Write-Utf8 -Path $yamlOutsidePath -Text $yamlOutsideText
    $yamlOutsideHash = Get-FileSha -Path $yamlOutsidePath
    $yamlOutsideRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $yamlOutside)
    Assert-True ($yamlOutsideRun.Code -eq 2 -and (Get-FileSha -Path $yamlOutsidePath) -eq $yamlOutsideHash -and $yamlOutsideRun.Output.Contains("frontmatter delimiters")) "YAML managed markers outside frontmatter conflict without overwriting"

    $optOut = New-TestProject -Parent $testRoot -Name "opt-out"
    $optOutPath = Join-Path $optOut ".github/copilot-instructions.md"
    $optOutText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/copilot-instructions.md")) + "`n<!-- GEURTS-MANAGED-OPT-OUT -->`nUser-owned routing remains authoritative.`n"
    Write-Utf8 -Path $optOutPath -Text $optOutText
    $optOutHash = Get-FileSha -Path $optOutPath
    $optOutRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $optOut)
    Assert-True ($optOutRun.Code -eq 0 -and (Get-FileSha -Path $optOutPath) -eq $optOutHash -and $optOutRun.Output.Contains("Skipped: .github/copilot-instructions.md")) "Explicit managed opt-out preserves the complete native entry"

    $editedManaged = New-TestProject -Parent $testRoot -Name "edited-managed"
    $editedManagedPath = Join-Path $editedManaged ".github/copilot-instructions.md"
    $editedManagedText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/copilot-instructions.md")).Replace("Geurts Game Forge Copilot Instructions", "User Edited Geurts Game Forge Copilot Instructions")
    Write-Utf8 -Path $editedManagedPath -Text $editedManagedText
    $editedManagedHash = Get-FileSha -Path $editedManagedPath
    $editedManagedRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $editedManaged)
    Assert-True ($editedManagedRun.Code -eq 2 -and (Get-FileSha -Path $editedManagedPath) -eq $editedManagedHash) "Edited managed content conflicts without overwriting"

    $futureManaged = New-TestProject -Parent $testRoot -Name "future-managed"
    $futureManagedPath = Join-Path $futureManaged ".github/copilot-instructions.md"
    $futureManagedText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/copilot-instructions.md")).Replace('version="1.3.0"', 'version="2.0.0"')
    Write-Utf8 -Path $futureManagedPath -Text $futureManagedText
    $futureManagedHash = Get-FileSha -Path $futureManagedPath
    $futureManagedRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $futureManaged)
    Assert-True ($futureManagedRun.Code -eq 2 -and (Get-FileSha -Path $futureManagedPath) -eq $futureManagedHash -and $futureManagedRun.Output.Contains("no downgrade")) "Future managed native entry is never downgraded"

    $tamperedCatalogProject = New-TestProject -Parent $testRoot -Name "tampered-catalog"
    $tamperedCatalogPath = Join-Path $tamperedCatalogProject "NativeEntryMigrationCatalog.json"
    $tamperedCatalog = Get-Content -LiteralPath (Join-Path $RepositoryRoot "Tools/NativeEntryMigrationCatalog.json") -Raw | ConvertFrom-Json
    $tamperedCatalog.entries[0].targetPath = "UserInstructions.md"
    Write-Utf8 -Path $tamperedCatalogPath -Text ($tamperedCatalog | ConvertTo-Json -Depth 10)
    $tamperedCatalogRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $tamperedCatalogProject, "-MigrationCatalogPath", $tamperedCatalogPath)
    Assert-True ($tamperedCatalogRun.Code -eq 1 -and -not (Test-Path -LiteralPath (Join-Path $tamperedCatalogProject "UserInstructions.md"))) "Tampered migration catalog is rejected before native mutation"

    # Exact historical native templates, including the last Documentation route, migrate with backups.
    $historicalSets = @(
        @{ Name = "documentation-v11"; Files = @{
            ".github/copilot-instructions.md" = "4badea6:Tools/AIAgentInstructionTemplates/copilot-instructions.md";
            ".github/instructions/geurts-unity.instructions.md" = "4badea6:Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md";
            ".github/instructions/geurts-game-design.instructions.md" = "4badea6:Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"
        }},
        @{ Name = "v04"; Files = @{
            ".github/copilot-instructions.md" = "b989941:Tools/AIAgentInstructionTemplates/copilot-instructions.md";
            ".github/instructions/geurts-unity.instructions.md" = "b989941:Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md";
            ".github/instructions/geurts-game-design.instructions.md" = "b989941:Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"
        }},
        @{ Name = "v05"; Files = @{
            ".github/copilot-instructions.md" = "b989941:Tools/AIAgentInstructionTemplates/copilot-instructions.md";
            ".github/instructions/geurts-unity.instructions.md" = "b989941:Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md";
            ".github/instructions/geurts-game-design.instructions.md" = "b989941:Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"
        }},
        @{ Name = "v06"; Files = @{
            ".github/copilot-instructions.md" = "544922c:Tools/AIAgentInstructionTemplates/copilot-instructions.md";
            ".github/instructions/geurts-unity.instructions.md" = "544922c:Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md";
            ".github/instructions/geurts-game-design.instructions.md" = "544922c:Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"
        }}
    )
    foreach ($set in $historicalSets) {
        $project = New-TestProject -Parent $testRoot -Name $set.Name
        foreach ($relative in $set.Files.Keys) { Write-Utf8 -Path (Join-Path $project $relative) -Text (Get-HistoricalFile -Specification $set.Files[$relative]) }
        $migrationRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $project)
        Assert-True ($migrationRun.Code -eq 0) "Exact $($set.Name) native set migrates"
        foreach ($relative in $set.Files.Keys) {
            $target = Join-Path $project $relative
            $migratedNativeText = [System.IO.File]::ReadAllText($target)
            Assert-True ($migratedNativeText.Contains("GEURTS-MANAGED-BEGIN") -and $migratedNativeText.Contains('version="1.3.0"') -and [regex]::Matches($migratedNativeText, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and -not $migratedNativeText.Contains("GeurtsGameForgeCommandments/AGENTS.md")) "$($set.Name) $relative migrates to the exact managed v1.3.0 project-wide route through AI_READ_FIRST.md"
            Assert-True (Test-Path -LiteralPath ($target + ".pre-v0.9.0.bak") -PathType Leaf) "$($set.Name) $relative receives a pre-v0.9.0 backup"
        }
    }

    $crlfLegacyProject = New-TestProject -Parent $testRoot -Name "legacy-crlf-migration"
    $crlfLegacyPath = Join-Path $crlfLegacyProject ".github/copilot-instructions.md"
    $crlfLegacySource = Get-HistoricalFile -Specification "544922c:Tools/AIAgentInstructionTemplates/copilot-instructions.md"
    $crlfLegacyText = ((($crlfLegacySource -replace "`r`n", "`n") -replace "`r", "`n").Replace("`n", "`r`n"))
    Write-Utf8 -Path $crlfLegacyPath -Text $crlfLegacyText
    $crlfLegacyHash = Get-FileSha -Path $crlfLegacyPath
    $crlfLegacyRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $crlfLegacyProject)
    $crlfMigratedText = [System.IO.File]::ReadAllText($crlfLegacyPath)
    Assert-True ($crlfLegacyRun.Code -eq 0 -and $crlfMigratedText.Contains('version="1.3.0"') -and [regex]::Matches($crlfMigratedText, [regex]::Escape($expectedProjectRouteText)).Count -eq 1 -and (Test-CrLfOnly -Text $crlfMigratedText) -and (Get-FileSha -Path ($crlfLegacyPath + ".pre-v0.9.0.bak")) -eq $crlfLegacyHash) "Exact CRLF legacy template migration installs the v1.3.0 project-wide route while preserving its whole-file newline convention and byte-identical legacy backup"

    $modifiedLegacy = New-TestProject -Parent $testRoot -Name "modified-legacy"
    $modifiedLegacyPath = Join-Path $modifiedLegacy ".github/copilot-instructions.md"
    Write-Utf8 -Path $modifiedLegacyPath -Text ((Get-HistoricalFile -Specification "544922c:Tools/AIAgentInstructionTemplates/copilot-instructions.md") + "`nUser modification.`n")
    $modifiedLegacyHash = Get-FileSha -Path $modifiedLegacyPath
    $modifiedLegacyRun = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $modifiedLegacy)
    Assert-True ($modifiedLegacyRun.Code -eq 2 -and (Get-FileSha -Path $modifiedLegacyPath) -eq $modifiedLegacyHash -and $modifiedLegacyRun.Output.Contains("user-modified legacy")) "Modified legacy native entry is preserved and reported as conflicted"

    # GDD managed-region writes preserve supported encodings and exact bytes outside the region.
    $primaryGddBlock = @'
<!-- GEURTS-GDD-PRIMARY-BEGIN version="1.0.0" -->
## Primary Game Design Document

**Primary document:** `Docs/GameDesign/Encoding.md`

This document is the primary source of context about the game.
Technical design and implementation guidance remains authoritative in `GeurtsGameForgeCommandments/`, entered through `AI_READ_FIRST.md` and its manifest.
<!-- GEURTS-GDD-PRIMARY-END -->
'@
    $importedGddBlock = '<!-- GEURTS-GDD-IMPORTS-BEGIN version="1.0.0" -->' + "`n" + '## Imported Game Design Documents' + "`n`n" + 'These selected documents supplement the primary game context. Import does not assign design authority or classification.' + "`n`n" + '- `Docs/GameDesign/Encoding.md`' + "`n" + '- `Docs/GameDesign/Supporting.md`' + "`n" + '<!-- GEURTS-GDD-IMPORTS-END -->' + "`n"
    $primaryGddBlock = ($primaryGddBlock -replace "`r`n", "`n") + "`n"
    $gddEncodingCases = @(
        @{ Name = "gdd-utf8-bom"; Label = "UTF-8 BOM"; Encoding = (New-Object System.Text.UTF8Encoding($true, $true)); PreambleLength = 3 },
        @{ Name = "gdd-utf16le"; Label = "UTF-16LE"; Encoding = (New-Object System.Text.UnicodeEncoding($false, $true, $true)); PreambleLength = 2 },
        @{ Name = "gdd-utf16be"; Label = "UTF-16BE"; Encoding = (New-Object System.Text.UnicodeEncoding($true, $true, $true)); PreambleLength = 2 }
    )
    $gddManagedPattern = '(?ms)<!-- GEURTS-GDD-MANIFEST-BEGIN version="0\.7\.0" -->\r?\n.*?<!-- GEURTS-GDD-MANIFEST-END -->'
    foreach ($encodingCase in $gddEncodingCases) {
        $encodingProject = New-TestProject -Parent $testRoot -Name $encodingCase.Name
        $encodingSetup = Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $encodingProject, "-IncludeGameDesignScaffolding")
        if ($encodingSetup.Code -ne 0) { throw "Unable to prepare $($encodingCase.Label) GDD encoding fixture." }
        $encodingManifestPath = Join-Path $encodingProject "Docs/GameDesign/GameDesignManifest.md"
        $encodingDesignPath = Join-Path $encodingProject "Docs/GameDesign/Encoding.md"
        Write-Utf8 -Path $encodingDesignPath -Text "geurtsId: encoding-case`npurpose: Encoding regression input`n# Encoding`n"
        $encodingBaseText = [System.IO.File]::ReadAllText($encodingManifestPath)
        $encodingBaseRegion = [regex]::Match($encodingBaseText, $gddManagedPattern)
        if (-not $encodingBaseRegion.Success) { throw "Unable to locate GDD managed region for $($encodingCase.Label)." }
        $encodingPrefixText = $encodingBaseText.Substring(0, $encodingBaseRegion.Index).Replace("`n", "`r`n") + "<!-- exact user prefix -->`n"
        $encodingRegionText = ((($encodingBaseRegion.Value -replace "`r`n", "`n") -replace "`r", "`n").Replace("`n", "`r`n"))
        $encodingSuffixText = "`r`n<!-- exact user suffix -->`n" + $primaryGddBlock + $importedGddBlock + $encodingBaseText.Substring($encodingBaseRegion.Index + $encodingBaseRegion.Length)
        [System.IO.File]::WriteAllText($encodingManifestPath, ($encodingPrefixText + $encodingRegionText + $encodingSuffixText), $encodingCase.Encoding)
        $encodingRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $encodingProject)
        $encodingAfterBytes = [System.IO.File]::ReadAllBytes($encodingManifestPath)
        $encodingExpectedPrefix = [byte[]](@($encodingCase.Encoding.GetPreamble()) + @($encodingCase.Encoding.GetBytes($encodingPrefixText)))
        $encodingExpectedSuffix = [byte[]]($encodingCase.Encoding.GetBytes($encodingSuffixText))
        $encodingAfterText = $encodingCase.Encoding.GetString($encodingAfterBytes, [int]$encodingCase.PreambleLength, $encodingAfterBytes.Length - [int]$encodingCase.PreambleLength)
        $encodingAfterRegion = [regex]::Match($encodingAfterText, $gddManagedPattern)
        Assert-True ($encodingRun.Code -eq 0 -and $encodingRun.Output.Contains("Updated: Docs/GameDesign/GameDesignManifest.md") -and (Test-BytePrefix -Bytes $encodingAfterBytes -Expected $encodingExpectedPrefix) -and (Test-ByteSuffix -Bytes $encodingAfterBytes -Expected $encodingExpectedSuffix) -and $encodingAfterRegion.Success -and (Test-CrLfOnly -Text $encodingAfterRegion.Value)) "GDD $($encodingCase.Label) update preserves exact outside-region bytes, BOM/encoding, mixed outer newlines, and CRLF region convention"
        Assert-True ($encodingAfterText.Contains($primaryGddBlock) -and $encodingAfterText.Contains($importedGddBlock) -and $encodingAfterRegion.Value.IndexOf('GEURTS-GDD-PRIMARY', [System.StringComparison]::Ordinal) -lt 0) "GDD $($encodingCase.Label) maintenance preserves primary and imported-document routing outside the managed table"
    }

    foreach ($invalidEncodingCase in @(
        @{ Name = "gdd-invalid-utf8"; Label = "invalid BOM-less UTF-8"; Bytes = [byte[]](0x23, 0x20, 0xC3, 0x28, 0x0A); Pattern = '(?i)invalid text encoding' },
        @{ Name = "gdd-utf32"; Label = "UTF-32"; Bytes = [byte[]](0xFF, 0xFE, 0x00, 0x00, 0x41, 0x00, 0x00, 0x00); Pattern = '(?i)unsupported UTF-32' }
    )) {
        $invalidEncodingProject = New-TestProject -Parent $testRoot -Name $invalidEncodingCase.Name
        $invalidDesignRoot = Join-Path $invalidEncodingProject "Docs/GameDesign"
        New-Item -ItemType Directory -Path $invalidDesignRoot -Force | Out-Null
        $invalidEncodingManifest = Join-Path $invalidDesignRoot "GameDesignManifest.md"
        [System.IO.File]::WriteAllBytes($invalidEncodingManifest, $invalidEncodingCase.Bytes)
        $invalidEncodingBefore = Get-FileSha -Path $invalidEncodingManifest
        $invalidEncodingRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $invalidEncodingProject)
        Assert-True ($invalidEncodingRun.Code -eq 2 -and (Get-FileSha -Path $invalidEncodingManifest) -eq $invalidEncodingBefore -and $invalidEncodingRun.Output -match $invalidEncodingCase.Pattern) "GDD $($invalidEncodingCase.Label) conflicts without mutation or silent re-encoding"
    }

    $gddConcurrentProject = New-TestProject -Parent $testRoot -Name "gdd-concurrent-byte-drift"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $gddConcurrentProject, "-IncludeGameDesignScaffolding") | Out-Null
    Write-Utf8 -Path (Join-Path $gddConcurrentProject "Docs/GameDesign/Concurrent.md") -Text "geurtsId: gdd-concurrent`n# Concurrent`n"
    $gddConcurrentManifest = Join-Path $gddConcurrentProject "Docs/GameDesign/GameDesignManifest.md"
    $gddConcurrentText = [System.IO.File]::ReadAllText($gddConcurrentManifest)
    $gddConcurrentBomEncoding = New-Object System.Text.UTF8Encoding($true, $true)
    $gddConcurrentBarrier = Join-Path $testRoot "barrier-gdd-byte-drift"
    $gddConcurrentProcess = Start-TestScriptAtBarrier -Path $gddScript -Arguments @("-ProjectRoot", $gddConcurrentProject) -BarrierPath $gddConcurrentBarrier -TargetPath $gddConcurrentManifest
    Wait-TestScriptBarrier -Run $gddConcurrentProcess
    [System.IO.File]::WriteAllText($gddConcurrentManifest, $gddConcurrentText, $gddConcurrentBomEncoding)
    $gddConcurrentHash = Get-FileSha -Path $gddConcurrentManifest
    $gddConcurrentRun = Complete-TestScriptBarrier -Run $gddConcurrentProcess
    $gddConcurrentBytes = [System.IO.File]::ReadAllBytes($gddConcurrentManifest)
    Assert-True ($gddConcurrentRun.Code -eq 2 -and (Get-FileSha -Path $gddConcurrentManifest) -eq $gddConcurrentHash -and $gddConcurrentBytes.Length -ge 3 -and $gddConcurrentBytes[0] -eq 0xEF -and $gddConcurrentBytes[1] -eq 0xBB -and $gddConcurrentBytes[2] -eq 0xBF -and $gddConcurrentRun.Output -match '(?i)manifest bytes changed.*concurrent edit was preserved') "GDD raw-byte guard detects an encoding-only concurrent edit and preserves it"

    $gddParentSwapProject = New-TestProject -Parent $testRoot -Name "gdd-parent-reparse-swap"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $gddParentSwapProject, "-IncludeGameDesignScaffolding") | Out-Null
    Write-Utf8 -Path (Join-Path $gddParentSwapProject "Docs/GameDesign/Swap.md") -Text "geurtsId: gdd-parent-swap`n# Swap`n"
    $gddParentSwapTarget = Join-Path $gddParentSwapProject "Docs/GameDesign/GameDesignManifest.md"
    $gddParentSwapBarrier = Join-Path $testRoot "barrier-gdd-parent-swap"
    $gddParentSwapProcess = Start-TestScriptAtBarrier -Path $gddScript -Arguments @("-ProjectRoot", $gddParentSwapProject) -BarrierPath $gddParentSwapBarrier -TargetPath $gddParentSwapTarget
    $gddParentSwapDirectory = Join-Path $gddParentSwapProject "Docs/GameDesign"
    $gddParentSwapSaved = Join-Path $gddParentSwapProject "Docs/GameDesign-before-swap"
    $gddParentSwapOutside = Join-Path $testRoot "gdd-parent-swap-outside"
    $gddParentSwapSentinel = Join-Path $gddParentSwapOutside "user-sentinel.txt"
    $gddParentSwapRun = $null
    try {
        Wait-TestScriptBarrier -Run $gddParentSwapProcess
        New-Item -ItemType Directory -Path $gddParentSwapOutside | Out-Null
        Write-Utf8 -Path $gddParentSwapSentinel -Text "Outside GDD content must remain untouched.`n"
        $gddParentSwapSentinelHash = Get-FileSha -Path $gddParentSwapSentinel
        Move-Item -LiteralPath $gddParentSwapDirectory -Destination $gddParentSwapSaved
        New-Item -ItemType Junction -Path $gddParentSwapDirectory -Target $gddParentSwapOutside | Out-Null
        $gddParentSwapRun = Complete-TestScriptBarrier -Run $gddParentSwapProcess
        $gddParentSwapProcess = $null
    }
    finally {
        Stop-TestScriptBarrier -Run $gddParentSwapProcess
        Restore-TestDirectorySwap -Path $gddParentSwapDirectory -ExpectedTarget $gddParentSwapOutside -SavedPath $gddParentSwapSaved
    }
    $gddParentSwapDebris = @(
        @(Get-ChildItem -LiteralPath $gddParentSwapProject -Filter ".ggf-*" -Force -File -ErrorAction SilentlyContinue)
        @(Get-ChildItem -LiteralPath $gddParentSwapDirectory -Filter ".ggf-*" -Force -File -ErrorAction SilentlyContinue)
    )
    Assert-True ($gddParentSwapRun -and $gddParentSwapRun.Code -eq 2 -and $gddParentSwapRun.Output -match '(?i)reparse point immediately before promotion' -and (Get-FileSha -Path $gddParentSwapSentinel) -eq $gddParentSwapSentinelHash -and -not (Test-Path -LiteralPath (Join-Path $gddParentSwapOutside "GameDesignManifest.md")) -and $gddParentSwapDebris.Count -eq 0) "GDD final guard rejects a GameDesign parent junction without external writes or root/design transaction debris"

    # Deterministic GDD add, metadata preservation, move detection, removal, and duplicate safety.
    $gddProject = New-TestProject -Parent $testRoot -Name "gdd"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $gddProject, "-IncludeGameDesignScaffolding") | Out-Null
    $designDoc = Join-Path $gddProject "Docs/GameDesign/Core.md"
    Write-Utf8 -Path $designDoc -Text "---`ngeurtsId: core-design`npurpose: Defines approved core play.`nstatus: Active`nversion: 1.0.0`nauthority: Primary`ntags: gameplay, core`n---`n# Core`n"
    $gddAdd = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    $gddManifestPath = Join-Path $gddProject "Docs/GameDesign/GameDesignManifest.md"
    $gddText = [System.IO.File]::ReadAllText($gddManifestPath)
    Assert-True ($gddAdd.Code -eq 0 -and $gddAdd.Output.Contains("Added: Docs/GameDesign/Core.md") -and $gddText.Contains("core-design") -and $gddText.Contains("Defines approved core play.")) "GDD document metadata is added without filename inference"
    $gddUnchanged = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    Assert-True ($gddUnchanged.Code -eq 0 -and $gddUnchanged.Output.Contains("Unchanged: Docs/GameDesign/Core.md")) "GDD rerun reports unchanged documents deterministically"
    $corePrimaryBlock = $primaryGddBlock.Replace('Docs/GameDesign/Encoding.md', 'Docs/GameDesign/Core.md')
    Write-Utf8 -Path $gddManifestPath -Text ([System.IO.File]::ReadAllText($gddManifestPath) + "`n" + $corePrimaryBlock)
    Write-Utf8 -Path $designDoc -Text ([System.IO.File]::ReadAllText($designDoc).Replace('authority: Primary', 'authority: Supporting'))
    $primaryPointerRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    $primaryPointerText = [System.IO.File]::ReadAllText($gddManifestPath)
    Assert-True ($primaryPointerRun.Code -eq 0 -and $primaryPointerText.Contains($corePrimaryBlock) -and $primaryPointerText.Contains('| Supporting |') -and [regex]::Matches($primaryPointerText, 'GEURTS-GDD-PRIMARY-BEGIN').Count -eq 1) "Explicit primary pointer survives ordinary maintenance when source metadata supplies a different table authority"
    $primaryPointerHash = Get-FileSha -Path $gddManifestPath
    $primaryPointerAgain = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    Assert-True ($primaryPointerAgain.Code -eq 0 -and (Get-FileSha -Path $gddManifestPath) -ceq $primaryPointerHash) "Maintenance with an explicit primary pointer remains byte-idempotent"
    $renamedDoc = Join-Path $gddProject "Docs/GameDesign/CoreRenamed.md"
    Move-Item -LiteralPath $designDoc -Destination $renamedDoc
    $gddRename = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    Assert-True ($gddRename.Code -eq 0 -and $gddRename.Output.Contains("Renamed: Docs/GameDesign/CoreRenamed.md")) "GDD same-directory rename is reported distinctly"
    Assert-True ([System.IO.File]::ReadAllText($gddManifestPath).Contains($corePrimaryBlock)) "Generic discovery does not silently retarget an explicit primary pointer after a rename"
    $movedDoc = Join-Path $gddProject "Docs/GameDesign/Systems/CoreRenamed.md"
    New-Item -ItemType Directory -Path (Split-Path -Parent $movedDoc) | Out-Null
    Move-Item -LiteralPath $renamedDoc -Destination $movedDoc
    $gddMove = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    $gddMovedText = [System.IO.File]::ReadAllText($gddManifestPath)
    Assert-True ($gddMove.Code -eq 0 -and $gddMove.Output.Contains("Moved: Docs/GameDesign/Systems/CoreRenamed.md") -and $gddMovedText.Contains("Docs/GameDesign/Systems/CoreRenamed.md") -and $gddMovedText.Contains("core-design")) "GDD move preserves stable ID and metadata"
    Remove-Item -LiteralPath $movedDoc -Force
    $gddRemove = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    Assert-True ($gddRemove.Code -eq 0 -and -not [System.IO.File]::ReadAllText($gddManifestPath).Contains("core-design")) "Removed GDD record is deleted after same-run rename matching"
    Assert-True ([System.IO.File]::ReadAllText($gddManifestPath).Contains($corePrimaryBlock)) "Generic discovery preserves an explicit primary selection after its source is removed for a later missing-primary report"

    $importedDoc = Join-Path $gddProject "Docs/GameDesign/Imported.md"
    Write-Utf8 -Path $importedDoc -Text "# Imported design notes`n"
    $gddImport = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject, "-ImportedPath", "Docs/GameDesign/Imported.md")
    Assert-True ($gddImport.Code -eq 0 -and $gddImport.Output.Contains("Imported: Docs/GameDesign/Imported.md")) "Explicit importer signal produces a distinct imported event"
    Write-Utf8 -Path (Join-Path $gddProject "Docs/GameDesign/.hidden.md") -Text "# Hidden`n"
    Write-Utf8 -Path (Join-Path $gddProject "Docs/GameDesign/.private/Hidden.md") -Text "# Hidden below hidden directory`n"
    Write-Utf8 -Path (Join-Path $gddProject "Docs/GameDesign/Unsupported.txt") -Text "Unsupported design payload`n"
    $gddFiltered = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    $gddFilteredText = [System.IO.File]::ReadAllText($gddManifestPath)
    Assert-True ($gddFiltered.Code -eq 0 -and $gddFiltered.Output.Contains("Unsupported: Docs/GameDesign/Unsupported.txt") -and -not $gddFilteredText.Contains(".hidden.md") -and -not $gddFilteredText.Contains(".private/Hidden.md") -and -not $gddFilteredText.Contains("Unsupported.txt")) "Hidden and unsupported files are excluded with explicit reporting"
    $wrongPathManifest = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject, "-ManifestPath", "Docs/Other/GameDesignManifest.md")
    Assert-True ($wrongPathManifest.Code -eq 2 -and $wrongPathManifest.Output.Contains("Conflicted:") -and $wrongPathManifest.Output.Contains("required project path")) "GDD maintainer refuses a manifest outside the required project path"
    $malformedGddProject = New-TestProject -Parent $testRoot -Name "gdd-malformed"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $malformedGddProject, "-IncludeGameDesignScaffolding") | Out-Null
    $malformedGddManifest = Join-Path $malformedGddProject "Docs/GameDesign/GameDesignManifest.md"
    $malformedGddText = [System.IO.File]::ReadAllText($malformedGddManifest).Replace('<!-- GEURTS-GDD-MANIFEST-END -->', "| malformed | row |`n<!-- GEURTS-GDD-MANIFEST-END -->")
    Write-Utf8 -Path $malformedGddManifest -Text $malformedGddText
    $malformedGddHash = Get-FileSha -Path $malformedGddManifest
    $malformedGddRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $malformedGddProject)
    Assert-True ($malformedGddRun.Code -eq 2 -and (Get-FileSha -Path $malformedGddManifest) -eq $malformedGddHash) "Malformed managed GDD records conflict without discarding user routing metadata"
    $futureGddProject = New-TestProject -Parent $testRoot -Name "gdd-future"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $futureGddProject, "-IncludeGameDesignScaffolding") | Out-Null
    $futureGddManifest = Join-Path $futureGddProject "Docs/GameDesign/GameDesignManifest.md"
    Write-Utf8 -Path $futureGddManifest -Text ([System.IO.File]::ReadAllText($futureGddManifest).Replace('GEURTS-GDD-MANIFEST-BEGIN version="0.7.0"', 'GEURTS-GDD-MANIFEST-BEGIN version="9.0.0"'))
    $futureGddHash = Get-FileSha -Path $futureGddManifest
    $futureGddRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $futureGddProject)
    Assert-True ($futureGddRun.Code -eq 2 -and (Get-FileSha -Path $futureGddManifest) -eq $futureGddHash -and $futureGddRun.Output.Contains("no downgrade")) "Future GDD manifest region is never downgraded"
    $invalidMetadataProject = New-TestProject -Parent $testRoot -Name "gdd-invalid-metadata"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $invalidMetadataProject, "-IncludeGameDesignScaffolding") | Out-Null
    Write-Utf8 -Path (Join-Path $invalidMetadataProject "Docs/GameDesign/BadVersion.md") -Text "geurtsId: bad-version`nversion: definitely-not-semver`n# Invalid version`n"
    $invalidMetadataManifest = Join-Path $invalidMetadataProject "Docs/GameDesign/GameDesignManifest.md"
    $invalidMetadataHash = Get-FileSha -Path $invalidMetadataManifest
    $invalidMetadataRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $invalidMetadataProject)
    Assert-True ($invalidMetadataRun.Code -eq 2 -and (Get-FileSha -Path $invalidMetadataManifest) -eq $invalidMetadataHash) "Invalid explicit GDD metadata is rejected before rendering"
    $lockedGddProject = New-TestProject -Parent $testRoot -Name "gdd-locked"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $lockedGddProject, "-IncludeGameDesignScaffolding") | Out-Null
    $ownedLockPath = Join-Path $lockedGddProject ".ggf-manifest.lock"
    $ownedLock = New-Object System.IO.FileStream($ownedLockPath, [System.IO.FileMode]::OpenOrCreate, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
    try {
        $lockedGddRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $lockedGddProject)
        Assert-True ($lockedGddRun.Code -eq 2 -and (Test-Path -LiteralPath $ownedLockPath -PathType Leaf)) "Failed GDD lock acquisition does not delete another operation's lock"
    }
    finally {
        $ownedLock.Dispose()
        Remove-Item -LiteralPath $ownedLockPath -Force -ErrorAction SilentlyContinue
    }
    $unlockedSentinelProject = New-TestProject -Parent $testRoot -Name "gdd-unlocked-lock-sentinel"
    Invoke-TestScript -Path $manageScript -Arguments @("-ProjectRoot", $unlockedSentinelProject, "-IncludeGameDesignScaffolding") | Out-Null
    $unlockedSentinelPath = Join-Path $unlockedSentinelProject ".ggf-manifest.lock"
    [System.IO.File]::WriteAllBytes($unlockedSentinelPath, [byte[]](0x00, 0xFF, 0x10, 0x42, 0x0D, 0x0A))
    $unlockedSentinelHash = Get-FileSha -Path $unlockedSentinelPath
    $unlockedSentinelRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $unlockedSentinelProject)
    $unlockedSentinelDebris = @(Get-ChildItem -LiteralPath $unlockedSentinelProject -Filter ".ggf-*" -Force -File | Where-Object { $_.FullName -cne $unlockedSentinelPath })
    Assert-True ($unlockedSentinelRun.Code -eq 2 -and $unlockedSentinelRun.Output -match '(?i)lock path already exists or could not be acquired.*preserved' -and (Get-FileSha -Path $unlockedSentinelPath) -eq $unlockedSentinelHash -and $unlockedSentinelDebris.Count -eq 0) "Pre-existing unlocked GDD lock sentinel conflicts, remains byte-identical, and leaves no tool-owned debris"
    Write-Utf8 -Path (Join-Path $gddProject "Docs/GameDesign/One.md") -Text "geurtsId: duplicate-id`n# One`n"
    Write-Utf8 -Path (Join-Path $gddProject "Docs/GameDesign/Two.md") -Text "geurtsId: duplicate-id`n# Two`n"
    $beforeDuplicate = Get-FileSha -Path $gddManifestPath
    $duplicateRun = Invoke-TestScript -Path $gddScript -Arguments @("-ProjectRoot", $gddProject)
    Assert-True ($duplicateRun.Code -eq 2 -and $duplicateRun.Output.Contains("Conflicted:") -and (Get-FileSha -Path $gddManifestPath) -eq $beforeDuplicate) "Duplicate GDD identifiers report conflict and preserve the last valid manifest"

    # Definition consumption, profile selection, idempotence, and path collision safety.
    # The production contract fixes the full profile at 76 entries. Use the source definition
    # for behavior tests.
    $definitionPath = Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureDefinition.json"
    $folderTechniqueContractText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureTechnique.md"))
    $folderDefinitionContract = Get-Content -LiteralPath $definitionPath -Raw | ConvertFrom-Json
    $folderToolContractText = [System.IO.File]::ReadAllText($folderScript)
    $managerToolContractText = [System.IO.File]::ReadAllText($manageScript)
    Assert-True ($folderTechniqueContractText -match '(?im)^\*\*Version:\*\*\s*0\.16\.6\s*$' -and [string]$folderDefinitionContract.definitionVersion -ceq "0.13.0" -and [string]$folderDefinitionContract.packageVersion -ceq "0.61.1" -and $folderToolContractText.Contains('[string]$definition.definitionVersion -ne "0.13.0"') -and $managerToolContractText.Contains('[string]$definition.definitionVersion -ne "0.13.0"')) "Folder technique, definition, creator, and native manager agree on definition v0.13.0 in package v0.61.1"

    $versionMismatchAuthority = Join-Path $testRoot "folder-version-mismatch-authority"
    New-Item -ItemType Directory -Path $versionMismatchAuthority | Out-Null
    $versionMismatchDefinitionPath = Join-Path $versionMismatchAuthority "GeurtsFolderStructureDefinition.json"
    Copy-Item -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureTechnique.md") -Destination (Join-Path $versionMismatchAuthority "GeurtsFolderStructureTechnique.md")
    $versionMismatchDefinition = Get-Content -LiteralPath $definitionPath -Raw | ConvertFrom-Json
    $versionMismatchDefinition.definitionVersion = "0.8.0"
    Write-Utf8 -Path $versionMismatchDefinitionPath -Text ($versionMismatchDefinition | ConvertTo-Json -Depth 12)
    $versionMismatchProject = New-TestProject -Parent $testRoot -Name "folder-version-mismatch-project"
    $versionMismatchRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $versionMismatchProject, "-DefinitionPath", $versionMismatchDefinitionPath)
    Assert-True ($versionMismatchRun.Code -ne 0 -and $versionMismatchRun.Output.Contains("Folder definition version must be 0.13.0") -and -not (Test-Path -LiteralPath (Join-Path $versionMismatchProject "Assets/_Project"))) "Folder creator rejects a v0.8.0 definition before project mutation"

    $earlyExitProject = New-TestProject -Parent $testRoot -Name "barrier-early-exit-project"
    $earlyExitBarrierPath = Join-Path $testRoot "barrier-expected-early-exit"
    $earlyExitRun = Start-TestScriptAtBarrier -Path $folderScript -Arguments @("-ProjectRoot", $earlyExitProject, "-DefinitionPath", $versionMismatchDefinitionPath) -BarrierPath $earlyExitBarrierPath -TargetPath (Join-Path $earlyExitProject "Assets/_Project")
    $earlyExitMessage = $null
    try { Wait-TestScriptBarrier -Run $earlyExitRun }
    catch { $earlyExitMessage = $_.Exception.Message }
    finally { Stop-TestScriptBarrier -Run $earlyExitRun }
    Assert-True ($earlyExitMessage -match '(?i)exited before its write boundary.*Folder definition version must be 0\.13\.0' -and $earlyExitMessage -notmatch '(?i)No process is associated|disposed') "Barrier harness preserves the primary early-exit error without double wait or dispose"

    $folderProject = New-TestProject -Parent $testRoot -Name "folders"
    $folderRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $folderProject, "-DefinitionPath", $definitionPath)
    Assert-True ($folderRun.Code -eq 0 -and $folderRun.Output.Contains("Skipped: .github") -and $folderRun.Output.Contains("definition 0.13.0") -and (Test-Path -LiteralPath (Join-Path $folderProject "Assets/_Project") -PathType Container) -and -not (Test-Path -LiteralPath (Join-Path $folderProject "GeurtsGameForgeCommandments"))) "Folder tool consumes the exact definition while never creating the reserved documentation container"
    $fullTemplatePaths = @($folderDefinitionContract.managedFolders | Where-Object { @($_.automation.creationProfiles) -contains "full-project-structure" } | ForEach-Object { [string]$_.path } | Sort-Object)
    $createdTemplatePaths = @(Get-ChildItem -LiteralPath $folderProject -Directory -Recurse -Force | ForEach-Object { $_.FullName.Substring($folderProject.Length + 1).Replace('\', '/') } | Sort-Object)
    Assert-True ($fullTemplatePaths.Count -eq 76 -and $createdTemplatePaths.Count -eq 76 -and ($createdTemplatePaths -join "|") -ceq ($fullTemplatePaths -join "|")) "Fresh folder creation produces exactly the expanded 76-folder full profile"
    $newTemplatePaths = @(
        "SourceAssets", "SourceAssets/Art", "SourceAssets/Audio",
        "Assets/_Project/Localization", "Assets/_Project/Settings/Input", "Assets/_Project/Settings/Rendering",
        "Assets/_Project/Scripts/Testing/EditMode", "Assets/_Project/Scripts/Testing/PlayMode", "Assets/_Project/Testing/Fixtures",
        "Tools/Build", "Tools/Validation", "Assets/_Project/Data/Definitions", "Assets/_Project/Data/Tables",
        "Assets/_Project/Prefabs/Entities", "Assets/_Project/Prefabs/Gameplay"
    )
    $missingReusableFolders = @($newTemplatePaths | Where-Object { -not (Test-Path -LiteralPath (Join-Path $folderProject $_) -PathType Container) })
    Assert-True ($missingReusableFolders.Count -eq 0) "Reusable source, localization, configuration, tests, data, prefab and tooling folders are available in a fresh project"
    $legacyGenrePaths = @(
        "Assets/_Project/Data/Items", "Assets/_Project/Data/Enemies", "Assets/_Project/Data/Weapons", "Assets/_Project/Data/Progression",
        "Assets/_Project/Prefabs/Characters", "Assets/_Project/Prefabs/Weapons"
    )
    $createdGenreFolders = @($legacyGenrePaths | Where-Object { Test-Path -LiteralPath (Join-Path $folderProject $_) })
    Assert-True ($createdGenreFolders.Count -eq 0) "Fresh template creation does not assume items, enemies, weapons, characters or progression"
    $unexpectedUnityFiles = @(Get-ChildItem -LiteralPath $folderProject -File -Recurse -Force | Where-Object { $_.Extension -in @(".unity", ".asmdef", ".meta") })
    Assert-True ($unexpectedUnityFiles.Count -eq 0) "Host-side folder creation does not author Unity scenes, assembly definitions or metadata"
    $folderAgain = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $folderProject, "-DefinitionPath", $definitionPath)
    Assert-True ($folderAgain.Code -eq 0 -and $folderAgain.Output.Contains("Exists") -and $folderAgain.Output -notmatch '(?m)^Created: ') "Repeating expanded folder creation creates nothing"

    # Reconstruct the previous 67-folder layout without invoking an obsolete creator or migrating content.
    $legacyFolderProject = New-TestProject -Parent $testRoot -Name "folders-existing-legacy-template"
    $legacyTemplatePaths = @($fullTemplatePaths | Where-Object { $_ -notin $newTemplatePaths }) + $legacyGenrePaths
    Assert-True ($legacyTemplatePaths.Count -eq 67) "Preservation fixture represents the previous 67-folder template"
    foreach ($legacyPath in $legacyTemplatePaths) {
        New-Item -ItemType Directory -Path (Join-Path $legacyFolderProject $legacyPath) -Force | Out-Null
    }
    $legacyPreservedFiles = @()
    $legacyPreservedDirectories = @()
    $legacyCreatedUtc = [DateTime]::Parse("2022-02-03T04:05:06Z").ToUniversalTime()
    $legacyWrittenUtc = [DateTime]::Parse("2023-03-04T05:06:07Z").ToUniversalTime()
    foreach ($legacyPath in $legacyGenrePaths) {
        $legacyDirectory = Join-Path $legacyFolderProject $legacyPath
        $legacySentinel = Join-Path $legacyDirectory "user-owned.asset"
        [System.IO.File]::WriteAllBytes($legacySentinel, [byte[]](0x00, 0xFF, 0x42, 0x0D, 0x0A, 0x10))
        Write-Utf8 -Path ($legacySentinel + ".meta") -Text "fileFormatVersion: 2`r`nguid: 11111111111111111111111111111111`r`n"
        Write-Utf8 -Path ($legacyDirectory + ".meta") -Text "fileFormatVersion: 2`r`nguid: 22222222222222222222222222222222`r`nfolderAsset: yes`r`n"
        foreach ($preservedPath in @($legacySentinel, ($legacySentinel + ".meta"), ($legacyDirectory + ".meta"))) {
            [System.IO.File]::SetCreationTimeUtc($preservedPath, $legacyCreatedUtc)
            [System.IO.File]::SetLastWriteTimeUtc($preservedPath, $legacyWrittenUtc)
            $legacyPreservedFiles += [pscustomobject]@{
                Path = $preservedPath
                Hash = Get-FileSha -Path $preservedPath
                CreatedTicks = [System.IO.File]::GetCreationTimeUtc($preservedPath).Ticks
                WrittenTicks = [System.IO.File]::GetLastWriteTimeUtc($preservedPath).Ticks
            }
        }
        $legacyPreservedDirectories += [pscustomobject]@{
            Path = $legacyDirectory
            WrittenTicks = [System.IO.Directory]::GetLastWriteTimeUtc($legacyDirectory).Ticks
        }
    }
    $legacyUpgradeRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $legacyFolderProject, "-DefinitionPath", $definitionPath)
    $legacyUpgradeMissing = @($fullTemplatePaths | Where-Object { -not (Test-Path -LiteralPath (Join-Path $legacyFolderProject $_) -PathType Container) })
    Assert-True ($legacyUpgradeRun.Code -eq 0 -and $legacyUpgradeMissing.Count -eq 0) "Updating a project with the old template creates the complete new profile without moving old content"
    $legacyUpgradeAgain = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $legacyFolderProject, "-DefinitionPath", $definitionPath)
    Assert-True ($legacyUpgradeAgain.Code -eq 0 -and $legacyUpgradeAgain.Output -notmatch '(?m)^Created: ') "Repeating the old-template update creates nothing and performs no migration"
    $changedLegacyFiles = @($legacyPreservedFiles | Where-Object {
        -not (Test-Path -LiteralPath $_.Path -PathType Leaf) -or (Get-FileSha -Path $_.Path) -cne $_.Hash -or
        [System.IO.File]::GetCreationTimeUtc($_.Path).Ticks -ne $_.CreatedTicks -or [System.IO.File]::GetLastWriteTimeUtc($_.Path).Ticks -ne $_.WrittenTicks
    })
    $changedLegacyDirectories = @($legacyPreservedDirectories | Where-Object {
        -not (Test-Path -LiteralPath $_.Path -PathType Container) -or [System.IO.Directory]::GetLastWriteTimeUtc($_.Path).Ticks -ne $_.WrittenTicks
    })
    Assert-True ($changedLegacyFiles.Count -eq 0 -and $changedLegacyDirectories.Count -eq 0) "Removed template entries retain existing directories, binary asset bytes, file and folder metadata, and original timestamps"

    $rawCandidateProject = New-TestProject -Parent $testRoot -Name "unselected-project-root-folder-definition"
    $rawCandidateDirectory = Join-Path $rawCandidateProject "GeurtsTechniques"
    New-Item -ItemType Directory -Path $rawCandidateDirectory | Out-Null
    $rawCandidatePath = Join-Path $rawCandidateDirectory "GeurtsFolderStructureDefinition.json"
    $rawCandidate = Get-Content -LiteralPath $definitionPath -Raw | ConvertFrom-Json
    @($rawCandidate.managedFolders | Where-Object { [string]$_.path -ceq "Builds" })[0].path = "MaliciousRawCandidate"
    Write-Utf8 -Path $rawCandidatePath -Text ($rawCandidate | ConvertTo-Json -Depth 12)
    $rawCandidateRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $rawCandidateProject)
    Assert-True ($rawCandidateRun.Code -eq 0 -and (Test-Path -LiteralPath (Join-Path $rawCandidateProject "Assets/_Project") -PathType Container) -and -not (Test-Path -LiteralPath (Join-Path $rawCandidateProject "MaliciousRawCandidate"))) "Folder tool never consumes an unselected raw project-root definition; only package resolution or explicit -DefinitionPath can select one"

    $folderDirectorySwapProject = New-TestProject -Parent $testRoot -Name "folder-directory-parent-swap"
    $folderDirectorySwapTarget = Join-Path $folderDirectorySwapProject "Assets/_Project"
    $folderDirectorySwapBarrier = Join-Path $testRoot "barrier-folder-directory-swap"
    $folderDirectorySwapProcess = Start-TestScriptAtBarrier -Path $folderScript -Arguments @("-ProjectRoot", $folderDirectorySwapProject, "-DefinitionPath", $definitionPath) -BarrierPath $folderDirectorySwapBarrier -TargetPath $folderDirectorySwapTarget
    $folderDirectorySwapAssets = Join-Path $folderDirectorySwapProject "Assets"
    $folderDirectorySwapSaved = Join-Path $folderDirectorySwapProject "Assets-before-swap"
    $folderDirectorySwapOutside = Join-Path $testRoot "folder-directory-swap-outside"
    $folderDirectorySwapSentinel = Join-Path $folderDirectorySwapOutside "user-sentinel.txt"
    $folderDirectorySwapRun = $null
    try {
        Wait-TestScriptBarrier -Run $folderDirectorySwapProcess
        New-Item -ItemType Directory -Path $folderDirectorySwapOutside | Out-Null
        Write-Utf8 -Path $folderDirectorySwapSentinel -Text "Outside folder content must remain untouched.`n"
        $folderDirectorySwapSentinelHash = Get-FileSha -Path $folderDirectorySwapSentinel
        Move-Item -LiteralPath $folderDirectorySwapAssets -Destination $folderDirectorySwapSaved
        New-Item -ItemType Junction -Path $folderDirectorySwapAssets -Target $folderDirectorySwapOutside | Out-Null
        $folderDirectorySwapRun = Complete-TestScriptBarrier -Run $folderDirectorySwapProcess
        $folderDirectorySwapProcess = $null
    }
    finally {
        Stop-TestScriptBarrier -Run $folderDirectorySwapProcess
        Restore-TestDirectorySwap -Path $folderDirectorySwapAssets -ExpectedTarget $folderDirectorySwapOutside -SavedPath $folderDirectorySwapSaved
    }
    Assert-True ($folderDirectorySwapRun -and $folderDirectorySwapRun.Code -ne 0 -and $folderDirectorySwapRun.Output -match '(?i)reparse point or changed path.*Assets/_Project' -and (Get-FileSha -Path $folderDirectorySwapSentinel) -eq $folderDirectorySwapSentinelHash -and -not (Test-Path -LiteralPath (Join-Path $folderDirectorySwapOutside "_Project"))) "Folder tool rejects a parent junction introduced at the final directory boundary without creating descendants outside the project"
    $wrongOwnerRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $folderProject, "-DefinitionPath", $definitionPath, "-Profile", "native-entry")
    Assert-True ($wrongOwnerRun.Code -ne 0 -and $wrongOwnerRun.Output.Contains("Invalid: native-entry") -and $wrongOwnerRun.Output.Contains("owned by 'native-entry-manager'")) "Folder tool cannot execute a profile owned by another automation"
    $tamperedAuthority = New-TestProject -Parent $testRoot -Name "tampered-folder-authority"
    Copy-Item -LiteralPath $definitionPath -Destination (Join-Path $tamperedAuthority "GeurtsFolderStructureDefinition.json")
    Copy-Item -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureTechnique.md") -Destination (Join-Path $tamperedAuthority "GeurtsFolderStructureTechnique.md")
    $tamperedDefinitionPath = Join-Path $tamperedAuthority "GeurtsFolderStructureDefinition.json"
    $tamperedDefinition = Get-Content -LiteralPath $tamperedDefinitionPath -Raw | ConvertFrom-Json
    foreach ($folder in @($tamperedDefinition.managedFolders)) {
        if ($folder.path -in @("Builds", "Tools")) {
            $folder.automation.owner = "native-entry-manager"
            $folder.automation.creationProfiles = @("native-entry")
        }
        elseif ($folder.path -in @(".github", ".github/instructions")) {
            $folder.automation.owner = "folder-structure-tool"
            $folder.automation.creationProfiles = @("full-project-structure")
        }
    }
    Write-Utf8 -Path $tamperedDefinitionPath -Text ($tamperedDefinition | ConvertTo-Json -Depth 12)
    $tamperedProject = New-TestProject -Parent $testRoot -Name "tampered-folder-project"
    $tamperedRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $tamperedProject, "-DefinitionPath", $tamperedDefinitionPath)
    Assert-True ($tamperedRun.Code -ne 0 -and $tamperedRun.Output.Contains("Invalid: Builds") -and @((Get-ChildItem -LiteralPath $tamperedProject -Force).Name | Where-Object { $_ -notin @("Assets", "Packages", "ProjectSettings") }).Count -eq 0) "Folder tool rejects count-preserving profile-scope tampering before mutation"
    $reservedDefinitionPath = Join-Path $tamperedAuthority "ReservedFolderDefinition.json"
    $reservedDefinition = Get-Content -LiteralPath $definitionPath -Raw | ConvertFrom-Json
    $reservedFixture = @($reservedDefinition.managedFolders | Where-Object { [string]$_.path -ceq "Builds" })[0]
    $reservedFixture.path = "GeurtsGameForgeCommandments"
    $reservedFixture.parent = $null
    Write-Utf8 -Path $reservedDefinitionPath -Text ($reservedDefinition | ConvertTo-Json -Depth 12)
    $reservedProject = New-TestProject -Parent $testRoot -Name "reserved-folder-project"
    $reservedRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $reservedProject, "-DefinitionPath", $reservedDefinitionPath)
    Assert-True ($reservedRun.Code -ne 0 -and $reservedRun.Output -match '(?i)reserved placement outside folder-tool authority' -and -not (Test-Path -LiteralPath (Join-Path $reservedProject "GeurtsGameForgeCommandments"))) "Folder tool rejects a count-preserving attempt to add the project-local documentation copy to the creation registry"
    $blockedProject = New-TestProject -Parent $testRoot -Name "folder-blocked"
    Write-Utf8 -Path (Join-Path $blockedProject "Assets/_Project") -Text "blocking file"
    $blockedRun = Invoke-TestScript -Path $folderScript -Arguments @("-ProjectRoot", $blockedProject, "-DefinitionPath", $definitionPath)
    Assert-True ($blockedRun.Code -ne 0 -and $blockedRun.Output.Contains("Conflicted: Assets/_Project") -and (Test-Path -LiteralPath (Join-Path $blockedProject "Assets/_Project") -PathType Leaf)) "Folder collision reports the exact path and fails without deleting user content"

    # Static validation covers manifest/version integrity, source ownership, notification-only startup,
    # separated UI versions, the manual overwrite boundary, generic safeguards, and payload fidelity.
    $staticValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $RepositoryRoot)
    Assert-True ($staticValidation.Code -eq 0) "Repository static validation covers all normative acceptance rules"
    $staticJsonValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $RepositoryRoot, "-OutputFormat", "Json")
    $staticJsonObject = $null
    try { $staticJsonObject = $staticJsonValidation.Output | ConvertFrom-Json }
    catch { }
    $requiredLifecycleChecks = @(
        "Documentation audience tags",
        "Steam manifest routing",
        "Steam audience and metadata",
        "Steam target and preparation boundary",
        "Steam independent local prerequisite",
        "Steam optional provider and lifetime",
        "Steam evidence and artifacts",
        "Steam optional services and account-free drafts",
        "Steam policy publication boundary",
        "Portable root onboarding boundary",
        "Supported operation and capability evidence",
        "Unity 6000.6.3f1 target",
        "Unity C# example patterns",
        "Required technical dependencies and policies",
        "Frozen GFI v2 source and compatibility boundary",
        "Frozen GFI v2 startup and manual trigger",
        "Frozen GFI v2 separated versions",
        "Frozen GFI v2 destructive warning",
        "Frozen GFI v2 complete-tree replacement",
        "Frozen GFI v2 receipt lifecycle",
        "Frozen GFI v2 overwrite boundary",
        "Frozen GFI v2 discarded lifecycle exclusion",
        "Documentation companion closed contract",
        "Companion schema forward compatibility",
        "Documentation companion architecture boundary",
        "God-first optional Commandments Companion boundary",
        "Installed brick menu contract",
        "God documentation content integration",
        "No Unity companion implementation in documentation source",
        "Companion offline startup",
        "Companion confirmation and complete update",
        "Companion bounded project and script boundary",
        "Companion minimal lifecycle exclusions",
        "Companion AI-routing limitation"
    )
    $missingLifecycleChecks = @($requiredLifecycleChecks | Where-Object { $checkName = $_; @($staticJsonObject.checks | Where-Object { $_.name -ceq $checkName -and $_.passed }).Count -ne 1 })
    Assert-True ($staticJsonValidation.Code -eq 0 -and $staticJsonObject -and $staticJsonObject.status -eq "VALID" -and @($staticJsonObject.checks | Where-Object { -not $_.passed }).Count -eq 0 -and $missingLifecycleChecks.Count -eq 0) "Repository validation JSON output is parseable and contains every passing companion and frozen-GFI boundary check"

    # Mutated package fixtures must fail without changing the source checkout or any Unity project.
    $steamMutations = @(
        @{ Name = 'mandatory-api'; Old = 'The Steam API through Steamworks.NET is mandatory for Geurts Unity project setup'; New = 'The Steam API through Steamworks.NET is optional for Geurts Unity project setup'; Check = 'Steam independent local prerequisite' },
        @{ Name = 'existing-handoff'; Old = "Steamworks.NET is required before Install God and BigBang's existing-God handoff"; New = 'Steamworks.NET is required before initial installation only'; Check = 'Steam independent local prerequisite' },
        @{ Name = 'target'; Old = 'Steam on Windows x64 is the primary release target'; New = 'Steam on Windows x86 is the primary release target'; Check = 'Steam target and preparation boundary' },
        @{ Name = 'local-login'; Old = 'Local prerequisite inspection must not initialize Steam, load native Steam libraries, contact Steam or require a running client, login, AppID, account entitlement or network connectivity'; New = 'Local prerequisite inspection requires a Steam login'; Check = 'Steam independent local prerequisite' },
        @{ Name = 'compile-dependency'; Old = 'BigBang must still compile and open when Steamworks.NET, God, Odin Inspector and Quantum Console are absent'; New = 'BigBang must depend on Steamworks.NET'; Check = 'Steam independent local prerequisite' },
        @{ Name = 'scene-lifetime'; Old = 'do not use direct or indirect `DontDestroyOnLoad`'; New = 'use `DontDestroyOnLoad`'; Check = 'Steam optional provider and lifetime' },
        @{ Name = 'native-default'; Old = 'Native Steam activation is off by default in local unconfigured development'; New = 'Native Steam activation is on by default in local unconfigured development'; Check = 'Steam optional provider and lifetime' },
        @{ Name = 'release-claim'; Old = 'Native Steam integration and overlay remain unverified'; New = 'Native Steam integration and overlay are verified'; Check = 'Steam policy publication boundary' },
        @{ Name = 'cache-ack'; Old = 'cache changes and server acknowledgements are separate outcomes'; New = 'cache setters prove server acknowledgement'; Check = 'Steam optional services and account-free drafts' },
        @{ Name = 'preview-upload'; Old = 'unresolved placeholders, Preview=1, no SetLive'; New = 'resolved defaults, Preview=0, automatic SetLive'; Check = 'Steam optional services and account-free drafts' },
        @{ Name = 'hidden-admission'; Old = '## BigBang admission and compile independence'; New = "<!-- GEURTS-SECTION:BEGIN HUMAN-ONLY -->`r`n## BigBang admission and compile independence"; Check = 'Steam audience and metadata' }
    )
    foreach ($steamMutation in $steamMutations) {
        $steamFixture = New-StaticValidationFixture -Parent $testRoot -Name ('static-steam-' + $steamMutation.Name)
        $steamPath = Join-Path $steamFixture 'GeurtsTechniques/GeurtsSteamIntegrationTechnique.md'
        $steamOriginal = [IO.File]::ReadAllText($steamPath)
        $steamChanged = $steamOriginal.Replace($steamMutation.Old, $steamMutation.New)
        if ($steamMutation.Name -eq 'hidden-admission') {
            $steamChanged = $steamChanged.Replace('## Optional provider and shared contracts', "<!-- GEURTS-SECTION:END -->`r`n## Optional provider and shared contracts")
        }
        if ($steamChanged -ceq $steamOriginal) { throw ('Steam fixture did not mutate: ' + $steamMutation.Name) }
        Write-Utf8 -Path $steamPath -Text $steamChanged
        $steamRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $steamFixture)
        Assert-True ($steamRun.Code -ne 0 -and $steamRun.Output.Contains('[FAIL] ' + $steamMutation.Check)) ('Steam validator rejects ' + $steamMutation.Name)
    }
    foreach ($steamCase in @('missing-file', 'missing-route', 'missing-validation-entry', 'fake-release')) {
        $steamFixture = New-StaticValidationFixture -Parent $testRoot -Name ('static-steam-' + $steamCase)
        $steamCheck = 'Steam manifest routing'
        switch ($steamCase) {
            'missing-file' { Remove-Item -LiteralPath (Join-Path $steamFixture 'GeurtsTechniques/GeurtsSteamIntegrationTechnique.md'); $steamCheck = 'Manifest-listed files' }
            'missing-route' {
                $steamPath = Join-Path $steamFixture 'GeurtsTechniqueManifest.md'
                Write-Utf8 -Path $steamPath -Text ([regex]::Replace([IO.File]::ReadAllText($steamPath), '(?m)^\| Steam preparation, platform services and Windows release evidence[^\r\n]*\r?\n', ''))
            }
            'missing-validation-entry' {
                $steamPath = Join-Path $steamFixture 'GeurtsTechniques/GeurtsCommandmentsCompanionContract.json'
                $steamContract = [IO.File]::ReadAllText($steamPath) | ConvertFrom-Json
                $steamContract.validationEntries = @($steamContract.validationEntries | Where-Object { $_ -cne 'GeurtsTechniques/GeurtsSteamIntegrationTechnique.md' })
                Write-Utf8 -Path $steamPath -Text ($steamContract | ConvertTo-Json -Depth 10)
                $steamCheck = 'Documentation companion closed contract'
            }
            'fake-release' {
                $steamPath = Join-Path $steamFixture 'GeurtsTechniques/GeurtsBrickCatalogue.json'
                $steamCatalogue = [IO.File]::ReadAllText($steamPath) | ConvertFrom-Json
                $steamCatalogue.bricks += [pscustomobject]@{ id = 'com.geurts.gameforge.steam'; released = $true; version = '0.1.0'; source = 'https://invalid.example/steam.git#0000000000000000000000000000000000000000' }
                Write-Utf8 -Path $steamPath -Text ($steamCatalogue | ConvertTo-Json -Depth 10)
                $steamCheck = 'Steam policy publication boundary'
            }
        }
        $steamRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $steamFixture)
        Assert-True ($steamRun.Code -ne 0 -and $steamRun.Output.Contains('[FAIL] ' + $steamCheck)) ('Steam validator rejects ' + $steamCase)
    }
    foreach ($aiCase in @('portable-route', 'planned-operations')) {
        $aiFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-ai-usability-" + $aiCase)
        if ($aiCase -eq 'portable-route') {
            $aiPath = Join-Path $aiFixture 'GeurtsTechniques/GeurtsAgentTechnique.md'
            $aiText = [IO.File]::ReadAllText($aiPath).Replace('./GeurtsGameForgeCommandments/AI_READ_FIRST.md', 'C:/MovedProject/GeurtsGameForgeCommandments/AI_READ_FIRST.md')
        }
        else {
            $aiPath = Join-Path $aiFixture 'GeurtsTechniques/GeurtsGameForgeAutomationTechnique.md'
            $aiText = [IO.File]::ReadAllText($aiPath).Replace('Planned features never acquire supported operations', 'Planned features may advertise supported operations')
        }
        Write-Utf8 -Path $aiPath -Text $aiText
        $aiResult = Invoke-TestScript -Path (Join-Path $aiFixture 'Tools/ValidateGeurtsDocumentation.ps1') -Arguments @('-RepositoryRoot', $aiFixture)
        Assert-True ($aiResult.Code -eq 1) ("Static validation rejects AI usability boundary drift: " + $aiCase)
    }
    foreach ($toolCase in @('companion-exemption', 'catalogue-tools-removed')) {
        $toolFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-companion-tools-" + $toolCase)
        if ($toolCase -eq 'companion-exemption') {
            $toolTechniquePath = Join-Path $toolFixture 'GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md'
            $toolTechniqueText = [System.IO.File]::ReadAllText($toolTechniquePath).Replace('It requires separately installed licensed Odin Inspector and Quantum Console assemblies', 'God has no licensed library requirements')
            Write-Utf8 -Path $toolTechniquePath -Text $toolTechniqueText
        }
        else {
            $toolCataloguePath = Join-Path $toolFixture 'GeurtsTechniques/GeurtsBrickCatalogue.json'
            $toolCatalogue = [System.IO.File]::ReadAllText($toolCataloguePath) | ConvertFrom-Json
            @($toolCatalogue.bricks | Where-Object { $_.id -ceq 'com.geurts.gameforge.god' })[0].requiredTools = @()
            Write-Utf8 -Path $toolCataloguePath -Text ($toolCatalogue | ConvertTo-Json -Depth 10)
        }
        $toolRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $toolFixture)
        Assert-True ($toolRun.Code -ne 0 -and $toolRun.Output.Contains('[FAIL] Companion licensed tooling boundary')) "Validator rejects $toolCase without confusing God independence with licensed-tool requirements"
    }

    foreach ($case in @(
        @{ Name = 'dry-run'; Old = 'Unity removal dry run before confirmation'; New = 'Remove packages before review' },
        @{ Name = 'settings'; Old = "Delete only confirmed removed packages' exact owned settings files after resolved-graph verification"; New = 'Delete all project settings before removal' },
        @{ Name = 'self-removal'; Old = 'Save the self-removal result before releasing assembly reload'; New = 'Forget the self-removal result' },
        @{ Name = 'retained-pins'; Old = 'Retain installed non-Forge Registry and BuiltIn versions with exact pins'; New = 'Allow dependencies to downgrade' },
        @{ Name = 'frozen-pins'; Old = 'Include those same frozen pins in both the dry run and confirmed grouped removal'; New = 'Recompute versions during removal' },
        @{ Name = 'manifest-review'; Old = 'confirmation writes these pins to `Packages/manifest.json` and may make indirect dependencies direct'; New = 'No manifest changes need explanation' }
    )) {
        $fixture = New-StaticValidationFixture -Parent $testRoot -Name ('static-bigcrunch-' + $case.Name)
        $path = Join-Path $fixture 'GeurtsTechniques/GeurtsBigBangTechnique.md'
        $text = [IO.File]::ReadAllText($path)
        Assert-True ($text.Contains($case.Old)) ('BigCrunch ' + $case.Name + ' fixture actually changes the declared contract')
        Write-Utf8 -Path $path -Text $text.Replace($case.Old, $case.New)
        $run = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $fixture)
        Assert-True ($run.Code -ne 0 -and $run.Output.Contains('[FAIL] BigCrunch removal boundary')) ('Validator rejects BigCrunch ' + $case.Name + ' regression')
    }
    foreach ($themeCase in @('missing-technique', 'missing-applicability', 'palette-drift', 'private-theme-fork', 'companion-dependency', 'unexplained-disabled-action')) {
        $themeFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-editor-theme-" + $themeCase)
        $themeFixturePath = Join-Path $themeFixture 'GeurtsTechniques/GeurtsEditorUIThemeTechnique.md'
        $themeFixtureText = [System.IO.File]::ReadAllText($themeFixturePath)
        $expectedThemeFailure = 'Editor UI theme contract'
        if ($themeCase -eq 'missing-technique') {
            Remove-Item -LiteralPath $themeFixturePath
            $expectedThemeFailure = 'Manifest-listed files'
        }
        elseif ($themeCase -eq 'missing-applicability') {
            $themeManifestPath = Join-Path $themeFixture 'GeurtsTechniqueManifest.md'
            $themeManifestText = [regex]::Replace([System.IO.File]::ReadAllText($themeManifestPath), '(?m)^\| Shared visual foundation[^\r\n]+\r?\n', '')
            Write-Utf8 -Path $themeManifestPath -Text $themeManifestText
            $expectedThemeFailure = 'Mandatory Editor UI theme routing'
        }
        else {
            if ($themeCase -eq 'palette-drift') { $themeFixtureText = $themeFixtureText.Replace('#6EF29D', '#00FFFF') }
            elseif ($themeCase -eq 'private-theme-fork') { $themeFixtureText = $themeFixtureText.Replace('All bricks that depend on God must reuse', 'Each brick can replace') }
            elseif ($themeCase -eq 'companion-dependency') { $themeFixtureText = $themeFixtureText.Replace('Commandments must reuse God''s canonical theme directly', 'Commandments can maintain its own theme') }
            else { $themeFixtureText = $themeFixtureText.Replace('Explain unavailable actions visibly with the actual reason and an actionable next step', 'Hide unavailable actions without explanation') }
            Write-Utf8 -Path $themeFixturePath -Text $themeFixtureText
        }
        $themeRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $themeFixture)
        Assert-True ($themeRun.Code -ne 0 -and $themeRun.Output.Contains('[FAIL] ' + $expectedThemeFailure)) "Validator rejects Editor theme $themeCase regression"
    }

    foreach ($appearanceCase in @('missing-technique', 'missing-applicability', 'misordered-read', 'bad-version', 'hidden-policy',
        'noncollapsible', 'hidden-header', 'colour-only', 'console-only', 'hidden-tab', 'draw-only-validation', 'bigbang-vendor', 'palette-fork')) {
        $appearanceFixture = New-StaticValidationFixture -Parent $testRoot -Name ('static-appearance-' + $appearanceCase)
        $appearanceFixturePath = Join-Path $appearanceFixture 'GeurtsTechniques/GeurtsEditorAppearanceTechnique.md'
        $appearanceFixtureText = [IO.File]::ReadAllText($appearanceFixturePath)
        $expectedAppearanceFailure = 'Editor Appearance policy'
        if ($appearanceCase -eq 'missing-technique') {
            Remove-Item -LiteralPath $appearanceFixturePath
            $expectedAppearanceFailure = 'Manifest-listed files'
        }
        elseif ($appearanceCase -in @('missing-applicability', 'misordered-read')) {
            $appearanceManifestPath = Join-Path $appearanceFixture 'GeurtsTechniqueManifest.md'
            $appearanceManifestText = [IO.File]::ReadAllText($appearanceManifestPath)
            if ($appearanceCase -eq 'missing-applicability') {
                $appearanceManifestText = [regex]::Replace($appearanceManifestText, '(?m)^\| Forge-owned Editor workflow presentation[^\r\n]+\r?\n', '')
            } else {
                $appearanceManifestText = $appearanceManifestText.Replace('Editor UI Theme; Editor Appearance; Diagnostics;', 'Editor Appearance; Editor UI Theme; Diagnostics;')
            }
            Write-Utf8 -Path $appearanceManifestPath -Text $appearanceManifestText
            $expectedAppearanceFailure = 'Editor Appearance routing'
        }
        else {
            $originalAppearanceText = $appearanceFixtureText
            switch ($appearanceCase) {
                'bad-version' { $appearanceFixtureText = $appearanceFixtureText.Replace('**Version:** 0.1.6', '**Version:** 0.0.1') }
                'hidden-policy' { $appearanceFixtureText = $appearanceFixtureText.Replace('GEURTS-AUDIENCE: AI-READ', 'GEURTS-AUDIENCE: HUMAN-ONLY') }
                'noncollapsible' { $appearanceFixtureText = $appearanceFixtureText.Replace('Every content section must have a visible descriptive header and collapsible content', 'Content sections may remain permanently expanded without headers') }
                'hidden-header' { $appearanceFixtureText = $appearanceFixtureText.Replace('Its header remains visible when collapsed', 'Its header disappears when collapsed') }
                'colour-only' { $appearanceFixtureText = $appearanceFixtureText.Replace('Each callout must include severity text and a distinct severity icon', 'Each callout may indicate severity only by colour') }
                'console-only' { $appearanceFixtureText = $appearanceFixtureText.Replace('Routine authoring validation findings must appear inline at the affected field or group', 'Routine authoring validation findings may appear only in the Console') }
                'hidden-tab' { $appearanceFixtureText = $appearanceFixtureText.Replace('Inactive tabs must expose warning/error indicators', 'Inactive tabs may hide warning/error indicators') }
                'draw-only-validation' { $appearanceFixtureText = $appearanceFixtureText.Replace('Do not validate only drawn controls', 'Validate only drawn controls') }
                'bigbang-vendor' { $appearanceFixtureText = $appearanceFixtureText.Replace('This requirement must not introduce God or vendor dependencies into BigBang', 'BigBang must reference Odin before installing prerequisites') }
                'palette-fork' { $appearanceFixtureText += "`r`nPrivate accent palette: #00FFFF`r`n" }
            }
            Assert-True ($appearanceFixtureText -cne $originalAppearanceText) "Appearance $appearanceCase fixture actually changes the declared policy"
            Write-Utf8 -Path $appearanceFixturePath -Text $appearanceFixtureText
        }
        $appearanceRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $appearanceFixture)
        Assert-True ($appearanceRun.Code -ne 0 -and $appearanceRun.Output.Contains('[FAIL] ' + $expectedAppearanceFailure)) "Validator rejects Appearance $appearanceCase regression"
    }

    $godDependencyFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-god-required-documentation"
    $godCataloguePath = Join-Path $godDependencyFixture "GeurtsTechniques/GeurtsBrickCatalogue.json"
    $godCatalogue = [System.IO.File]::ReadAllText($godCataloguePath) | ConvertFrom-Json
    $godEntry = @($godCatalogue.bricks | Where-Object { $_.id -ceq "com.geurts.gameforge.god" })[0]
    $godEntry.dependencies = @([pscustomobject]@{ id = "com.geurts.gameforge.documentation"; minimumVersion = "0.8.1" })
    Write-Utf8 -Path $godCataloguePath -Text ($godCatalogue | ConvertTo-Json -Depth 10)
    $godDependencyRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $godDependencyFixture)
    Assert-True ($godDependencyRun.Code -ne 0 -and $godDependencyRun.Output.Contains('[FAIL] God-first optional Commandments Companion boundary')) "Validator rejects reintroducing Commandments Companion as a required God catalogue dependency"

    $godContentFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-god-content-confirmation"
    $godContentPath = Join-Path $godContentFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $godContentPath -Text ([System.IO.File]::ReadAllText($godContentPath).Replace('one cancel-default confirmation before archive acquisition, including on the first manual content installation', 'confirmation only after the first content installation'))
    $godContentRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $godContentFixture)
    Assert-True ($godContentRun.Code -ne 0 -and $godContentRun.Output.Contains('[FAIL] God documentation content integration')) "Validator rejects exempting the first content installation from the companion confirmation"

    $godPackageFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-god-package-content-coupling"
    $godPackagePath = Join-Path $godPackageFixture "GeurtsTechniques/GeurtsBrickContract.md"
    Write-Utf8 -Path $godPackagePath -Text ([System.IO.File]::ReadAllText($godPackagePath).Replace('Manual Update All cannot replace content', 'Package Update All automatically replaces documentation content'))
    $godPackageRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $godPackageFixture)
    Assert-True ($godPackageRun.Code -ne 0 -and $godPackageRun.Output.Contains('[FAIL] God documentation content integration')) "Validator rejects silently coupling package Update All to content replacement"

    foreach ($audienceCase in @('hidden-entry', 'missing-tag', 'unclosed-section')) {
        $audienceFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-audience-" + $audienceCase)
        $audiencePath = Join-Path $audienceFixture 'AI_READ_FIRST.md'
        $audienceText = [System.IO.File]::ReadAllText($audiencePath)
        if ($audienceCase -eq 'hidden-entry') { $audienceText = $audienceText.Replace('<!-- GEURTS-AUDIENCE: AI-READ -->', '<!-- GEURTS-AUDIENCE: HUMAN-ONLY -->') }
        elseif ($audienceCase -eq 'missing-tag') { $audienceText = $audienceText.Replace('<!-- GEURTS-AUDIENCE: AI-READ -->', '') }
        else { $audienceText += "`n<!-- GEURTS-SECTION:BEGIN HUMAN-ONLY -->`nHidden rules." }
        Write-Utf8 -Path $audiencePath -Text $audienceText
        $audienceRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $audienceFixture)
        Assert-True ($audienceRun.Code -ne 0 -and $audienceRun.Output.Contains('[FAIL] Documentation audience tags')) "Validator rejects $audienceCase without hiding mandatory bootstrap rules"
    }

    foreach ($namingCase in @('duplicate-scene-type', 'missing-asset-type', 'missing-script-exemption', 'hidden-naming', 'missing-applicability', 'missing-numeric-suffix', 'nonnumeric-suffix', 'mandatory-number', 'padded-suffix')) {
        $namingFixture = New-StaticValidationFixture -Parent $testRoot -Name ('static-naming-' + $namingCase)
        $namingFixturePath = Join-Path $namingFixture 'GeurtsTechniques/GeurtsNamingTechnique.md'
        $namingFixtureText = [System.IO.File]::ReadAllText($namingFixturePath)
        $originalNamingFixtureText = $namingFixtureText
        $expectedNamingFailure = 'Naming Technique policy'
        if ($namingCase -eq 'missing-applicability') {
            $namingManifestPath = Join-Path $namingFixture 'GeurtsTechniqueManifest.md'
            $namingManifestText = [regex]::Replace([System.IO.File]::ReadAllText($namingManifestPath), '(?m)^\| First-party asset, scene object, prefab root and script names[^\r\n]+\r?\n', '')
            Write-Utf8 -Path $namingManifestPath -Text $namingManifestText
            $expectedNamingFailure = 'Naming Technique routing'
        } else {
            if ($namingCase -eq 'duplicate-scene-type') { $namingFixtureText = $namingFixtureText.Replace('| `OBJ` | Interactable object |', '| `ENV` | Interactable object |') }
            elseif ($namingCase -eq 'missing-asset-type') { $namingFixtureText = [regex]::Replace($namingFixtureText, '(?m)^\| Fonts \| `FONT`[^\r\n]+\r?\n', '') }
            elseif ($namingCase -eq 'missing-numeric-suffix') { $namingFixtureText = $namingFixtureText.Replace('(?:_(?:0|[1-9][0-9]*))?', '') }
            elseif ($namingCase -eq 'nonnumeric-suffix') { $namingFixtureText = $namingFixtureText.Replace('(?:_(?:0|[1-9][0-9]*))?', '(?:_[A-Za-z0-9]+)?') }
            elseif ($namingCase -eq 'mandatory-number') { $namingFixtureText = $namingFixtureText.Replace('(?:_(?:0|[1-9][0-9]*))?', '(?:_(?:0|[1-9][0-9]*))') }
            elseif ($namingCase -eq 'padded-suffix') { $namingFixtureText = $namingFixtureText.Replace('(?:_(?:0|[1-9][0-9]*))?', '(?:_[0-9]+)?') }
            elseif ($namingCase -eq 'hidden-naming') { $namingFixtureText = $namingFixtureText.Replace('GEURTS-AUDIENCE: AI-READ', 'GEURTS-AUDIENCE: HUMAN-ONLY') }
            else { $namingFixtureText = $namingFixtureText.Replace('Scripts MUST NOT use `TYPE_Category_Description`', 'Scripts MAY use `TYPE_Category_Description`') }
            Assert-True ($namingFixtureText -cne $originalNamingFixtureText) "Naming $namingCase fixture changes its intended rule"
            Write-Utf8 -Path $namingFixturePath -Text $namingFixtureText
        }
        $namingRun = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $namingFixture)
        Assert-True ($namingRun.Code -ne 0 -and $namingRun.Output.Contains('[FAIL] ' + $expectedNamingFailure)) "Validator rejects Naming $namingCase regression"
    }

    $unityTargetFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-unity-target"
    $unityTargetReadme = Join-Path $unityTargetFixture "README.md"
    Write-Utf8 -Path $unityTargetReadme -Text ([System.IO.File]::ReadAllText($unityTargetReadme).Replace('**Unity target:** Unity 6.6 (6000.6.3f1)', '**Unity target:** Unity 6.0 LTS (6000.0)'))
    $policyFixture = New-StaticValidationFixture -Parent $testRoot -Name "missing-version-policy"
    $policyPath = Join-Path $policyFixture "AI_READ_FIRST.md"
    Write-Utf8 -Path $policyPath -Text ([System.IO.File]::ReadAllText($policyPath).Replace("Never publish changed content under the same version", "Version changes are optional"))
    $policyRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $policyFixture)
    Assert-True ($policyRun.Code -ne 0 -and $policyRun.Output.Contains("Mandatory reading and version policy")) "Validator rejects removal of the mandatory version-bump rule"

    $unityTargetRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $unityTargetFixture)
    Assert-True ($unityTargetRun.Code -ne 0 -and $unityTargetRun.Output.Contains("[FAIL] Unity 6000.6.3f1 target")) "Static validation rejects a conflicting Unity target in a package entry surface"

    $unityBaselineFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-unity-baseline-missing"
    $unityBaselineTechnique = Join-Path $unityBaselineFixture "GeurtsTechniques/GeurtsUnityTechnique.md"
    $baselineOriginal = [System.IO.File]::ReadAllText($unityBaselineTechnique)
    $withoutBaseline = [regex]::Replace($baselineOriginal, '(?ms)^## Unity 6000\.6\.3f1 Compatibility Baseline\s*.*?(?=^## |\z)', '')
    Assert-True ($withoutBaseline -cne $baselineOriginal -and $withoutBaseline -notmatch '(?m)^## Unity 6000\.6\.3f1 Compatibility Baseline') "Missing-baseline fixture removes the standalone Unity topic's final section"
    Write-Utf8 -Path $unityBaselineTechnique -Text $withoutBaseline
    $unityBaselineRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $unityBaselineFixture)
    Assert-True ($unityBaselineRun.Code -ne 0 -and $unityBaselineRun.Output.Contains("[FAIL] Unity 6000.6.3f1 target")) "Static validation rejects target metadata without the technical compatibility baseline"

    $invalidUnityExamples = @(
        @{ Name = "obsolete-find"; Code = 'var items = UnityEngine.Object.FindObjectsOfType<UnityEngine.Collider>();' },
        @{ Name = "deprecated-first-find"; Code = 'var item = UnityEngine.Object.FindFirstObjectByType<UnityEngine.Collider>();' },
        @{ Name = "deprecated-sort-find"; Code = 'var items = UnityEngine.Object.FindObjectsByType<UnityEngine.Collider>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);' },
        @{ Name = "legacy-input"; Code = 'float movement = UnityEngine.Input.GetAxis("Horizontal");' },
        @{ Name = "legacy-rpc"; Code = '[ServerRpc] public void PingServerRpc() { }' },
        @{ Name = "legacy-uxml"; Code = 'public class Factory : UxmlFactory<Example> { }' },
        @{ Name = "file-namespace"; Code = 'namespace Example;' },
        @{ Name = "global-using"; Code = 'global using UnityEngine;' },
        @{ Name = "record-struct"; Code = 'public record struct Example(int Value);' }
    )
    foreach ($exampleCase in $invalidUnityExamples) {
        $exampleFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-unity-example-" + $exampleCase.Name)
        $exampleTechnique = Join-Path $exampleFixture "GeurtsTechniques/GeurtsTechnicalTechnique.md"
        $invalidFence = [Environment]::NewLine + '```csharp' + [Environment]::NewLine + $exampleCase.Code + [Environment]::NewLine + '```' + [Environment]::NewLine
        Write-Utf8 -Path $exampleTechnique -Text ([System.IO.File]::ReadAllText($exampleTechnique) + $invalidFence)
        $exampleRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $exampleFixture)
        Assert-True ($exampleRun.Code -ne 0 -and $exampleRun.Output.Contains("[FAIL] Unity C# example patterns")) ("Static validation rejects unsupported current C# example: " + $exampleCase.Name)
    }


    # Each fixture reintroduces a different audited cross-document contradiction.
    $consistencyCases = @(
        @{ Name = 'duplicate-numeric-allocation'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'first free `_0`, `_1`, `_2`'; New = 'stable GUID suffix'; Check = 'Estimated naming scans and exclusions' },
        @{ Name = 'duplicate-nested-number'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'never append nested numbers'; New = 'append another number after the first'; Check = 'Estimated naming scans and exclusions' },
        @{ Name = 'folder-reader-version'; Path = 'Tools/CreateGeurtsFolderStructure.ps1'; Old = '0\.16\.6'; New = '0\.16\.0'; Check = 'Folder technique reader version parity' },
        @{ Name = 'logging-fallback'; Path = 'GeurtsTechniques/GeurtsDiagnosticsTechnique.md'; Old = '## Shared logging contract'; New = "## Logging Standards`r`n`r`nThe facade must fall back to Unity logging." },
        @{ Name = 'menu-network'; Path = 'GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md'; Old = 'Opening the Commandments menu or embedded view stays offline'; New = 'A deliberate Commandments Companion menu opening may request remote metadata' },
        @{ Name = 'tool-owner'; Path = 'README.md'; Old = 'Angels owns **Install Codex guide**'; New = 'God owns the separate **Install Codex guide**' },
        @{ Name = 'root-guide-ban'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'automatic root guide installation'; New = 'root guide installation' },
        @{ Name = 'auto-sort-default'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'off by default'; New = 'on by default'; Check = 'Automatic import organization boundary' },
        @{ Name = 'auto-sort-history'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Missing, malformed or mismatched history pauses'; New = 'Missing, malformed or mismatched history continues'; Check = 'Automatic import organization boundary' },
        @{ Name = 'auto-rename-default'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = '**Automatically rename new imports**, off by default and separate from sorting'; New = '**Automatically rename new imports**, on by default'; Check = 'Automatic import naming boundary' },
        @{ Name = 'auto-rename-collision'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Never overwrite existing assets'; New = 'Overwrite existing assets'; Check = 'Automatic import naming boundary' },
        @{ Name = 'codex-naming-sharing'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'exactly what content is sent, account usage and automatic application'; New = 'silently send content'; Check = 'Codex import naming boundary' },
        @{ Name = 'codex-naming-retry'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'No automatic retry, catch-up or repeated paid inference after an interrupted request'; New = 'Automatically retry interrupted requests'; Check = 'Codex import naming boundary' },
        @{ Name = 'estimated-naming-required'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Always estimate each eligible file'; New = 'Skip uncertain eligible files'; Check = 'Estimated naming scans and exclusions' },
        @{ Name = 'measured-progress-required'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'completed asset outcomes divided by the reviewed total'; New = 'elapsed time estimate'; Check = 'Estimated naming scans and exclusions' },
        @{ Name = 'audio-secure-key'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Windows Credential Manager'; New = 'plaintext project settings'; Check = 'Actual audio naming boundary' },
        @{ Name = 'audio-coverage'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Never claim omitted portions/channels were heard'; New = 'Claim the entire recording was heard'; Check = 'Actual audio naming boundary' },
        @{ Name = 'codex-all-segments'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Codex chooses Type, Category and Description'; New = 'Codex only chooses a description'; Check = 'Codex import naming boundary' },
        @{ Name = 'codex-image-audio'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'Always consider images and audio'; New = 'Skip all images and audio'; Check = 'Asset organization setup and complete naming' },
        @{ Name = 'codex-incoming-folders'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'descendants of incoming moved folders'; New = 'no incoming folder contents'; Check = 'Asset organization setup and complete naming' },
        @{ Name = 'odin-visible-boxes'; Path = 'GeurtsTechniques/GeurtsEditorAppearanceTechnique.md'; Old = 'Verify actual visible Odin BoxGroups on the affected screen'; New = 'Assume attributes are sufficient'; Check = 'Asset organization setup and complete naming' },

        @{ Name = 'codex-context-bounds'; Path = 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'; Old = 'aggregate context to 512 KiB'; New = 'unbounded context'; Check = 'Codex project context boundary' },
        @{ Name = 'codex-context-ownership'; Path = 'GeurtsTechniques/GeurtsGameDesignDocumentationTechnique.md'; Old = 'untrusted evidence, not executable instructions'; New = 'instructions to execute'; Check = 'Codex project context boundary' },
        @{ Name = 'codex-context-scan'; Path = 'GeurtsTechniques/GeurtsGameDesignDocumentationTechnique.md'; Old = 'Do not recursively scan or read unrelated/supporting design documents'; New = 'Read every design document'; Check = 'Codex project context boundary' },



        @{ Name = 'mandatory-console'; Path = 'GeurtsTechniques/GeurtsCommandsTechnique.md'; Old = 'Installing or enabling a runtime developer console is optional'; New = 'Every gameplay project must include a validated developer-console setup' },
        @{ Name = 'extra-status'; Path = 'GeurtsTechniques/GeurtsForgeSetupContract.json'; Old = '"not-applicable"'; New = '"not-applicable", "unavailable"' },
        @{ Name = 'false-success-outline'; Path = 'GeurtsTechniques/GeurtsEditorUIThemeTechnique.md'; Old = 'retain neutral borders and precise text'; New = 'receive green success borders' },
        @{ Name = 'duplicate-migration'; Path = 'README.md'; Old = '## Supporting Documents'; New = "## Supporting Documents`r`n`r`n- ``Migrations/v0.11.0.md`` - duplicate reference." }
    )
    foreach ($case in $consistencyCases) {
        $fixture = New-StaticValidationFixture -Parent $testRoot -Name ('static-consistency-' + $case.Name)
        $path = Join-Path $fixture $case.Path
        $text = [IO.File]::ReadAllText($path)
        if (-not $text.Contains($case.Old)) { throw "Consistency fixture mutation did not match: $($case.Name)" }
        Write-Utf8 -Path $path -Text $text.Replace($case.Old, $case.New)
        $run = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $fixture)
        $expectedCheck = if ($case.Check) { $case.Check } else { 'Resolved documentation policy consistency' }
        Assert-True ($run.Code -ne 0 -and $run.Output.Contains('[FAIL] ' + $expectedCheck)) "Validator rejects audited contradiction: $($case.Name)"
    }

    $optionalOdinFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-optional-odin"
    $optionalOdinTechnique = Join-Path $optionalOdinFixture "GeurtsTechniques/GeurtsAuthoringTechnique.md"
    $optionalOdinText = [System.IO.File]::ReadAllText($optionalOdinTechnique).Replace('Odin Inspector is required within the implementation scope defined by the Unity 6000.6.3f1 dependency baseline.', 'Odin Inspector is optional within the implementation scope defined by the Unity 6000.6.3f1 dependency baseline.')
    Write-Utf8 -Path $optionalOdinTechnique -Text $optionalOdinText
    $optionalOdinRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $optionalOdinFixture)
    Assert-True ($optionalOdinRun.Code -ne 0 -and $optionalOdinRun.Output.Contains("[FAIL] Required technical dependencies and policies")) "Static validation rejects making Odin Inspector optional"

    $optionalQuantumFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-optional-quantum"
    $optionalQuantumTechnique = Join-Path $optionalQuantumFixture "GeurtsTechniques/GeurtsCommandsTechnique.md"
    $optionalQuantumText = [System.IO.File]::ReadAllText($optionalQuantumTechnique).Replace('Quantum Console remains a required licensed library', 'Quantum Console is an optional licensed library')
    Write-Utf8 -Path $optionalQuantumTechnique -Text $optionalQuantumText
    $optionalQuantumRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $optionalQuantumFixture)
    Assert-True ($optionalQuantumRun.Code -ne 0 -and $optionalQuantumRun.Output.Contains("[FAIL] Required technical dependencies and policies")) "Static validation rejects making Quantum Console optional"

    $brickRouteFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-native-brick-route"
    $testingBoundaryFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-testing-boundary"
    $testingBoundaryPath = Join-Path $testingBoundaryFixture "GeurtsTechniques/GeurtsCommandsTechnique.md"
    Write-Utf8 -Path $testingBoundaryPath -Text ([System.IO.File]::ReadAllText($testingBoundaryPath).Replace('never bypasses host/server authority', 'bypasses host/server authority'))
    $testingBoundaryRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $testingBoundaryFixture)
    Assert-True ($testingBoundaryRun.Code -ne 0 -and $testingBoundaryRun.Output.Contains("[FAIL] Required technical dependencies and policies")) "Static validation rejects weakening testing host/server authority"
    $brickRouteTemplatePath = Join-Path $brickRouteFixture "Tools/AIAgentInstructionTemplates/copilot-instructions.md"
    $weakenedBrickRoute = 'Read and follow `GeurtsGameForgeCommandments/AI_READ_FIRST.md`; it routes to the installed documentation.'
    Write-Utf8 -Path $brickRouteTemplatePath -Text ([System.IO.File]::ReadAllText($brickRouteTemplatePath).Replace($expectedProjectRouteText, $weakenedBrickRoute))
    $brickRouteValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $brickRouteFixture)
    Assert-True ($brickRouteValidation.Code -ne 0 -and $brickRouteValidation.Output.Contains("Managed native routes")) "Static validation rejects a route that drops the all-project-work and manifest-selected source-of-truth instruction"

    foreach ($templateExpectation in $nativeTemplateExpectations) {
        $narrowRouteFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-narrow-route-" + [System.IO.Path]::GetFileNameWithoutExtension($templateExpectation.Path))
        $narrowRoutePath = Join-Path $narrowRouteFixture $templateExpectation.Path
        $narrowRouteText = [System.IO.File]::ReadAllText($narrowRoutePath).Replace("Before any Geurts Game Forge project work", "Before planning or modifying any Geurts Game Forge brick code")
        Write-Utf8 -Path $narrowRoutePath -Text $narrowRouteText
        $narrowRouteRun = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $narrowRouteFixture)
        Assert-True ($narrowRouteRun.Code -ne 0 -and $narrowRouteRun.Output.Contains("[FAIL] Managed native routes")) "$($templateExpectation.Path) cannot regress to brick-code-only routing"
    }

    $templateHashFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-native-template-hash"
    $templateHashPath = Join-Path $templateHashFixture "Tools/AIAgentInstructionTemplates/copilot-instructions.md"
    Write-Utf8 -Path $templateHashPath -Text ([System.IO.File]::ReadAllText($templateHashPath).Replace('sha256="92e4a7ae1ff00f20480b217108a028bce40276a97d4caa3b614588fdf75874bc"', 'sha256="03464c8bace065ddfe2f305dfedafafbb8a1099cb318c21dad185d46d22451eb"'))
    $templateHashValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $templateHashFixture)
    Assert-True ($templateHashValidation.Code -ne 0 -and $templateHashValidation.Output.Contains("Managed template integrity")) "Static validation rejects drift from the exact approved v1.3.0 managed-region hashes"

    foreach ($guideMutation in @("placeholder", "standalone")) {
        $guideFixture = New-StaticValidationFixture -Parent $testRoot -Name ("static-codex-" + $guideMutation)
        if ($guideMutation -eq "placeholder") {
            $guideTechniquePath = Join-Path $guideFixture "GeurtsTechniques/GeurtsAgentTechnique.md"
            Write-Utf8 -Path $guideTechniquePath -Text ([System.IO.File]::ReadAllText($guideTechniquePath).Replace('{{GEURTS_DOCUMENTATION_ENTRY_POINT}}', 'missing entry'))
        }
        else { Write-Utf8 -Path (Join-Path $guideFixture "AGENTS.md") -Text "Deprecated entry" }
        $guideValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $guideFixture)
        Assert-True ($guideValidation.Code -ne 0 -and $guideValidation.Output.Contains("Codex guide template and retired routes")) "Static validation rejects Codex guide $guideMutation regression"
    }

    $extraRouteFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-extra-route"
    $extraRouteContractPath = Join-Path $extraRouteFixture "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json"
    $extraRouteContract = Get-Content -LiteralPath $extraRouteContractPath -Raw | ConvertFrom-Json
    $extraRouteContract.routeMappings += [pscustomobject]@{ template = "Tools/AIAgentInstructionTemplates/copilot-instructions.md"; target = ".cursor/rules/geurts.md" }
    Write-Utf8 -Path $extraRouteContractPath -Text ($extraRouteContract | ConvertTo-Json -Depth 10)
    $extraRouteValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $extraRouteFixture)
    Assert-True ($extraRouteValidation.Code -ne 0 -and $extraRouteValidation.Output.Contains("Documentation companion closed contract")) "Static validation rejects an added companion AI-route mapping"

    $docsRouteFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-docs-route"
    $docsRouteContractPath = Join-Path $docsRouteFixture "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json"
    $docsRouteContract = Get-Content -LiteralPath $docsRouteContractPath -Raw | ConvertFrom-Json
    $docsRouteContract.routeMappings[2].target = "Docs/GameDesign/geurts-game-design.instructions.md"
    $docsRouteContract.updateUi.confirmationTargets[3].path = "Docs/GameDesign/geurts-game-design.instructions.md"
    Write-Utf8 -Path $docsRouteContractPath -Text ($docsRouteContract | ConvertTo-Json -Depth 10)
    $docsRouteValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $docsRouteFixture)
    Assert-True ($docsRouteValidation.Code -ne 0 -and $docsRouteValidation.Output.Contains("Documentation companion closed contract")) "Static validation rejects a contract route or confirmation target under Docs/GameDesign"

    $forbiddenLifecycleFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-forbidden-lifecycle"
    $forbiddenLifecycleTechnique = Join-Path $forbiddenLifecycleFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $forbiddenLifecycleTechnique -Text ([System.IO.File]::ReadAllText($forbiddenLifecycleTechnique) + "`nThe companion provides a preview, backup, rollback journal, and migration path for Update, then requires a second confirmation.`n")
    $forbiddenLifecycleValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $forbiddenLifecycleFixture)
    Assert-True ($forbiddenLifecycleValidation.Code -ne 0 -and $forbiddenLifecycleValidation.Output.Contains("Companion minimal lifecycle exclusions")) "Static validation rejects affirmative preview, backup, rollback, journal, migration, and second-confirmation behavior"

    $secondConfirmationFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-second-confirmation"
    $secondConfirmationTechnique = Join-Path $secondConfirmationFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $secondConfirmationTechnique -Text ([System.IO.File]::ReadAllText($secondConfirmationTechnique) + "`nThe companion requires a second confirmation after archive validation.`n")
    $secondConfirmationValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $secondConfirmationFixture)
    Assert-True ($secondConfirmationValidation.Code -ne 0 -and $secondConfirmationValidation.Output.Contains("Companion minimal lifecycle exclusions")) "Static validation independently rejects a second Update confirmation"

    $startupMutationFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-startup-mutation"
    $startupMutationTechnique = Join-Path $startupMutationFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $startupMutationTechnique -Text ([System.IO.File]::ReadAllText($startupMutationTechnique) + "`nAt Unity open, the companion automatically downloads and replaces documentation.`n")
    $startupMutationValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $startupMutationFixture)
    Assert-True ($startupMutationValidation.Code -ne 0 -and $startupMutationValidation.Output.Contains("Companion offline startup")) "Static validation rejects automatic download or replacement during Unity open"

    $startupCheckFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-startup-check"
    $startupCheckTechnique = Join-Path $startupCheckFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $startupCheckTechnique -Text ([System.IO.File]::ReadAllText($startupCheckTechnique) + "`nAt Unity open, the companion automatically checks remote metadata.`n")
    $startupCheckValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $startupCheckFixture)
    Assert-True ($startupCheckValidation.Code -ne 0 -and $startupCheckValidation.Output.Contains("Companion offline startup")) "Static validation rejects a remote metadata check during Unity startup"

    $bootstrapFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-bootstrap"
    $bootstrapTechnique = Join-Path $bootstrapFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $bootstrapTechnique -Text ([System.IO.File]::ReadAllText($bootstrapTechnique) + "`nThe companion uses an external batch bootstrap to execute .bat setup scripts.`n")
    $bootstrapValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $bootstrapFixture)
    Assert-True ($bootstrapValidation.Code -ne 0 -and $bootstrapValidation.Output.Contains("Companion minimal lifecycle exclusions")) "Static validation rejects an external batch/bootstrap setup claim"

    $expandedDownloadedContractFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-expanded-downloaded-contract"
    $expandedDownloadedContractTechnique = Join-Path $expandedDownloadedContractFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $expandedDownloadedContractTechnique -Text ([System.IO.File]::ReadAllText($expandedDownloadedContractTechnique) + "`nThe downloaded contract may add a managed target after confirmation.`n")
    $expandedDownloadedContractValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $expandedDownloadedContractFixture)
    Assert-True ($expandedDownloadedContractValidation.Code -ne 0 -and $expandedDownloadedContractValidation.Output.Contains("Companion confirmation and complete update")) "Static validation rejects a downloaded contract that expands the pre-approved managed target set"

    $comparisonStateFailureFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-comparison-state-failure"
    $comparisonStateFailureTechnique = Join-Path $comparisonStateFailureFixture "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    Write-Utf8 -Path $comparisonStateFailureTechnique -Text ([System.IO.File]::ReadAllText($comparisonStateFailureTechnique) + "`nA comparison-state write failure reclassifies the content Update as failed and rolls back the replacement.`n")
    $comparisonStateFailureValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $comparisonStateFailureFixture)
    Assert-True ($comparisonStateFailureValidation.Code -ne 0 -and $comparisonStateFailureValidation.Output.Contains("Companion confirmation and complete update")) "Static validation rejects treating comparison-state persistence failure as failed or rolled-back managed content"

    $pluginCodeFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-companion-plugin-code"

    $standardsBoundaryFixture = New-StaticValidationFixture -Parent $testRoot -Name 'static-standards-only-boundary'
    $standardsBoundaryPath = Join-Path $standardsBoundaryFixture 'GeurtsTechniques/GeurtsStandardsOnlyTechnique.md'
    Write-Utf8 $standardsBoundaryPath ([IO.File]::ReadAllText($standardsBoundaryPath).Replace('No Geurts Unity packages are required by StandardsOnly.', 'StandardsOnly requires God.'))
    $standardsBoundaryValidation = Invoke-TestScript -Path $validatorScript -Arguments @('-RepositoryRoot', $standardsBoundaryFixture)
    Assert-True ($standardsBoundaryValidation.Code -ne 0 -and $standardsBoundaryValidation.Output -match '\[FAIL\] Standards-only applicability') 'Static validation rejects removal of the standalone package-dependency boundary'
    $pluginCodePath = Join-Path $pluginCodeFixture "Editor/DocumentationCompanion.cs"
    Write-Utf8 -Path $pluginCodePath -Text "internal static class DocumentationCompanionFixture { }`n"
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $pluginCodeAddOutput = @(& git -C $pluginCodeFixture add -- "Editor/DocumentationCompanion.cs" 2>&1)
        $pluginCodeAddExitCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    if ($pluginCodeAddExitCode -ne 0) { throw "Unable to stage plugin-code fixture: $($pluginCodeAddOutput -join ' ')" }
    $pluginCodeValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $pluginCodeFixture)
    Assert-True ($pluginCodeValidation.Code -ne 0 -and $pluginCodeValidation.Output.Contains("No Unity companion implementation in documentation source")) "Static validation rejects tracked C# companion implementation in the documentation repository"

    $legacyLifecycleFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-old-lifecycle"
    $legacyLifecycleTechnique = Join-Path $legacyLifecycleFixture "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    Write-Utf8 -Path $legacyLifecycleTechnique -Text ([System.IO.File]::ReadAllText($legacyLifecycleTechnique) + "`nGame Forge Intelligence performs exactly one routine remote documentation check per Unity project launch or open, then promotes the candidate atomically with combined rollback.`n")
    $legacyLifecycleValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $legacyLifecycleFixture)
    Assert-True ($legacyLifecycleValidation.Code -ne 0 -and $legacyLifecycleValidation.Output.Contains("Frozen GFI v2 discarded lifecycle exclusion")) "Static validation rejects reintroduced stateful launch-check, atomic-promotion, and rollback language in the frozen GFI v2 contract"

    $gddOverwriteFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-gdd-overwrite"
    $gddOverwriteTechnique = Join-Path $gddOverwriteFixture "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    Write-Utf8 -Path $gddOverwriteTechnique -Text ([System.IO.File]::ReadAllText($gddOverwriteTechnique) + "`nGame Forge Intelligence may also delete and replace <ProjectRoot>/Docs/GameDesign during documentation Update.`n")
    $gddOverwriteValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $gddOverwriteFixture)
    Assert-True ($gddOverwriteValidation.Code -ne 0 -and $gddOverwriteValidation.Output.Contains("Frozen GFI v2 overwrite boundary")) "Static validation rejects any permission for the frozen GFI v2 contract to replace project-authored Docs/GameDesign"

    $pluginEmbeddingFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-plugin-embedding"
    $pluginEmbeddingTechnique = Join-Path $pluginEmbeddingFixture "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    Write-Utf8 -Path $pluginEmbeddingTechnique -Text ([System.IO.File]::ReadAllText($pluginEmbeddingTechnique) + "`nThe plugin may embed Geurts documentation in <PluginPackageRoot>/Documentation~.`n")
    $pluginEmbeddingValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $pluginEmbeddingFixture)
    Assert-True ($pluginEmbeddingValidation.Code -ne 0 -and $pluginEmbeddingValidation.Output.Contains("Frozen GFI v2 source and compatibility boundary")) "Static validation rejects bundled Geurts documentation inside the frozen GFI plugin Documentation~ boundary"

    $versionConflationFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-version-conflation"
    $versionConflationTechnique = Join-Path $versionConflationFixture "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    Write-Utf8 -Path $versionConflationTechnique -Text ([System.IO.File]::ReadAllText($versionConflationTechnique) + "`nThe UI may display the compatibility schema as the GameForgeIntelligence Plugin version.`n")
    $versionConflationValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $versionConflationFixture)
    Assert-True ($versionConflationValidation.Code -ne 0 -and $versionConflationValidation.Output.Contains("Frozen GFI v2 separated versions")) "Static validation rejects conflation of frozen GFI v2 schema, technique, documentation, and plugin versions"

    $historicalReceiptFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-historical-receipt"
    $historicalReceiptTechnique = Join-Path $historicalReceiptFixture "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    Write-Utf8 -Path $historicalReceiptTechnique -Text ([System.IO.File]::ReadAllText($historicalReceiptTechnique) + "`nA historical receipt may continue to drive Installed Geurts Documentation and update comparison after deletion begins.`n")
    $historicalReceiptValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $historicalReceiptFixture)
    Assert-True ($historicalReceiptValidation.Code -ne 0 -and $historicalReceiptValidation.Output.Contains("Frozen GFI v2 receipt lifecycle")) "Static validation rejects historical-receipt fallback inside the frozen GFI v2 contract"

    $versionAvailabilityFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-package-version-availability"
    $versionAvailabilityTechnique = Join-Path $versionAvailabilityFixture "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    Write-Utf8 -Path $versionAvailabilityTechnique -Text ([System.IO.File]::ReadAllText($versionAvailabilityTechnique) + "`nPackage-version ordering determines whether an Update is available even when commit IDs match.`n")
    $versionAvailabilityValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $versionAvailabilityFixture)
    Assert-True ($versionAvailabilityValidation.Code -ne 0 -and $versionAvailabilityValidation.Output.Contains("Frozen GFI v2 receipt lifecycle")) "Static validation rejects package-version-based availability inside the frozen GFI v2 contract"

    $supportingSurfaceFixture = New-StaticValidationFixture -Parent $testRoot -Name "static-supporting-surface-contradictions"
    $supportingSurfaceReadme = Join-Path $supportingSurfaceFixture "README.md"
    $supportingSurfaceContradictions = @(
        "At Unity open, the companion automatically downloads and replaces documentation.",
        "The downloaded contract may add a managed target after confirmation.",
        "The companion uses an external batch bootstrap to execute .bat setup scripts."
    ) -join "`n"
    Write-Utf8 -Path $supportingSurfaceReadme -Text ([System.IO.File]::ReadAllText($supportingSurfaceReadme) + "`n" + $supportingSurfaceContradictions + "`n")
    $supportingSurfaceValidation = Invoke-TestScript -Path $validatorScript -Arguments @("-RepositoryRoot", $supportingSurfaceFixture)
    Assert-True ($supportingSurfaceValidation.Code -ne 0 -and $supportingSurfaceValidation.Output.Contains("Companion offline startup") -and $supportingSurfaceValidation.Output.Contains("Companion confirmation and complete update") -and $supportingSurfaceValidation.Output.Contains("Companion minimal lifecycle exclusions")) "Static validation rejects startup mutation, expanded approval, and bootstrap contradictions in current supporting surfaces"
}
catch {
    $script:Failed++
    $harnessLocation = if ($_.InvocationInfo.ScriptLineNumber) { " (line $($_.InvocationInfo.ScriptLineNumber))" } else { "" }
    $script:FailureMessages.Add("Test harness exception: $($_.Exception.Message)$harnessLocation") | Out-Null
    if ($OutputFormat -eq "Text") { Write-Host "TEST HARNESS ERROR: $($_.Exception.Message)$harnessLocation" -ForegroundColor Red }
}
finally {
    try {
        $fullTestRoot = [System.IO.Path]::GetFullPath($testRoot)
        if ($fullTestRoot.StartsWith($temporaryBase, [System.StringComparison]::OrdinalIgnoreCase) -and (Split-Path -Leaf $fullTestRoot).StartsWith("ggf-automation-tests-", [System.StringComparison]::Ordinal)) {
            Remove-Item -LiteralPath $fullTestRoot -Recurse -Force -ErrorAction Stop
        }
        else { throw "Refused unsafe temporary cleanup path: $fullTestRoot" }
    }
    catch {
        $script:Failed++
        $script:FailureMessages.Add("Temporary cleanup failed: $($_.Exception.Message)") | Out-Null
    }
}

if ($OutputFormat -eq "Json") {
    [pscustomobject]@{
        status = $(if ($script:Failed -eq 0) { "PASSED" } else { "FAILED" })
        passed = $script:Passed
        failed = $script:Failed
        failures = $script:FailureMessages.ToArray()
    } | ConvertTo-Json -Depth 5
}
else {
    Write-Host "Automation test summary: passed=$script:Passed failed=$script:Failed"
    if ($script:FailureMessages.Count -gt 0) { $script:FailureMessages | ForEach-Object { Write-Host " - $_" -ForegroundColor Red } }
}
if ($script:Failed -gt 0) { exit 1 }
exit 0
