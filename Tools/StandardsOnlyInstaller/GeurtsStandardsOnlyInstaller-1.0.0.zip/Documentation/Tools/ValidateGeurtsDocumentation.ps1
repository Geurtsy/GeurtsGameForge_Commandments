# ValidateGeurtsDocumentation.ps1
# Version: 0.61.1

[CmdletBinding()]
param(
    [string]$RepositoryRoot,
    [switch]$RunAutomationTests,
    [string[]]$SourceRepositories = @(),
    [ValidateSet("Text", "Json")]
    [string]$OutputFormat = "Text"
)

$ErrorActionPreference = "Stop"
$checks = New-Object System.Collections.Generic.List[object]
$failures = New-Object System.Collections.Generic.List[string]
$automationTests = $null
$publishedSources = $null

function Add-Check([string]$Name, [bool]$Passed, [string]$Message) {
    $checks.Add([pscustomobject]@{ name = $Name; passed = $Passed; message = $Message }) | Out-Null
    if (-not $Passed) { $failures.Add("$Name - $Message") | Out-Null }
    if ($OutputFormat -eq "Text") {
        $label = if ($Passed) { "PASS" } else { "FAIL" }
        Write-Host ("[{0}] {1}: {2}" -f $label, $Name, $Message) -ForegroundColor $(if ($Passed) { "Green" } else { "Red" })
    }
}

function Get-DeclaredVersion([string]$Path) {
    $text = [System.IO.File]::ReadAllText($Path)
    foreach ($pattern in @(
        '(?im)^\s*#\s*Version:\s*(?<Version>\d+\.\d+(?:\.\d+)?)',
        '(?im)^\s*rem\s+Version:\s*(?<Version>\d+\.\d+(?:\.\d+)?)',
        '(?im)^\*\*(?:Template )?Version:\*\*\s*(?<Version>\d+\.\d+(?:\.\d+)?)',
        '(?im)^Version:\s*(?<Version>\d+\.\d+(?:\.\d+)?)'
    )) {
        $match = [regex]::Match($text, $pattern)
        if ($match.Success) { return $match.Groups["Version"].Value }
    }
    if ([System.IO.Path]::GetExtension($Path) -eq ".json") {
        try {
            $json = $text | ConvertFrom-Json
            if ($json.packageVersion) { return [string]$json.packageVersion }
            if ($json.schemaVersion) { return [string]$json.schemaVersion }
        }
        catch { return $null }
    }
    return $null
}

function Test-SafeDefinitionPath([string]$Path) {
    if ([string]::IsNullOrWhiteSpace($Path) -or [System.IO.Path]::IsPathRooted($Path) -or $Path.Contains('\') -or $Path.StartsWith('/') -or $Path.EndsWith('/')) { return $false }
    foreach ($segment in $Path.Split('/')) {
        if ([string]::IsNullOrWhiteSpace($segment) -or $segment -in @('.', '..') -or $segment.EndsWith('.') -or $segment.EndsWith(' ') -or $segment.IndexOfAny([System.IO.Path]::GetInvalidFileNameChars()) -ge 0) { return $false }
    }
    return $true
}

function Test-ExactStringSequence([object[]]$Actual, [string[]]$Expected) {
    $actualValues = @($Actual | ForEach-Object { [string]$_ })
    if ($actualValues.Count -ne $Expected.Count) { return $false }
    for ($index = 0; $index -lt $Expected.Count; $index++) {
        if ($actualValues[$index] -cne $Expected[$index]) { return $false }
    }
    return $true
}

function Test-ExactPropertySet($Object, [string[]]$Expected) {
    if ($null -eq $Object) { return $false }
    $actualNames = @($Object.PSObject.Properties | ForEach-Object { [string]$_.Name } | Sort-Object)
    $expectedNames = @($Expected | Sort-Object)
    return Test-ExactStringSequence -Actual $actualNames -Expected $expectedNames
}

function Get-ExpectedFolderProfiles([string]$Path) {
    if ($Path -in @(".github", ".github/instructions")) { return @("native-entry") }
    if ($Path -in @("Docs", "Docs/GameDesign")) { return @("full-project-structure", "gdd-scaffolding") }
    if ($Path -in @("Assets", "Assets/_Project", "Assets/_Project/Scenes", "Assets/_Project/Scenes/Boot", "Assets/_Project/Scenes/Frontend", "Assets/_Project/Scenes/Gameplay", "Assets/_Project/Scenes/Test", "Assets/_Project/Scenes/Sandbox")) { return @("full-project-structure", "bootstrap") }
    return @("full-project-structure")
}

function Get-TextHash([string]$Text) {
    if ($Text.Length -gt 0 -and $Text[0] -eq [char]0xFEFF) { $Text = $Text.Substring(1) }
    $normalized = $Text -replace "`r`n", "`n" -replace "`r", "`n"
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($normalized)
        return ([System.BitConverter]::ToString($sha.ComputeHash($bytes))).Replace("-", "").ToLowerInvariant()
    }
    finally { $sha.Dispose() }
}

function Get-GitTrackedPaths([string]$Root) {
    $previousPreference = $ErrorActionPreference
    $ErrorActionPreference = "Continue"
    try {
        $output = @(& git -c core.quotepath=false -C $Root ls-files --cached -- 2>&1)
        $exitCode = $LASTEXITCODE
        $deletedOutput = @(& git -c core.quotepath=false -C $Root ls-files --deleted -- 2>&1)
        $deletedExitCode = $LASTEXITCODE
    }
    finally { $ErrorActionPreference = $previousPreference }
    if ($exitCode -ne 0 -or $deletedExitCode -ne 0) {
        throw "Unable to enumerate Git-tracked source files: $($output -join [Environment]::NewLine)"
    }
    $deletedSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    foreach ($deletedPath in $deletedOutput) { [void]$deletedSet.Add(([string]$deletedPath).Replace('\', '/')) }
    return @($output | ForEach-Object { ([string]$_).Replace('\', '/') } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) -and -not $deletedSet.Contains($_) })
}

try {
    if ([string]::IsNullOrWhiteSpace($RepositoryRoot)) { $RepositoryRoot = Split-Path -Parent $PSScriptRoot }
    $RepositoryRoot = [System.IO.Path]::GetFullPath($RepositoryRoot)
    if (-not (Test-Path -LiteralPath $RepositoryRoot -PathType Container)) { throw "Repository root does not exist: $RepositoryRoot" }

    Import-Module (Join-Path $PSScriptRoot "GeurtsDocumentationAudience.psm1") -Force
    $manifestPath = Join-Path $RepositoryRoot "GeurtsTechniqueManifest.md"
    $manifestText = if (Test-Path -LiteralPath $manifestPath -PathType Leaf) { [System.IO.File]::ReadAllText($manifestPath) } else { "" }
    $packageMatch = [regex]::Match($manifestText, '(?im)^\*\*Version:\*\*\s*(?<Version>\d+\.\d+\.\d+)')
    $packageVersion = if ($packageMatch.Success) { $packageMatch.Groups["Version"].Value } else { $null }
    Add-Check "Package version" ($packageVersion -eq "0.61.1") "Manifest package version is $packageVersion."

    $entryPolicy = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "AI_READ_FIRST.md"))
    $versionPolicyValid = $entryPolicy.Contains("Before planning or editing any part of Geurts Game Forge") -and
        $entryPolicy.Contains("no matter how small") -and $entryPolicy.Contains("Never publish changed content under the same version") -and
        $entryPolicy.Contains('MAJOR.MINOR.PATCH') -and $entryPolicy.Contains("new version exceeds the previous published version")
    Add-Check "Mandatory reading and version policy" $versionPolicyValid "AI_READ_FIRST requires current documentation reading and an appropriate version bump for every update, however small."

    $standardsPath = Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsStandardsOnlyTechnique.md'
    $standardsText = if (Test-Path -LiteralPath $standardsPath -PathType Leaf) { [IO.File]::ReadAllText($standardsPath) } else { '' }
    $standardsValid = $entryPolicy.Contains('StandardsOnly') -and
        $manifestText.Contains('### 1.2 Usage Profiles') -and
        $manifestText.Contains('| Standards-only adoption without Geurts Game Forge packages | `GeurtsTechniques/GeurtsStandardsOnlyTechnique.md` |') -and
        $standardsText.Contains('No Geurts Unity packages are required by StandardsOnly.') -and
        $standardsText.Contains('not a new PowerShell reader mode') -and
        $standardsText.Contains('General Standards Remain Applicable') -and
        $standardsText.Contains('Steam, Odin Inspector and Quantum Console are optional in StandardsOnly, including Unity implementation.') -and
        $standardsText.Contains('No Steam SDK, Steam client, Steamworks account, App ID, Steamworks.NET package or Steam startup integration is required.') -and
        $standardsText.Contains('God Commandments Update before full folder setup') -and
        $standardsText.Contains('run the existing create-only PowerShell tool') -and
        $standardsText.Contains('Package requirements apply again to any explicitly adopted Forge integration') -and
        $standardsText.Contains('does not authorize a parallel Forge updater') -and
        $standardsText.Contains('Normal session initialization reads the selected local copy without a remote check.')
    Add-Check 'Standards-only applicability' $standardsValid 'The entry and manifest select a standalone owner that retains general standards, optional Steam/Odin/Quantum Console integrations, conditional Forge dependencies, source-only folder setup and existing lifecycle boundaries.'

    $readmeStatusText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "README.md"))
    $targetMigrationText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Migrations/v0.47.0.md"))
    $gfiMigrationText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Migrations/v0.10.0.md"))
    $gfiStatusText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"))
    $companionStatusText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"))
    $draftStatusValid = $manifestText -match '(?im)^\*\*Status:\*\*\s*Draft normative package manifest\s*$' -and $readmeStatusText -match '(?im)^\*\*Status:\*\*\s*Draft technique package\s*$' -and $gfiStatusText -match '(?im)^\*\*Status:\*\*\s*Draft normative technique\s*$' -and $companionStatusText -match '(?im)^\*\*Status:\*\*\s*Draft normative technique\s*$' -and $targetMigrationText -match '(?i)planned transition' -and $targetMigrationText -match '(?i)target-release snapshot' -and $targetMigrationText -notmatch '(?i)(?:v0\.46\.0|package v0\.46\.0)[^\r\n]{0,80}(?:is|was|has been) released'
    Add-Check "Draft target-release status" $draftStatusValid "Package v0.61.1 remains a Draft target release; its migration guide is a planned target-release snapshot, not a completed-release claim."

    $listedRecords = New-Object System.Collections.Generic.List[object]
    foreach ($match in [regex]::Matches($manifestText, '(?m)^- `(?<Path>[^`]+)` v(?<Version>\d+\.\d+\.\d+|\d+\.\d+)\s*$')) {
        $listedRecords.Add([pscustomobject]@{ Path = $match.Groups["Path"].Value; Version = $match.Groups["Version"].Value }) | Out-Null
    }
    foreach ($match in [regex]::Matches($manifestText, '(?m)^\| `(?<Path>[^`]+)` \| (?<Version>\d+\.\d+\.\d+|\d+\.\d+) \|')) {
        $listedRecords.Add([pscustomobject]@{ Path = $match.Groups["Path"].Value; Version = $match.Groups["Version"].Value }) | Out-Null
    }
    $missingListed = New-Object System.Collections.Generic.List[string]
    $versionMismatches = New-Object System.Collections.Generic.List[string]
    foreach ($record in $listedRecords) {
        $relative = $record.Path
        if ($relative.Contains("<ProjectRoot>")) { continue }
        $fullPath = Join-Path $RepositoryRoot ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        if (-not (Test-Path -LiteralPath $fullPath)) {
            $missingListed.Add($relative) | Out-Null
            continue
        }
        if (Test-Path -LiteralPath $fullPath -PathType Leaf) {
            $declared = Get-DeclaredVersion -Path $fullPath
            $listed = $record.Version
            if ([string]::IsNullOrWhiteSpace($declared)) { $versionMismatches.Add("$relative listed $listed but has no readable declared version") | Out-Null }
            elseif ($declared -ne $listed) { $versionMismatches.Add("$relative listed $listed but declares $declared") | Out-Null }
        }
    }
    Add-Check "Manifest-listed files" ($listedRecords.Count -gt 0 -and $missingListed.Count -eq 0) $(if ($missingListed.Count) { "Missing: " + ($missingListed -join ", ") } else { "$($listedRecords.Count) listed files exist." })
    Add-Check "Listed file versions" ($versionMismatches.Count -eq 0) $(if ($versionMismatches.Count) { $versionMismatches -join "; " } else { "Manifest-listed versions agree with declared file versions." })

    $trackedPaths = @(Get-GitTrackedPaths -Root $RepositoryRoot)
    $trackedSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    $trackedInventoryFailures = New-Object System.Collections.Generic.List[string]
    foreach ($trackedPath in $trackedPaths) {
        if (-not $trackedSet.Add([string]$trackedPath)) { $trackedInventoryFailures.Add("duplicate Git path '$trackedPath'") | Out-Null }
    }
    $audienceFailures = New-Object System.Collections.Generic.List[string]
    foreach ($relative in @($listedRecords.Path | Where-Object { $_.EndsWith('.md') } | Sort-Object -Unique)) {
        try {
            $sourceText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative))
            foreach ($mode in @('GameUse', 'ForgeDevelopment')) {
                $filtered = ConvertTo-GeurtsAudienceText -Text $sourceText -Mode $mode
                if (-not $relative.StartsWith('Tools/AIAgentInstructionTemplates/') -and -not $filtered.HasFileTag) {
                    throw 'Documentation requires an explicit file audience tag.'
                }
                if ($relative -in @('AI_READ_FIRST.md', 'GeurtsTechniqueManifest.md') -and
                    ($filtered.FileAudience -cne 'AI-READ' -or $filtered.SkippedLines -gt 0)) {
                    throw 'Entry and manifest must remain completely AI-readable.'
                }
            }
        }
        catch { $audienceFailures.Add("${relative}: $($_.Exception.Message)") | Out-Null }
    }
    Add-Check "Documentation audience tags" ($audienceFailures.Count -eq 0) $(if ($audienceFailures.Count) { $audienceFailures -join '; ' } else { 'Audience tags are valid in both modes; bootstrap rules and literal templates remain readable.' })

    $sectionFailures = New-Object 'System.Collections.Generic.List[string]'
    foreach ($rule in @('<!-- GEURTS-READ-SECTIONS:BEGIN -->', '<!-- GEURTS-READ-SECTIONS:END -->',
        'A new unlisted section is required by default', 'There is no output cap or silent truncation',
        'It never counts as reading the rules', 'Changelogs and historical release summaries are never mandatory routine reading')) {
        if (-not $manifestText.Contains($rule)) { $sectionFailures.Add("Missing efficient-reading boundary: $rule") | Out-Null }
    }
    foreach ($relative in @($listedRecords.Path | Where-Object { $_.EndsWith('.md') } | Sort-Object -Unique)) {
        try {
            $preview = Read-GeurtsAudienceDocument -RepositoryRoot $RepositoryRoot -Document $relative -Mode ForgeDevelopment -IncludeHuman -Preview
            if (-not $preview.PreviewOnly -or $preview.Content.Length -ne 0 -or $preview.ReturnedCharacters -ne 0) {
                throw 'Preview must return metadata only.'
            }
        }
        catch { $sectionFailures.Add("${relative}: $($_.Exception.Message)") | Out-Null }
    }
    Add-Check 'Controlled section registry and preview' ($sectionFailures.Count -eq 0) $(if ($sectionFailures.Count) { $sectionFailures -join '; ' } else { 'Every controlled heading resolves uniquely in registered, non-protected Markdown; previews contain no document text and new untabled rules remain required.' })

    $registrySection = [regex]::Match($manifestText, '(?ms)<!-- GEURTS-PACKAGE-FILES:BEGIN -->(?<Body>.*?)<!-- GEURTS-PACKAGE-FILES:END -->')
    $registrySet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    if (-not $registrySection.Success -or [regex]::Matches($manifestText, 'GEURTS-PACKAGE-FILES:BEGIN').Count -ne 1 -or [regex]::Matches($manifestText, 'GEURTS-PACKAGE-FILES:END').Count -ne 1) {
        $trackedInventoryFailures.Add("package registry markers are missing or duplicated") | Out-Null
    }
    else {
        foreach ($row in [regex]::Matches($registrySection.Groups["Body"].Value, '(?m)^\| `(?<Path>[^`]+)` \| (?<Version>\d+\.\d+\.\d+|\d+\.\d+) \|')) {
            $registryPath = $row.Groups["Path"].Value
            if (-not $registrySet.Add($registryPath)) { $trackedInventoryFailures.Add("duplicate registry path '$registryPath'") | Out-Null }
        }
    }
    foreach ($trackedPath in $trackedSet) {
        if (-not $registrySet.Contains($trackedPath)) { $trackedInventoryFailures.Add("tracked path missing from registry: $trackedPath") | Out-Null }
    }
    foreach ($registryPath in $registrySet) {
        if (-not $trackedSet.Contains($registryPath)) { $trackedInventoryFailures.Add("registry path is not Git-tracked: $registryPath") | Out-Null }
    }
    Add-Check "Git-tracked package inventory" ($trackedInventoryFailures.Count -eq 0 -and $trackedSet.Count -gt 0 -and $trackedSet.Count -eq $registrySet.Count) $(if ($trackedInventoryFailures.Count) { $trackedInventoryFailures -join "; " } else { "The manifest registry exactly matches all $($trackedSet.Count) Git-tracked source files." })

    $expectedTopLevel = @(".gitattributes", "AI_READ_FIRST.md", "GeurtsTechniqueManifest.md", "GeurtsTechniques", "History", "Ideas", "Migrations", "README.md", "Tools") | Sort-Object
    $actualTopLevel = @($trackedPaths | ForEach-Object { ($_ -split '/')[0] } | Sort-Object -Unique)
    $topLevelValid = $actualTopLevel.Count -eq $expectedTopLevel.Count
    if ($topLevelValid) {
        for ($topLevelIndex = 0; $topLevelIndex -lt $expectedTopLevel.Count; $topLevelIndex++) {
            if ([string]$actualTopLevel[$topLevelIndex] -cne [string]$expectedTopLevel[$topLevelIndex]) { $topLevelValid = $false; break }
        }
    }
    $currentHiddenTracked = @($trackedPaths | Where-Object { $_ -match '(^|/)\.[^/]+' })
    $hiddenPathsValid = $currentHiddenTracked.Count -eq 1 -and $currentHiddenTracked[0] -ceq ".gitattributes"
    Add-Check "Current source tree shape" ($topLevelValid -and $hiddenPathsValid) $(if (-not $topLevelValid) { "Top-level tracked entries differ: " + ($actualTopLevel -join ", ") } elseif (-not $hiddenPathsValid) { "Current tracked hidden paths differ: " + ($currentHiddenTracked -join ", ") } else { "The nine confirmed top-level entries, including optional History archives, are tracked; .gitattributes is the sole tracked hidden path." })

    $resolverFailures = New-Object System.Collections.Generic.List[string]
    $resolverSection = [regex]::Match($manifestText, '(?ms)^## 1\. Manifest Resolver\s*(?<Body>.*?)(?=^## 2\.)')
    $subjectSection = [regex]::Match($manifestText, '(?ms)^## 2\. Subject Ownership and Applicability\s*(?<Body>.*?)(?=^## 3\.)')
    if (-not $resolverSection.Success) { $resolverFailures.Add("manifest resolver section is missing") | Out-Null }
    if (-not $subjectSection.Success) { $resolverFailures.Add("subject ownership and applicability section is missing") | Out-Null }
    if ($resolverSection.Success) {
        $resolverBody = $resolverSection.Groups["Body"].Value
        foreach ($term in @("package-file selection", "versions", "subject ownership", "applicability", "post-entry reading order", "cross-document conflicts")) {
            if ($resolverBody.IndexOf($term, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) { $resolverFailures.Add("resolver omits $term") | Out-Null }
        }
        $sequenceLines = @([regex]::Matches($resolverBody, '(?m)^(?<Number>[0-9]+)\.\s+(?<Text>[^\r\n]+)\r?$'))
        if ($sequenceLines.Count -lt 6) { $resolverFailures.Add("numbered file-read sequence is missing or incomplete") | Out-Null }
        else {
            for ($sequenceIndex = 0; $sequenceIndex -lt $sequenceLines.Count; $sequenceIndex++) {
                if ([int]$sequenceLines[$sequenceIndex].Groups["Number"].Value -ne ($sequenceIndex + 1)) { $resolverFailures.Add("numbered file-read sequence is not unique and contiguous") | Out-Null; break }
            }
            $firstRead = $sequenceLines[0].Groups["Text"].Value
            $secondRead = $sequenceLines[1].Groups["Text"].Value
            $thirdRead = $sequenceLines[2].Groups["Text"].Value
            if ($firstRead.IndexOf("AI_READ_FIRST.md", [System.StringComparison]::Ordinal) -lt 0 -or $secondRead.IndexOf("manifest", [System.StringComparison]::OrdinalIgnoreCase) -lt 0) { $resolverFailures.Add("file-read sequence does not start AI_READ_FIRST.md then manifest") | Out-Null }
            if (@($sequenceLines | Where-Object { $_.Groups["Text"].Value -match '(?i)current user|user instruction' }).Count -gt 0) { $resolverFailures.Add("user authority is incorrectly represented as a file-read item") | Out-Null }
        }
        $genericPosition = $resolverBody.IndexOf("selected generic subject techniques", [System.StringComparison]::OrdinalIgnoreCase)
        $companionPosition = $resolverBody.IndexOf("selected Commandments Companion", [System.StringComparison]::OrdinalIgnoreCase)
        $gfiPosition = $resolverBody.IndexOf("frozen Game Forge Intelligence", [System.StringComparison]::OrdinalIgnoreCase)
        $gddPosition = $resolverBody.IndexOf("project-specific game-design", [System.StringComparison]::OrdinalIgnoreCase)
        $productPosition = $resolverBody.IndexOf("product- or plugin-owned", [System.StringComparison]::OrdinalIgnoreCase)
        if ($companionPosition -lt 0 -or $gfiPosition -le $companionPosition -or $genericPosition -le $gfiPosition -or $gddPosition -le $genericPosition -or $productPosition -le $gddPosition) { $resolverFailures.Add("post-entry companion, optional integration, generic, project-design, and subordinate-product order is not deterministic") | Out-Null }
    }

    $expectedSubjectOwners = @(
        "GeurtsTechniques/GeurtsStandardsOnlyTechnique.md",
        "GeurtsTechniques/GeurtsNamingTechnique.md",
        "GeurtsTechniques/GeurtsTechnicalTechnique.md",
        "GeurtsTechniques/GeurtsUnityTechnique.md",
        "GeurtsTechniques/GeurtsSteamIntegrationTechnique.md",
        "GeurtsTechniques/GeurtsCodeTechnique.md",
        "GeurtsTechniques/GeurtsAuthoringTechnique.md",
        "GeurtsTechniques/GeurtsBootstrapTechnique.md",
        "GeurtsTechniques/GeurtsAudioTechnique.md",
        "GeurtsTechniques/GeurtsGameAITechnique.md",
        "GeurtsTechniques/GeurtsCommandsTechnique.md",
        "GeurtsTechniques/GeurtsMultiplayerTechnique.md",
        "GeurtsTechniques/GeurtsBigBangTechnique.md",
        "GeurtsTechniques/GeurtsForgeSetupTechnique.md",
        "GeurtsTechniques/GeurtsForgeSetupContract.json",
        "GeurtsTechniques/GeurtsEditorUIThemeTechnique.md",
        "GeurtsTechniques/GeurtsEditorAppearanceTechnique.md",
        "GeurtsTechniques/GeurtsDiagnosticsTechnique.md",
        "GeurtsTechniques/GeurtsGameForgeAutomationTechnique.md",
        "GeurtsTechniques/GeurtsFolderStructureTechnique.md",
        "GeurtsTechniques/GeurtsFolderStructureDefinition.json",
        "GeurtsTechniques/GeurtsAIAgentSetupTechnique.md",
        "GeurtsTechniques/GeurtsGameDesignDocumentationTechnique.md",
        "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md",
        "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json",
        "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md",
        "GeurtsTechniques/GeurtsGitIgnoreTechnique.md",
        "GeurtsTechniques/GeurtsGitAttributesTechnique.md",
        "GeurtsTechniques/GeurtsAgentTechnique.md",
        "GeurtsTechniques/GeurtsAIResponseControlTechnique_V1.1.md"
    )
    $subjectOwners = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    if ($subjectSection.Success) {
        $subjectRows = @([regex]::Matches($subjectSection.Groups["Body"].Value, '(?m)^\| (?<Subject>[^|]+) \| `(?<Owner>[^`]+)` \| (?<When>[^|]+) \|\r?$'))
        foreach ($subjectRow in $subjectRows) {
            $owner = $subjectRow.Groups["Owner"].Value
            if (-not $subjectOwners.Add($owner)) { $resolverFailures.Add("duplicate manifest subject owner '$owner'") | Out-Null }
            if (-not $registrySet.Contains($owner) -or -not (Test-Path -LiteralPath (Join-Path $RepositoryRoot $owner) -PathType Leaf)) { $resolverFailures.Add("selected owner is absent from the tracked package: $owner") | Out-Null }
            if ([string]::IsNullOrWhiteSpace($subjectRow.Groups["When"].Value)) { $resolverFailures.Add("selected owner has no applicability rule: $owner") | Out-Null }
        }
        if ($subjectRows.Count -ne $expectedSubjectOwners.Count) { $resolverFailures.Add("subject-owner row count is not exactly $($expectedSubjectOwners.Count)") | Out-Null }
        foreach ($expectedOwner in $expectedSubjectOwners) { if (-not $subjectOwners.Contains($expectedOwner)) { $resolverFailures.Add("missing manifest subject owner '$expectedOwner'") | Out-Null } }
        if ($subjectSection.Groups["Body"].Value.IndexOf("current user's explicit instruction", [System.StringComparison]::OrdinalIgnoreCase) -lt 0 -or $subjectSection.Groups["Body"].Value -notmatch '(?i)(?:material conflict.*(?:surface|ask)|(?:surface|ask).*material conflict)') { $resolverFailures.Add("user authority and unresolved material conflicts are not handled in the conflict section") | Out-Null }
    }

    $alternateResolverFiles = New-Object System.Collections.Generic.List[string]
    foreach ($technique in @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques") -Filter "*.md" -File)) {
        if ($technique.Name -ceq "GeurtsGameForgeIntelligenceIntegrationContract.md") { continue }
        $techniqueText = [System.IO.File]::ReadAllText($technique.FullName)
        if ($techniqueText -match '(?im)^##\s+(?:[0-9]+\.\s*)?Manifest Resolver\s*$' -or $techniqueText -match '(?im)^##\s+(?:[0-9]+\.\s*)?Subject Ownership and Applicability\s*$' -or $techniqueText -match '(?m)^\|\s*Subject\s*\|\s*Manifest-selected owner\s*\|') { $alternateResolverFiles.Add($technique.Name) | Out-Null }
    }
    if ($alternateResolverFiles.Count -gt 0) { $resolverFailures.Add("competing cross-document resolver structure: " + ($alternateResolverFiles -join ", ")) | Out-Null }
    Add-Check "Central manifest resolver" ($resolverFailures.Count -eq 0) $(if ($resolverFailures.Count) { $resolverFailures -join "; " } else { "The manifest alone defines a contiguous AI_READ_FIRST-to-manifest read sequence, selected owners, applicability, ordering, and conflict resolution; all selected paths exist." })

    $namingPath = Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsNamingTechnique.md'
    $namingText = if (Test-Path -LiteralPath $namingPath -PathType Leaf) { [System.IO.File]::ReadAllText($namingPath) } else { '' }
    $namingFailures = New-Object 'System.Collections.Generic.List[string]'
    $sceneRegistry = [regex]::Match($namingText, '(?ms)^### 5\.1 Scene Objects.*?(?=^#### Primary Role Classification)')
    $assetRegistry = [regex]::Match($namingText, '(?ms)^### 5\.2 Project Assets.*?(?=^#### Asset Classification)')
    $sceneRows = @([regex]::Matches($sceneRegistry.Value, '(?m)^\| `(?<Type>[A-Z][A-Z0-9]*)` \| [^|\r\n]+ \| `(?<Example>[^`]+)` \|\r?$'))
    $assetRows = @([regex]::Matches($assetRegistry.Value, '(?m)^\| [^|\r\n]+ \| `(?<Type>[A-Z][A-Z0-9]*)` \| [^|\r\n]+ \| `(?<Example>[^`]+)` \|\r?$'))
    if ($sceneRows.Count -ne 18 -or $assetRows.Count -ne 58) { $namingFailures.Add('Naming 0.1.1 must retain 18 scene roles and 58 asset kinds') | Out-Null }
    $allNamingRows = @($sceneRows) + @($assetRows)
    foreach ($group in @(@{ Label = 'scene'; Rows = $sceneRows }, @{ Label = 'asset'; Rows = $assetRows })) {
        $typeSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        foreach ($row in $group.Rows) {
            $type = $row.Groups['Type'].Value
            if (-not $typeSet.Add($type)) { $namingFailures.Add("duplicate $($group.Label) type: $type") | Out-Null }
            if ($row.Groups['Example'].Value -cnotmatch ('^' + $type + '_[A-Z][A-Za-z0-9]*_[A-Z][A-Za-z0-9]*(?:_[0-9]+)?$')) { $namingFailures.Add("invalid $($group.Label) example for $type") | Out-Null }
        }
        if (-not $typeSet.Contains('MISC') -or -not $typeSet.Contains('VID')) { $namingFailures.Add("$($group.Label) registry omits a shared VID/MISC type") | Out-Null }
    }
    $literalRows = @($allNamingRows | ForEach-Object { $_.Value.TrimEnd([char]13) }) -join "`n"
    if ((Get-TextHash -Text $literalRows) -cne '1ef452570b34a01299a088b6b49d78b757fe9bdf3e443ddfa2e96b9a0a66e9ac') { $namingFailures.Add('Naming 0.1.1 registry meanings or examples differ from the approved handoff') | Out-Null }
    foreach ($requiredRule in @('Scripts MUST NOT use `TYPE_Category_Description`', 'A prefab asset''s base filename MUST match its authored root GameObject name', 'MUST be used sparingly', 'CapitalCamelCase', 'Unity `.meta` files, GUIDs, serialized references', 'Do not silently create an abbreviation', 'Existing-content migrations, consumer documentation updates, and enforcement tooling require their own task scope')) {
        if (-not $namingText.Contains($requiredRule)) { $namingFailures.Add("missing naming rule: $requiredRule") | Out-Null }
    }
    if ($namingText -notmatch '(?m)^<!-- GEURTS-AUDIENCE: AI-READ -->\r?$' -or $namingText -notmatch '(?im)^\*\*Status:\*\* Draft normative technique\s*$') { $namingFailures.Add('Naming must use the package normative status and AI-READ audience') | Out-Null }
    $namingExpectedContent = [regex]::Replace($namingText, '\A<!-- GEURTS-AUDIENCE: AI-READ -->\r?\n', '')
    foreach ($mode in @('GameUse', 'ForgeDevelopment')) {
        try {
            $namingRead = ConvertTo-GeurtsAudienceText -Text $namingText -Mode $mode
            if ($namingRead.SkippedLines -ne 0 -or $namingRead.Content -cne $namingExpectedContent) { $namingFailures.Add("Naming rules are hidden in $mode") | Out-Null }
        } catch { $namingFailures.Add("Invalid Naming audience tags: $($_.Exception.Message)") | Out-Null }
    }
    $namingStructure = [regex]::Matches($namingText, '(?ms)^```regex\r?\n(?<Pattern>[^\r\n]+)\r?\n```')
    if ($namingStructure.Count -ne 1) { $namingFailures.Add('Naming must supply one structural expression') | Out-Null }
    else {
        try {
            $namingPattern = New-Object System.Text.RegularExpressions.Regex($namingStructure[0].Groups['Pattern'].Value)
            foreach ($validName in @('SND_UserInterface_SciFiClick', 'FX_Spirits_OrbWavesAndSparks_0', 'FX_Spirits_OrbWavesAndSparks_125', 'FX_Spirits_OrbWavesAndSparks_1', 'FX_Spirits_OrbWavesAndSparks_12', 'OBJ_Environment_SciFiDoor01')) {
                if (-not $namingPattern.IsMatch($validName)) { $namingFailures.Add("Naming rejects valid base/numbered name: $validName") | Out-Null }
            }
            foreach ($invalidName in @('FX_Spirits_OrbWavesAndSparks_007', 'FX_Spirits_OrbWavesAndSparks_00', 'FX_Spirits_OrbWavesAndSparks_', 'FX_Spirits_OrbWavesAndSparks_Final', 'FX_Spirits_OrbWavesAndSparks_1a', 'FX_Spirits_OrbWavesAndSparks_-1', 'FX_Spirits_OrbWavesAndSparks_1.2', 'FX_Spirits_OrbWavesAndSparks_1_2', 'FX_Spirits_OrbWavesAndSparks_ 1', 'fx_Spirits_OrbWavesAndSparks_1', 'FX_spirits_OrbWavesAndSparks_1')) {
                if ($namingPattern.IsMatch($invalidName)) { $namingFailures.Add("Naming accepts invalid structure: $invalidName") | Out-Null }
            }
        } catch { $namingFailures.Add('Naming structural expression is invalid') | Out-Null }
    }
    foreach ($requiredRule in @('Start a new numbered series at `0`', 'Preserve an existing valid numeric suffix when Type, Category, Description or the destination folder changes', 'leading zeros', 'VersionNumber (optional)', 'The number is optional.', 'Existing three-part names with numbers inside Description', 'any optional VersionNumber in both names', 'TYPE_CategoryName_DescriptionName_VersionNumber')) {
        if (-not $namingText.Contains($requiredRule)) { $namingFailures.Add("missing numeric naming rule: $requiredRule") | Out-Null }
    }
    if ($namingText.Contains('Contain exactly three non-empty segments') -or $namingText.Contains('do not add a fourth underscore-separated segment')) { $namingFailures.Add('Naming still prohibits the optional numeric segment') | Out-Null }
    Add-Check 'Naming Technique policy' ($namingFailures.Count -eq 0) $(if ($namingFailures.Count) { $namingFailures -join '; ' } else { 'All 76 approved registry entries, prefab/script exceptions, preservation rules and AI-readable policy remain intact.' })
    $namingOwner = [regex]::Match($subjectSection.Value, '(?m)^\| First-party asset, scene object, prefab root and script names \| `GeurtsTechniques/GeurtsNamingTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    $namingRoutingValid = $namingOwner.Success -and $resolverBody.Contains('Technical; Unity; Steam Integration; Code; Authoring; Bootstrap; Audio; GameAI; Commands; Multiplayer; Naming; Brick Contract') -and $registrySet.Contains('GeurtsTechniques/GeurtsNamingTechnique.md')
    foreach ($action in @('creating', 'naming', 'renaming', 'reviewing', 'first-party')) {
        if (-not $namingOwner.Groups['When'].Value.Contains($action)) { $namingRoutingValid = $false }
    }
    foreach ($relative in @('GeurtsTechniques/GeurtsTechnicalTechnique.md', 'GeurtsTechniques/GeurtsFolderStructureTechnique.md')) {
        if (-not [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative)).Contains('(GeurtsNamingTechnique.md)')) { $namingRoutingValid = $false }
    }
    Add-Check 'Naming Technique routing' $namingRoutingValid 'Naming is selected through the manifest after Technical, referenced by existing subject owners, and included in package membership without replacing folder, ID or code-symbol contracts.'

    # Content policy preserves independent admission, native evidence and real releases.
    $steamRelative = 'GeurtsTechniques/GeurtsSteamIntegrationTechnique.md'
    $steamPath = Join-Path $RepositoryRoot $steamRelative
    $steamText = if (Test-Path -LiteralPath $steamPath -PathType Leaf) { [IO.File]::ReadAllText($steamPath) } else { '' }
    $steamOwner = [regex]::Match($subjectSection.Value, '(?m)^\| Steam preparation, platform services and Windows release evidence \| `GeurtsTechniques/GeurtsSteamIntegrationTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    $steamRoutingValid = $steamOwner.Success -and $registrySet.Contains($steamRelative) -and
        [regex]::Matches($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsSteamIntegrationTechnique\.md` \| 0\.3\.0 \|').Count -eq 1 -and
        $resolverBody.Contains('Technical; Unity; Steam Integration; Code;')
    foreach ($topic in @('Steamworks.NET', 'BigBang', 'platform-service', 'bootstrap/native', 'build/distribution')) {
        if (-not $steamOwner.Groups['When'].Value.Contains($topic)) { $steamRoutingValid = $false }
    }
    foreach ($relative in @('GeurtsTechnicalTechnique.md', 'GeurtsUnityTechnique.md', 'GeurtsBrickContract.md', 'GeurtsForgeSetupTechnique.md', 'GeurtsBigBangTechnique.md')) {
        if (-not [IO.File]::ReadAllText((Join-Path $RepositoryRoot ('GeurtsTechniques/' + $relative))).Contains('(GeurtsSteamIntegrationTechnique.md)')) { $steamRoutingValid = $false }
    }
    Add-Check 'Steam manifest routing' $steamRoutingValid 'One Steam owner follows Unity, covers prerequisites/services/builds, and is referenced by the affected subject owners.'

    $steamAudienceValid = $steamText -match '(?im)^\*\*Version:\*\*\s*0\.3\.0\s*$' -and $steamText.StartsWith('<!-- GEURTS-AUDIENCE: AI-READ -->')
    foreach ($mode in @('GameUse', 'ForgeDevelopment')) {
        try {
            $steamRead = Read-GeurtsAudienceDocument -RepositoryRoot $RepositoryRoot -Document $steamRelative -Mode $mode
            if ($steamRead.SkippedLines -ne 0 -or -not $steamRead.Content.Contains('## BigBang admission and compile independence') -or -not $steamRead.Content.Contains('## Evidence and acceptance')) { $steamAudienceValid = $false }
        } catch { $steamAudienceValid = $false }
    }
    Add-Check 'Steam audience and metadata' $steamAudienceValid 'Steam prerequisite, implementation status and acceptance requirements remain completely readable in both modes.'

    $steamScopeValid = $steamText -match '(?i)Steam on Windows x64 is the primary release target' -and
        $steamText -match '(?i)Steam Deck, Proton, SteamOS, Linux and macOS are outside' -and
        $steamText -match '(?i)prepared for Steam development' -and
        $steamText -match '(?i)before obtaining a game AppID or configuring a store page, depots, branches, SteamPipe uploads or a release pipeline' -and
        $steamText -match '(?i)stable release verified against the exact Editor, Windows x64, scripting backend' -and
        $steamText -match '(?i)immutable Git commit' -and $steamText -match '(?i)consuming project.*Packages/manifest\.json' -and
        $steamText -match '(?i)Git URLs never belong in another package' -and
        $steamText -notmatch '(?i)(?:Steam Deck|Proton|SteamOS) (?:support|certification) is required'
    Add-Check 'Steam target and preparation boundary' $steamScopeValid 'Windows x64 and pinned wrapper compatibility are explicit; Account-free optional-service/draft preparation is explicit; real AppID/distribution acceptance and other platforms remain pending.'

    $steamBigBangText = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsBigBangTechnique.md'))
    $steamAdmissionValid = $steamText -match '(?i)Steamworks\.NET is required before Install God and BigBang.s existing-God handoff' -and
        $steamText -match '(?i)Steam API through Steamworks\.NET is mandatory for Geurts Unity project setup' -and
        $steamText -match '(?i)BigBang must still compile and open when Steamworks\.NET, God, Odin Inspector and Quantum Console are absent' -and
        $steamText -match '(?i)Local prerequisite inspection must not initialize Steam, load native Steam libraries, contact Steam or require a running client, login, AppID, account entitlement or network connectivity' -and
        $steamText -match '(?i)must not execute vendor static constructors or methods' -and
        $steamText -match '(?i)Revalidate local evidence immediately before installation dispatch' -and
        $steamText -match '(?i)failed compilation.*invalidate evidence' -and
        $steamText -match '(?i)Do not force reinstall or downgrade God' -and
        $steamBigBangText -match '(?i)Steamworks\.NET must pass local prerequisite checks before \*\*Install God\*\* and \*\*Open Game Forge God\*\*' -and
        $steamBigBangText -match '(?i)Red.*Orange.*Green' -and
        $steamBigBangText -match '(?i)BigBang must compile and open with Steamworks\.NET absent' -and
        $steamBigBangText -match '(?i)local check must not initialize Steam, load native Steam libraries, request the network or require a client, login, AppID or account entitlement' -and
        $steamText -notmatch '(?i)(?:local prerequisite (?:check|inspection)|Check prerequisites) (?:must|requires?) (?:initialize Steam|a Steam login|a running Steam client|native initialization|an AppID)'
    foreach ($relative in @('GeurtsTechnicalTechnique.md', 'GeurtsUnityTechnique.md', 'GeurtsBrickContract.md')) {
        if ([IO.File]::ReadAllText((Join-Path $RepositoryRoot ('GeurtsTechniques/' + $relative))) -notmatch '(?i)Steam API[^\r\n]{0,100}(?:mandatory|required)') { $steamAdmissionValid = $false }
    }
    Add-Check 'Steam independent local prerequisite' $steamAdmissionValid 'Installation and handoff require local Steam API evidence; numbered Red/Orange/Green steps preserve independent compilation and native-free local inspection.'

    $steamOwnershipValid = $steamText -match '(?i)God remains the only mandatory shared Geurts brick' -and
        $steamText -match '(?i)Steam provider is an optional peer' -and
        $steamText -match '(?i)God must not acquire Steamworks\.NET references or native initialization' -and
        $steamText -match '(?i)vendor-neutral' -and $steamText -match '(?i)Steam brick owns wrapper/native calls' -and
        $steamText -match '(?i)ordinary retained \*\*`SCN_BigBang`' -and
        $steamText -match '(?i)do not use direct or indirect `DontDestroyOnLoad`' -and
        $steamText -match '(?i)Native Steam activation is off by default in local unconfigured development' -and
        $steamText -match '(?i)one owned callback pump on Unity.s main thread' -and
        $steamText -match '(?i)Shutdown belongs only to the owner of successful initialization' -and
        $steamText -notmatch '(?i)(?:God|BigBang) (?:must|shall) (?:depend on|reference) (?:Steamworks\.NET|the Steam brick)'
    Add-Check 'Steam optional provider and lifetime' $steamOwnershipValid 'Optional native ownership preserves vendor-neutral God, retained scenes, default-off local activation and one callback/cleanup lifetime.'

    $steamEvidenceValid = $steamText -match '(?i)Windows x64 Build Profile' -and
        $steamText -match '(?i)Mono success does not establish IL2CPP/AOT' -and
        $steamText -match '(?i)Customer artifact checks must reject `steam_appid\.txt`' -and
        $steamText -match '(?i)Sample AppID \*\*480\*\* is a development example' -and
        $steamText -match '(?i)real graphics-enabled Windows standalone launched through Steam' -and
        $steamText -match '(?i)not new shared setup statuses' -and
        $steamText -match '(?i)God settings store module configuration, not gameplay saves' -and
        $steamText -match '(?i)cloud is a separate optional service' -and
        $steamText -match '(?i)Released Save and Load supplies local gameplay persistence'
    foreach ($dimension in @('Prerequisite ready', 'Prepared for Steam development', 'Integration verified', 'Release validated')) {
        if ($steamText -notmatch ('(?m)^\| ' + [regex]::Escape($dimension) + ' \|')) { $steamEvidenceValid = $false }
    }
    Add-Check 'Steam evidence and artifacts' $steamEvidenceValid 'Four evidence dimensions preserve shared statuses, real player gates, development-artifact exclusion and local gameplay persistence and separate cloud/account acceptance.'

    $steamExtendedValid = $steamText.Contains('## Account-free distribution preparation') -and
        $steamText -match '(?i)unresolved placeholders, Preview=1, no SetLive' -and
        $steamText -match '(?i)partner AppID/depot IDs remain zero' -and
        $steamText -match '(?i)matching clean customer-build receipt and unchanged complete artifact inventory' -and
        $steamText -match '(?i)cache changes and server acknowledgements are separate outcomes' -and
        $steamText -match '(?i)cache review is not a cross-device atomic transaction' -and
        $steamText -match '(?i)must never claim native writes were undone' -and
        $steamText -match '(?i)do not imply automatic Save and Load slot synchronization' -and
        $steamText -match '(?i)Real-account service and customer distribution acceptance remain unverified'
    Add-Check 'Steam optional services and account-free drafts' $steamExtendedValid 'Explicit cache/server evidence, bounded reviewed cloud data and unresolved preview-only drafts preserve the account-free boundary and pending real Steam acceptance.'

    $steamCatalogue = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsBrickCatalogue.json')) | ConvertFrom-Json
    $steamEntries = @($steamCatalogue.bricks | Where-Object { $_.id -ceq 'com.geurts.gameforge.steam' })
    $steamGodEntries = @($steamCatalogue.bricks | Where-Object { $_.id -ceq 'com.geurts.gameforge.god' })
    $steamInstallerEntries = @($steamCatalogue.bricks | Where-Object { $_.id -ceq 'com.geurts.gameforge.bigbang' })
    $steamPublicationValid = $steamText -match '(?i)Native Steam integration and overlay remain unverified' -and
        $steamBigBangText -match '(?i)published catalogue now identifies BigBang with the local Steam prerequisite gate' -and
        $steamText -notmatch '(?i)Native Steam integration and overlay are verified' -and
        $steamEntries.Count -eq 1 -and $steamGodEntries.Count -eq 1 -and $steamInstallerEntries.Count -eq 1 -and
        [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'Migrations/v0.51.0.md')).Contains('pending brick implementation') -and
        [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'Migrations/v0.52.0.md')).Contains('manual')
    if ($steamPublicationValid) {
        $steamEntry = $steamEntries[0]
        $steamPublicationValid = $steamEntry.released -and -not $steamEntry.developmentOnly -and
            [version]$steamEntry.version -ge [version]'0.1.0' -and
            $steamEntry.sourceKind -ceq 'git' -and
            $steamEntry.source -cmatch '^https://github\.com/Geurtsy/com\.geurts\.gameforge\.steam\.git#[a-f0-9]{40}$' -and
            @($steamEntry.dependencies | Where-Object { $_.id -ceq 'com.geurts.gameforge.god' -and [version]$_.minimumVersion -ge [version]'0.37.0' }).Count -eq 1 -and
            [version]$steamGodEntries[0].version -ge [version]'0.37.0' -and [version]$steamInstallerEntries[0].version -ge [version]'0.6.0' -and
            $steamEntry.description -match '(?i)native.*unverified' -and
            ([IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsGameForgeAutomationTechnique.md')).Contains('Preserve manual consumer installation.'))
    }
    Add-Check 'Steam policy publication boundary' $steamPublicationValid 'Released local preparation has exact owner pins and neutral God prerequisites; native/overlay and distribution acceptance remain separate and manual adoption is explicit.'
    $aiReadFirstText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "AI_READ_FIRST.md"))
    $aiCommitBoundaryValid = $aiReadFirstText -match "(?i)active package.?s single validated commit" -and $aiReadFirstText -notmatch '(?i)(?:manifest[^\r\n]{0,80}select(?:s|ed)?[^\r\n]{0,40}commit|commit[^\r\n]{0,40}selected by (?:the )?manifest)'
    $aiRouterValid = $aiReadFirstText -match '(?i)immediately continue to' -and $aiReadFirstText -match '(?i)GeurtsTechniqueManifest\.md' -and $aiReadFirstText -match '(?i)Do not inspect or select project GDD files here' -and $aiReadFirstText -match '(?i)manifest first decides whether the GDD Technique applies' -and $aiReadFirstText -notmatch '(?i)timestamp|fingerprint' -and $aiCommitBoundaryValid
    Add-Check "Documentation entry router" $aiRouterValid "AI_READ_FIRST routes immediately to the manifest, refers to the active package's validated commit without making the manifest select Git state, and performs no pre-manifest GDD inspection or fingerprint selection."

    $gitIgnoreFailures = New-Object System.Collections.Generic.List[string]
    $gitIgnoreRelative = "GeurtsTechniques/GeurtsGitIgnoreTechnique.md"
    $gitIgnorePath = Join-Path $RepositoryRoot $gitIgnoreRelative
    $gitIgnoreText = $null
    if (-not (Test-Path -LiteralPath $gitIgnorePath -PathType Leaf)) {
        $gitIgnoreFailures.Add("technique is missing") | Out-Null
    }
    else {
        try {
            $gitIgnoreBytes = [System.IO.File]::ReadAllBytes($gitIgnorePath)
            $gitIgnoreOffset = 0
            if ($gitIgnoreBytes.Length -ge 3 -and $gitIgnoreBytes[0] -eq 0xEF -and $gitIgnoreBytes[1] -eq 0xBB -and $gitIgnoreBytes[2] -eq 0xBF) { $gitIgnoreOffset = 3 }
            $strictUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
            $gitIgnoreText = $strictUtf8.GetString($gitIgnoreBytes, $gitIgnoreOffset, $gitIgnoreBytes.Length - $gitIgnoreOffset)
        }
        catch { $gitIgnoreFailures.Add("technique is not valid UTF-8") | Out-Null }
    }

    if ($null -ne $gitIgnoreText) {
        if ([regex]::Matches($gitIgnoreText, 'GEURTS-GITIGNORE-BEGIN').Count -ne 1 -or [regex]::Matches($gitIgnoreText, 'GEURTS-GITIGNORE-END').Count -ne 1) {
            $gitIgnoreFailures.Add("marker count is invalid") | Out-Null
        }
        $gitIgnorePattern = '(?ms)^<!-- GEURTS-GITIGNORE-BEGIN version="(?<Version>[0-9]+\.[0-9]+\.[0-9]+)" target="(?<Target>[^"]+)" sha256="(?<Hash>[0-9a-f]{64})" -->\r?\n```gitignore\r?\n(?<Payload>.*?)^```\r?\n<!-- GEURTS-GITIGNORE-END -->(?:\r?\n)?\z'
        $gitIgnoreMatches = @([regex]::Matches($gitIgnoreText, $gitIgnorePattern))
        if ($gitIgnoreMatches.Count -ne 1) {
            $gitIgnoreFailures.Add("marker or fence grammar is invalid") | Out-Null
        }
        else {
            $gitIgnoreMatch = $gitIgnoreMatches[0]
            $techniqueVersion = Get-DeclaredVersion -Path $gitIgnorePath
            if ($techniqueVersion -cne "1.0.1" -or $gitIgnoreMatch.Groups["Version"].Value -cne $techniqueVersion) { $gitIgnoreFailures.Add("template version is invalid") | Out-Null }
            if ($gitIgnoreMatch.Groups["Target"].Value -cne ".gitignore") { $gitIgnoreFailures.Add("target is not ordinal-exact .gitignore") | Out-Null }
            $payload = $gitIgnoreMatch.Groups["Payload"].Value
            if ($payload.Length -gt 0 -and $payload[0] -eq [char]0xFEFF) { $gitIgnoreFailures.Add("payload contains a byte-order mark") | Out-Null }
            $normalizedPayload = $payload -replace "`r`n", "`n" -replace "`r", "`n"
            if (-not $normalizedPayload.EndsWith("`n") -or $normalizedPayload.EndsWith("`n`n")) { $gitIgnoreFailures.Add("payload terminal newline is invalid") | Out-Null }
            if ([regex]::Matches($normalizedPayload, "`n").Count -ne 404) { $gitIgnoreFailures.Add("payload logical line count is not 404") | Out-Null }
            $expectedNormalizedHash = "4d9408d141d128225e02615c7e72031d53153f5dfcc9427305a6c651689008d4"
            if ($gitIgnoreMatch.Groups["Hash"].Value -cne $expectedNormalizedHash -or (Get-TextHash -Text $normalizedPayload) -cne $expectedNormalizedHash) { $gitIgnoreFailures.Add("normalized payload hash is invalid") | Out-Null }

            $sourceSha = [System.Security.Cryptography.SHA256]::Create()
            try { $approvedSourceHash = ([System.BitConverter]::ToString($sourceSha.ComputeHash($strictUtf8.GetBytes($normalizedPayload.Replace("`n", "`r`n"))))).Replace("-", "").ToLowerInvariant() }
            finally { $sourceSha.Dispose() }
            if ($approvedSourceHash -cne "1af49cb7916167b1dad80b762ba5e545fc727f609970a268069027f997658216") { $gitIgnoreFailures.Add("approved CRLF source hash is invalid") | Out-Null }
        }
    }

    $gfiTechniquePath = Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md"
    $gfiTechniqueText = if (Test-Path -LiteralPath $gfiTechniquePath -PathType Leaf) { [System.IO.File]::ReadAllText($gfiTechniquePath) } else { "" }
    $gitIgnoreOwnerRow = [regex]::Match($manifestText, '(?m)^\| Approved project-root `\.gitignore` payload \| `GeurtsTechniques/GeurtsGitIgnoreTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    if (-not $gitIgnoreOwnerRow.Success -or $gitIgnoreOwnerRow.Groups["When"].Value -notmatch '(?i)exact payload') { $gitIgnoreFailures.Add("manifest does not select the Git Ignore Technique as the exact-payload owner") | Out-Null }
    if ($gitIgnoreText -notmatch '(?i)fallbackPolicy:\s*none' -or $gitIgnoreText -notmatch '(?i)versioned compatibility content' -or $gitIgnoreText -notmatch '(?i)original imported rules, names and comments remain intact') { $gitIgnoreFailures.Add("technique does not preserve the imported compatibility asset and no-fallback boundary") | Out-Null }
    $gitIgnoreAuthorizationValid = $gitIgnoreText -match '(?i)explicit(?:ly)? (?:user[- ]?)?authori[sz]'
    $gitIgnoreMissingTargetValid = $gitIgnoreText -match '(?i)target is missing' -and $gitIgnoreText -match '(?i)(?:create|write)[^\r\n]{0,120}(?:only when|only if)[^\r\n]{0,120}(?:validates exactly|exact payload)'
    $gitIgnoreMatchingTargetValid = $gitIgnoreText -match '(?i)(?:identical|matches)[^\r\n]{0,100}(?:target|payload)' -and $gitIgnoreText -match '(?i)(?:report(?:ed)?[^\r\n]{0,80}(?:unchanged|match)|without rewriting|not rewrite)'
    $gitIgnoreDifferingTargetValid = $gitIgnoreText -match '(?i)(?:target|file)[^\r\n]{0,100}(?:differs|different)' -and $gitIgnoreText -match '(?i)preserve[^\r\n]{0,80}bytes[^\r\n]{0,80}timestamp' -and $gitIgnoreText -match '(?i)conflict'
    $gitIgnoreMutationBoundaryValid = $gitIgnoreText -match '(?i)never[^\r\n]{0,120}append' -and $gitIgnoreText -match '(?i)never[^\r\n]{0,160}merge' -and $gitIgnoreText -match '(?i)never[^\r\n]{0,160}replace' -and $gitIgnoreText -match '(?i)never[^\r\n]{0,160}reformat'
    $gitIgnoreIndexBoundaryValid = $gitIgnoreText -match '(?i)(?:no|never|must not)[^\r\n]{0,100}Git (?:index|tracking state)' -and $gitIgnoreText -match '(?i)never[^\r\n]{0,120}(?:stage|unstage|add|remove)'
    $gitIgnoreProvisioningValid = $gitIgnoreAuthorizationValid -and $gitIgnoreMissingTargetValid -and $gitIgnoreMatchingTargetValid -and $gitIgnoreDifferingTargetValid -and $gitIgnoreMutationBoundaryValid -and $gitIgnoreIndexBoundaryValid
    if (-not $gitIgnoreProvisioningValid) { $gitIgnoreFailures.Add("technique does not define the full authorized create-if-missing, exact-match, differing-target preservation, and Git-index boundary") | Out-Null }
    if ($gfiTechniqueText.Contains("GEURTS-GITIGNORE-BEGIN") -or $gfiTechniqueText -match '(?ms)```gitignore.*?```') { $gitIgnoreFailures.Add("Game Forge Intelligence technique duplicates the payload instead of deferring to its subject owner") | Out-Null }
    Add-Check "Custom .gitignore payload" ($gitIgnoreFailures.Count -eq 0) $(if ($gitIgnoreFailures.Count) { $gitIgnoreFailures -join "; " } else { "The v1.0.1 payload retains the original rules and appends FMOD recommendations; its subject owner alone defines explicit create-if-missing authorization, identical no-rewrite, differing-target conflict/preservation, no merge or replacement, and no Git-index mutation." })

    $attributesValid = $false
    try {
        $attributesPath = Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsGitAttributesTechnique.md'
        $attributesBytes = [System.IO.File]::ReadAllBytes($attributesPath)
        $attributesOffset = if ($attributesBytes.Length -ge 3 -and $attributesBytes[0] -eq 0xef -and $attributesBytes[1] -eq 0xbb -and $attributesBytes[2] -eq 0xbf) { 3 } else { 0 }
        $attributesUtf8 = New-Object System.Text.UTF8Encoding($false, $true)
        $attributesText = $attributesUtf8.GetString($attributesBytes, $attributesOffset, $attributesBytes.Length - $attributesOffset).Replace("`r`n", "`n").Replace("`r", "`n")
        $attributesMatch = [regex]::Match($attributesText, '(?ms)^<!-- GEURTS-GITATTRIBUTES-BEGIN version="1\.0\.1" target="\.gitattributes" sha256="(?<Hash>[0-9a-f]{64})" -->\n```gitattributes\n(?<Payload>.*?)^```\n<!-- GEURTS-GITATTRIBUTES-END -->\n?\z')
        $attributesPayload = $attributesMatch.Groups['Payload'].Value
        $attributesSha = [System.Security.Cryptography.SHA256]::Create()
        try { $attributesHash = ([System.BitConverter]::ToString($attributesSha.ComputeHash($attributesUtf8.GetBytes($attributesPayload)))).Replace('-', '').ToLowerInvariant() }
        finally { $attributesSha.Dispose() }
        $attributesValid = $attributesMatch.Success -and $attributesHash -ceq 'd051cf466ba5bffc055905a79ae76f93a60e27a3dbb8fcd16b968bb80c3e3d2d' -and
            $attributesMatch.Groups['Hash'].Value -ceq $attributesHash -and [regex]::Matches($attributesText, 'GEURTS-GITATTRIBUTES-BEGIN').Count -eq 1 -and
            [regex]::Matches($attributesText, 'GEURTS-GITATTRIBUTES-END').Count -eq 1 -and [regex]::Matches($attributesPayload, "`n").Count -eq 2 -and
            $attributesText -match '(?m)^\*\*Version:\*\* 1\.0\.1$' -and $manifestText.Contains('| `GeurtsTechniques/GeurtsGitAttributesTechnique.md` | 1.0.1 |') -and
            $manifestText.Contains('| FMOD project-root `.gitattributes` template and explicit installation | `GeurtsTechniques/GeurtsGitAttributesTechnique.md` |')
    }
    catch { $attributesValid = $false }
    Add-Check 'FMOD .gitattributes payload' $attributesValid 'The two-line UTF-8 payload, exact target/hash, 1.0.1 versions and manifest-selected owner agree.'

    $requiredPathFailures = New-Object System.Collections.Generic.List[string]
    $legacyGfiRedirectRelative = "GeurtsTechniques/GeurtsGameForgeIntelligenceIntegrationContract.md"
    foreach ($technique in @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques") -Filter "*.md" -File)) {
        $relative = "GeurtsTechniques/" + $technique.Name
        if ($relative -ceq $legacyGfiRedirectRelative) { continue }
        $text = [System.IO.File]::ReadAllText($technique.FullName)
        $expectedRequiredPath = "**Required package path:** " + [char]96 + $relative + [char]96
        if ($text -notmatch [regex]::Escape($expectedRequiredPath)) { $requiredPathFailures.Add($relative) | Out-Null }
    }
    Add-Check "Technique required-path metadata" ($requiredPathFailures.Count -eq 0) $(if ($requiredPathFailures.Count) { "Missing or incorrect required package path metadata: " + ($requiredPathFailures -join ", ") } else { "Every normative technique declares its required package path; the legacy redirect is checked separately." })

    $plainPathFailures = New-Object System.Collections.Generic.List[string]
    $packageMetadataPaths = @("AI_READ_FIRST.md", "GeurtsTechniqueManifest.md")
    $packageMetadataPaths += @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques") -Filter "*.md" -File | ForEach-Object { "GeurtsTechniques/" + $_.Name } | Where-Object { $_ -cne $legacyGfiRedirectRelative })
    $packageMetadataPaths += @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "Ideas") -Filter "*.md" -File | ForEach-Object { "Ideas/" + $_.Name })
    $packageMetadataPaths += @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "Migrations") -Filter "*.md" -File | ForEach-Object { "Migrations/" + $_.Name })
    foreach ($relative in $packageMetadataPaths) {
        $text = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative))
        $expected = "**Required package path:** " + [char]96 + $relative + [char]96
        if (-not $text.Contains($expected)) { $plainPathFailures.Add("$relative does not declare its required package path") | Out-Null }
    }
    foreach ($projectMetadata in @(
        @{ File = "Tools/AIAgentInstructionTemplates/GameDesign/README.md"; Required = "Docs/GameDesign/README.md" },
        @{ File = "Tools/AIAgentInstructionTemplates/GameDesign/GameDesignManifest.md"; Required = "Docs/GameDesign/GameDesignManifest.md" }
    )) {
        $text = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $projectMetadata.File))
        $expected = "**Required project path:** " + [char]96 + $projectMetadata.Required + [char]96
        if (-not $text.Contains($expected)) { $plainPathFailures.Add("$($projectMetadata.File) does not declare its required project path") | Out-Null }
    }
    foreach ($file in @(Get-ChildItem -LiteralPath $RepositoryRoot -Recurse -File | Where-Object { $_.FullName -notmatch '[\\/]\.git[\\/]' })) {
        $text = [System.IO.File]::ReadAllText($file.FullName)
        if ($text.Replace("canonicalPath", "").Replace("CanonicalPath", "") -match '(?i)\bcanonical(?: package| project)? path\b') {
            $plainPathFailures.Add("$($file.FullName.Substring($RepositoryRoot.Length).TrimStart([char]92, [char]47)) contains obsolete human-facing path terminology") | Out-Null
        }
    }
    $folderTechniqueTextForPathTerms = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureTechnique.md"))
    $readmeTextForPathTerms = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "README.md"))
    if ($folderTechniqueTextForPathTerms -notmatch '(?i)`canonicalPath`[^\r\n]{0,100}legacy serialized compatibility key' -or $readmeTextForPathTerms -notmatch '(?i)`canonicalPath`[^\r\n]{0,100}legacy serialized compatibility') {
        $plainPathFailures.Add("canonicalPath is not explicitly documented as a legacy serialized compatibility key") | Out-Null
    }
    Add-Check "Plain-language path terminology" ($plainPathFailures.Count -eq 0) $(if ($plainPathFailures.Count) { $plainPathFailures -join "; " } else { "Human-facing metadata uses required package/project paths; canonicalPath remains only as an explicitly documented legacy serialized compatibility key." })

    $legacyGfiRedirectPath = Join-Path $RepositoryRoot $legacyGfiRedirectRelative
    $legacyGfiRedirectText = if (Test-Path -LiteralPath $legacyGfiRedirectPath -PathType Leaf) { [System.IO.File]::ReadAllText($legacyGfiRedirectPath) } else { "" }
    $subjectSectionForRedirect = [regex]::Match($manifestText, '(?ms)^## 2\. Subject Ownership and Applicability\s*(?<Body>.*?)(?=^## 3\.)')
    $redirectRegistryRow = [regex]::Match($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsGameForgeIntelligenceIntegrationContract\.md` \| 2\.0\.0 \| (?<Role>[^|]+) \|\r?$')
    $redirectBody = [regex]::Replace($legacyGfiRedirectText, '\A<!-- GEURTS-AUDIENCE: (?:AI-READ|HUMAN-ONLY) -->\r?\n', '')
    $redirectValid = $redirectBody.StartsWith("# Moved: Geurts Game Forge Intelligence Integration Contract", [System.StringComparison]::Ordinal) -and $legacyGfiRedirectText.Contains("**Version:** 2.0.0") -and $legacyGfiRedirectText.Contains("**Status:** Non-normative compatibility redirect") -and $legacyGfiRedirectText.Contains('**Legacy compatibility redirect path:** `GeurtsTechniques/GeurtsGameForgeIntelligenceIntegrationContract.md`') -and $legacyGfiRedirectText.Contains("GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique.md") -and $legacyGfiRedirectText -match '(?i)former v1 stateful launch-check/download, transaction, rollback, recovery, drift-preservation, and reintegration lifecycle is obsolete' -and $legacyGfiRedirectText -match '(?i)notification-and-manual-update contract' -and $legacyGfiRedirectText -match '(?i)fail closed' -and -not $legacyGfiRedirectText.Contains("**Required package path:**") -and -not $legacyGfiRedirectText.Contains("| Subject |") -and $legacyGfiRedirectText.Length -lt 2000 -and $redirectRegistryRow.Success -and $redirectRegistryRow.Groups["Role"].Value -match '(?i)non-normative compatibility redirect' -and $redirectRegistryRow.Groups["Role"].Value -match '(?i)never selected' -and $subjectSectionForRedirect.Success -and $subjectSectionForRedirect.Groups["Body"].Value.IndexOf($legacyGfiRedirectRelative, [System.StringComparison]::Ordinal) -lt 0
    Add-Check "Frozen GFI v2 compatibility redirect" $redirectValid "The legacy path is a short v2 non-normative fail-closed pointer that marks the v1 automatic transaction/recovery lifecycle obsolete and cannot become a second owner."

    $gfiRegistryRow = [regex]::Match($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique\.md` \| 2\.0\.0 \| (?<Role>[^|]+) \|\r?$')
    $gfiLifecycleOwnerRow = [regex]::Match($manifestText, '(?m)^\| Frozen Game Forge Intelligence 2\.0 integration compatibility \| `GeurtsTechniques/GeurtsGameForgeIntelligenceTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    $activeGfiContractSurfaceText = @($gfiTechniqueText, $gfiMigrationText) -join [Environment]::NewLine
    $packageAvailabilityContradiction = $activeGfiContractSurfaceText -match '(?i)package[- ]version(?: ordering| equality| inequality)?\s+(?:alone\s+)?(?:determines|may determine|can determine)[^\r\n]{0,120}(?:availability|Update is available)'
    $sourceBoundaryValid = $gfiTechniqueText -match '(?im)^\*\*Version:\*\*\s*2\.0\.0\s*$' -and $gfiTechniqueText -match '(?im)^\*\*Compatibility schema:\*\*\s*2\.0\.0\s*$' -and $gfiRegistryRow.Success -and $gfiRegistryRow.Groups["Role"].Value -match '(?i)Historical frozen compatibility guide' -and $gfiRegistryRow.Groups["Role"].Value -match '(?i)no current updater authority' -and $gfiLifecycleOwnerRow.Success -and $gfiLifecycleOwnerRow.Groups["When"].Value -match '(?i)Only for a requested historical review or existing-installation migration' -and $gfiLifecycleOwnerRow.Groups["When"].Value -match '(?i)Not current package guidance' -and $manifestText -match '(?i)current setup, checking, and Update belong exclusively to the God-owned Commandments service' -and $gfiTechniqueText.Contains("https://github.com/Geurtsy/GeurtsGameForge_Documentation.git") -and $gfiTechniqueText -match '(?im)^Branch:\s*main\s*$' -and $gfiTechniqueText -match '(?i)sole primary source and authority for all Geurts Game Forge documentation' -and $gfiTechniqueText -match '(?i)documentation update[^\r\n]{0,120}must not require[^\r\n]{0,80}Unity-package release' -and $gfiTechniqueText -match '(?i)`<PluginPackageRoot>/Documentation~/`[^\r\n]{0,140}only plugin-specific' -and $gfiTechniqueText -match '(?i)must not embed, duplicate, redefine, or become authority' -and $gfiTechniqueText -match '(?i)must not ship a bundled or fallback copy of Geurts documentation' -and $activeGfiContractSurfaceText -notmatch '(?i)(?:may|must|shall)\s+(?:embed|bundle|duplicate)[^\r\n]{0,120}Geurts[^\r\n]{0,120}Documentation~'
    Add-Check "Frozen GFI v2 source and compatibility boundary" $sourceBoundaryValid "The internally validated schema-2.0.0 contract remains available only for released-consumer compatibility; package v0.61.1 assigns current setup, checking, and Update exclusively to the Commandments Companion."

    $manualTriggerValid = $gfiTechniqueText -match '(?i)There is one live project-local Geurts documentation copy' -and $gfiTechniqueText -match '(?i)On each normal Unity project launch or open[^\r\n]{0,180}exactly one lightweight remote metadata check' -and $gfiTechniqueText -match '(?i)obtains the authoritative current `main` head commit ID' -and $gfiTechniqueText -match '(?i)Update availability is determined only by commit identity' -and $gfiTechniqueText -match '(?is)exact destination directory exists.{0,300}remote `main` head commit ID differs.{0,120}Update is available' -and $gfiTechniqueText -match '(?i)commit IDs are identical, do not report an Update' -and $gfiTechniqueText -match '(?i)Package-version ordering or inequality is display-only and must not determine availability' -and $gfiTechniqueText -match '(?is)remote head commit ID is unavailable.{0,260}exact destination is absent.{0,260}no current receipt with a valid installed commit ID.{0,260}startup comparison result is unknown' -and $gfiTechniqueText -match '(?i)do not claim that an Update is available or that the installed copy is current by inspecting local files or comparing package versions' -and $gfiTechniqueText -match '(?i)notification check must not download documentation, install or synchronize files, inspect or hash the project-local copy, mutate any project path, recover content, or run reintegration' -and $gfiTechniqueText -match '(?i)failed or unavailable metadata request is non-blocking and leaves the local copy usable' -and $gfiTechniqueText -match '(?i)Ordinary AI/session initialization uses the existing local copy and performs no additional remote documentation check' -and $gfiTechniqueText -match '(?i)Local edits inside the detached writable copy do not affect update availability' -and $gfiTechniqueText -match '(?i)project-local copy is missing[^\r\n]{0,160}documentation as unavailable' -and $gfiTechniqueText -match '(?i)must not install, reconstruct, recover, or fetch it automatically' -and $gfiTechniqueText -match '(?i)only by explicitly invoking the Update action' -and $gfiTechniqueText -match '(?i)exposes exactly one documentation lifecycle action labelled' -and $gfiTechniqueText.Contains("Update Geurts Game Forge Documentation") -and $gfiMigrationText -match '(?i)remote head commit ID differs[^\r\n]{0,180}current installed receipt' -and $gfiMigrationText -match '(?i)Package version is display-only and never determines availability' -and $gfiMigrationText -match '(?i)no valid installed commit ID, availability is unknown' -and -not $packageAvailabilityContradiction
    Add-Check "Frozen GFI v2 startup and manual trigger" $manualTriggerValid "The frozen released-consumer contract retains its internally coherent metadata-only launch check and explicit manual Update semantics without authorizing package-v0.61.1 behavior."

    $versionDisplayValid = $gfiTechniqueText.Contains("Installed Geurts Documentation: <version | Not installed | Unknown>") -and $gfiTechniqueText.Contains("GameForgeIntelligence Plugin: <version | Unknown>") -and $gfiTechniqueText -match '(?i)`Installed Geurts Documentation` comes only from the valid package-version field in the current installed receipt' -and $gfiTechniqueText -match '(?i)Never derive, refresh, or override that displayed version by reading, parsing, or hashing mutable project-local documentation files' -and $gfiTechniqueText -match '(?i)`Not installed` whenever the exact project-local destination is known to be missing, regardless of any receipt or retained history' -and $gfiTechniqueText -match '(?i)check only whether that exact directory exists[^\r\n]{0,160}must not inspect its contents' -and $gfiTechniqueText -match '(?i)`Unknown` when the directory exists but there is no current installed receipt[^\r\n]{0,220}new copy was not completed successfully' -and $gfiTechniqueText -match '(?i)recorded package version when the directory exists and the current installed receipt contains both a valid authoritative selected commit ID and a valid authoritative package version' -and $gfiTechniqueText -match '(?i)`GameForgeIntelligence Plugin` comes only from the canonical installed Unity package metadata for `com\.gameforge\.intelligence`' -and $gfiTechniqueText -match '(?i)Show `Unknown` if that canonical plugin version is unavailable or invalid' -and $gfiTechniqueText.Contains("Available Geurts Documentation: <version>") -and $gfiTechniqueText.Contains("Available Geurts Documentation: Update available (version unknown)") -and $gfiTechniqueText -match '(?i)available package version is display-only and never changes the commit-identity result' -and $gfiTechniqueText -match '(?i)package version, Game Forge Intelligence Technique version, compatibility schema version, and GameForgeIntelligence plugin version are distinct values' -and $gfiTechniqueText -match '(?i)label them separately as `Integration Technique` and `Compatibility Schema`' -and $activeGfiContractSurfaceText -notmatch '(?i)(?:may|must|shall)\s+(?:display|use)[^\r\n]{0,120}(?:compatibility schema|integration technique)[^\r\n]{0,120}(?:as|for)\s+(?:the\s+)?(?:installed Geurts Documentation|GameForgeIntelligence Plugin)' -and $gfiMigrationText -match '(?i)known missing destination shows `Not installed`' -and $gfiMigrationText -match '(?i)existing copy without a trustworthy current receipt and valid package version shows `Unknown`'
    Add-Check "Frozen GFI v2 separated versions" $versionDisplayValid "The frozen released-consumer contract keeps its documentation, plugin, technique, and schema values internally distinct."

    $companionTechniqueRelative = "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"
    $companionContractRelative = "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json"
    $companionTechniquePath = Join-Path $RepositoryRoot $companionTechniqueRelative
    $companionContractPath = Join-Path $RepositoryRoot $companionContractRelative
    $companionTechniqueText = if (Test-Path -LiteralPath $companionTechniquePath -PathType Leaf) { [System.IO.File]::ReadAllText($companionTechniquePath) } else { "" }
    $companionContractText = if (Test-Path -LiteralPath $companionContractPath -PathType Leaf) { [System.IO.File]::ReadAllText($companionContractPath) } else { "" }
    $companionContractFailures = New-Object System.Collections.Generic.List[string]
    $companionContract = $null
    if ([string]::IsNullOrWhiteSpace($companionContractText)) {
        $companionContractFailures.Add("contract file is missing or empty") | Out-Null
    }
    else {
        try { $companionContract = $companionContractText | ConvertFrom-Json }
        catch { $companionContractFailures.Add("contract JSON is invalid") | Out-Null }
    }

    $expectedValidationEntries = @(
        "AI_READ_FIRST.md",
        "GeurtsTechniqueManifest.md",
        "GeurtsTechniques/GeurtsStandardsOnlyTechnique.md",
        "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md",
        "GeurtsTechniques/GeurtsCommandmentsCompanionContract.json",
        "Tools/AIAgentInstructionTemplates/copilot-instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md",
        "GeurtsTechniques/GeurtsAgentTechnique.md",
        "GeurtsTechniques/GeurtsEditorUIThemeTechnique.md",
        "GeurtsTechniques/GeurtsNamingTechnique.md",
        "GeurtsTechniques/GeurtsEditorAppearanceTechnique.md",
        "GeurtsTechniques/GeurtsForgeSetupTechnique.md",
        "GeurtsTechniques/GeurtsForgeSetupContract.json",
        "GeurtsTechniques/GeurtsSteamIntegrationTechnique.md"
    )
    $expectedRouteMappings = @(
        [pscustomobject]@{ Template = "Tools/AIAgentInstructionTemplates/copilot-instructions.md"; Target = ".github/copilot-instructions.md" },
        [pscustomobject]@{ Template = "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md"; Target = ".github/instructions/geurts-unity.instructions.md" },
        [pscustomobject]@{ Template = "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"; Target = ".github/instructions/geurts-game-design.instructions.md" }
    )

    if ($companionContract) {
        if (-not (Test-ExactPropertySet -Object $companionContract -Expected @("schemaVersion", "packageVersion", "source", "destination", "validationEntries", "updateUi", "routeMappings"))) { $companionContractFailures.Add("top-level property set is not closed") | Out-Null }
        if ([string]$companionContract.schemaVersion -cne "3.0.0" -or [string]$companionContract.packageVersion -cne "0.61.1" -or [string]$companionContract.packageVersion -cne [string]$packageVersion) { $companionContractFailures.Add("schemaVersion, current packageVersion, or manifest parity is invalid") | Out-Null }

        if (-not (Test-ExactPropertySet -Object $companionContract.source -Expected @("repository", "branch", "selection"))) { $companionContractFailures.Add("source property set is not closed") | Out-Null }
        elseif ([string]$companionContract.source.repository -cne "https://github.com/Geurtsy/GeurtsGameForge_Commandments.git" -or [string]$companionContract.source.branch -cne "main" -or [string]$companionContract.source.selection -cne "exact-resolved-head-commit-archive") { $companionContractFailures.Add("official repository/main exact-commit archive source differs") | Out-Null }

        if (-not (Test-ExactPropertySet -Object $companionContract.destination -Expected @("projectRelativePath", "replacement", "access"))) { $companionContractFailures.Add("destination property set is not closed") | Out-Null }
        elseif ([string]$companionContract.destination.projectRelativePath -cne "GeurtsGameForgeCommandments" -or [string]$companionContract.destination.replacement -cne "complete-directory" -or [string]$companionContract.destination.access -cne "logically-read-only") { $companionContractFailures.Add("managed documentation destination differs") | Out-Null }

        if (-not (Test-ExactStringSequence -Actual @($companionContract.validationEntries) -Expected $expectedValidationEntries)) { $companionContractFailures.Add("current validationEntries is not the exact fourteen-entry package-v0.61.1 list") | Out-Null }
        $validationEntrySet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        foreach ($validationEntry in @($companionContract.validationEntries)) {
            $validationRelative = [string]$validationEntry
            if (-not $validationEntrySet.Add($validationRelative) -or -not (Test-SafeDefinitionPath -Path $validationRelative) -or -not (Test-Path -LiteralPath (Join-Path $RepositoryRoot $validationRelative) -PathType Leaf)) { $companionContractFailures.Add("validation entry is duplicate, unsafe, or absent: $validationRelative") | Out-Null }
        }

        if (-not (Test-ExactPropertySet -Object $companionContract.updateUi -Expected @("actionLabel", "confirmationDefault", "cancelResult", "confirmationTargets"))) { $companionContractFailures.Add("updateUi property set is not closed") | Out-Null }
        elseif ([string]$companionContract.updateUi.actionLabel -cne "Update Geurts Game Forge Commandments" -or [string]$companionContract.updateUi.confirmationDefault -cne "cancel" -or [string]$companionContract.updateUi.cancelResult -cne "no-network-or-filesystem-change") { $companionContractFailures.Add("Update action or cancel behavior differs") | Out-Null }

        $confirmationTargets = @($companionContract.updateUi.confirmationTargets)
        if ($confirmationTargets.Count -ne 4) { $companionContractFailures.Add("confirmation target count is not exactly three") | Out-Null }
        else {
            $expectedConfirmationPaths = @("GeurtsGameForgeCommandments") + @($expectedRouteMappings | ForEach-Object { $_.Target })
            for ($confirmationIndex = 0; $confirmationIndex -lt $confirmationTargets.Count; $confirmationIndex++) {
                $confirmationTarget = $confirmationTargets[$confirmationIndex]
                $expectedEffect = if ($confirmationIndex -eq 0) { "replace-complete-directory" } else { "replace-complete-file" }
                if (-not (Test-ExactPropertySet -Object $confirmationTarget -Expected @("path", "effect")) -or [string]$confirmationTarget.path -cne $expectedConfirmationPaths[$confirmationIndex] -or [string]$confirmationTarget.effect -cne $expectedEffect) { $companionContractFailures.Add("confirmation target $confirmationIndex differs from the exact path/effect list") | Out-Null }
            }
        }

        $routeMappings = @($companionContract.routeMappings)
        $routeTargets = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        $routeTemplates = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        if ($routeMappings.Count -ne 3) { $companionContractFailures.Add("route mapping count is not exactly three") | Out-Null }
        else {
            for ($routeIndex = 0; $routeIndex -lt $routeMappings.Count; $routeIndex++) {
                $routeMapping = $routeMappings[$routeIndex]
                $template = [string]$routeMapping.template
                $target = [string]$routeMapping.target
                if (-not (Test-ExactPropertySet -Object $routeMapping -Expected @("template", "target")) -or $template -cne $expectedRouteMappings[$routeIndex].Template -or $target -cne $expectedRouteMappings[$routeIndex].Target) { $companionContractFailures.Add("route mapping $routeIndex differs from the exact template-to-target list") | Out-Null }
                if (-not $routeTemplates.Add($template) -or -not $routeTargets.Add($target)) { $companionContractFailures.Add("duplicate route template or target") | Out-Null }
                if (-not (Test-SafeDefinitionPath -Path $template) -or -not (Test-SafeDefinitionPath -Path $target) -or -not (Test-Path -LiteralPath (Join-Path $RepositoryRoot $template) -PathType Leaf)) { $companionContractFailures.Add("route mapping is unsafe or its template is absent: $template -> $target") | Out-Null }
            }
        }
    }
    Add-Check "Documentation companion closed contract" ($companionContractFailures.Count -eq 0) $(if ($companionContractFailures.Count) { $companionContractFailures -join "; " } else { "The current schema-3.0.0/package-v0.61.1 source contract fixes the official exact-commit archive, one managed directory, fourteen validation entries, one four-target confirmation, and three exact full-file route mappings." })

    $gitOnlyFailures = New-Object System.Collections.Generic.List[string]
    $gitBrickCatalogue = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsBrickCatalogue.json")) | ConvertFrom-Json
    $gitBrickContractText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsBrickContract.md"))
    foreach ($brick in $gitBrickCatalogue.bricks) {
        if ($brick.released -and ($brick.sourceKind -cne 'git' -or $brick.developmentOnly -or $brick.source -notmatch '^https://github\.com/[^/]+/[^/]+\.git(?:\?path=/[^#]+)?#[0-9a-f]{40}$')) {
            $gitOnlyFailures.Add("Released brick must have an immutable Git source: $($brick.id)") | Out-Null
        }
    }
    foreach ($requiredPolicy in @('A local-only commit', 'Never overwrite a brick source folder or offer a downgrade', 'before dispatch', 'previous published Git version', 'strictly newer Git release')) {
        if (-not $gitBrickContractText.Contains($requiredPolicy)) { $gitOnlyFailures.Add("Missing Git delivery rule: $requiredPolicy") | Out-Null }
    }
    Add-Check "Git-only brick delivery and downgrade boundary" ($gitOnlyFailures.Count -eq 0) $(if ($gitOnlyFailures.Count) { $gitOnlyFailures -join '; ' } else { 'Released bricks use immutable Git sources; remote-first delivery and downgrade/source preservation rules are present.' })

    $companionForwardCompatibilityValid = $companionTechniqueText -match '(?i)`packageVersion` is source-release metadata, not a companion compatibility gate' -and $companionTechniqueText -match '(?i)valid version and exactly match the package manifest in the same archive' -and $companionTechniqueText -match '(?i)later package version alone must not require a companion release while schema 3\.0\.0 remains supported' -and $companionTechniqueText -match '(?i)`validationEntries` is the archive.?s closed current completeness list' -and $companionTechniqueText -match '(?i)schema-3\.0\.0 consumer may read a later list rather than pinning v0\.11\.0' -and $companionTechniqueText -match '(?i)every entry must be unique, safe, readable, and archive-root-relative before mutation' -and $companionTechniqueText -match '(?i)Validation entries grant no project-read or project-write authority'
    Add-Check "Companion schema forward compatibility" $companionForwardCompatibilityValid "Schema 3.0.0 pins mutation paths, not documentation releases: packageVersion must match the same archive manifest, and later safe validation-entry lists remain consumable without a companion release."

    $companionTechniqueRegistryRow = [regex]::Match($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsCommandmentsCompanionTechnique\.md` \| 3\.2\.5 \| (?<Role>[^|]+) \|\r?$')
    $companionContractRegistryRow = [regex]::Match($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsCommandmentsCompanionContract\.json` \| 0\.61\.1 \| (?<Role>[^|]+) \|\r?$')
    $companionOwnerRow = [regex]::Match($manifestText, '(?m)^\| God-owned Windows Unity Editor Commandments source, metadata check, confirmed replacement, project-boundary, and AI-routing lifecycle \| `GeurtsTechniques/GeurtsCommandmentsCompanionTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    $companionContractOwnerRow = [regex]::Match($manifestText, '(?m)^\| Exact companion source, documentation destination, validation entries, confirmation targets, and template-to-route mappings \| `GeurtsTechniques/GeurtsCommandmentsCompanionContract\.json` \| (?<When>[^|]+) \|\r?$')
    $companionArchitectureValid = $companionTechniqueRegistryRow.Success -and $companionContractRegistryRow.Success -and
        $companionOwnerRow.Success -and $companionContractOwnerRow.Success -and
        $companionTechniqueText.Contains('God **0.29.0 or newer** owns Commandments viewing') -and
        $companionTechniqueText.Contains('sole source and authority for generic Geurts Game Forge documentation') -and
        $companionTechniqueText.Contains('contains no Commandments Companion plugin code or God implementation') -and
        $companionTechniqueText.Contains('no lifecycle callbacks, no network transport and no menu or console-command registrations') -and
        $companionTechniqueText.Contains('no runtime assembly may reference them') -and
        $companionTechniqueText.Contains('Either order is supported') -and
        $companionTechniqueText.Contains('migrate those references to God') -and
        $companionTechniqueText.Contains('one content controller and no duplicate menu/command registrations') -and
        $companionTechniqueText.Contains('read local Commandments without any Unity package')
    Add-Check "Documentation companion architecture boundary" $companionArchitectureValid "The manifest selects the God-owned Editor service and passive compatibility adapter while authoritative readable content stays independent."

    $brickContractText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsBrickContract.md"))
    $brickCatalogue = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsBrickCatalogue.json")) | ConvertFrom-Json
    $godEntries = @($brickCatalogue.bricks | Where-Object { $_.id -ceq "com.geurts.gameforge.god" })
    $godFirstValid = $godEntries.Count -eq 1 -and
        @($godEntries[0].dependencies | Where-Object { $_.id -ceq "com.geurts.gameforge.documentation" }).Count -eq 0 -and
        $brickContractText.Contains('Commandments Companion is optional, not a required package or assembly dependency') -and
        $brickContractText.Contains('Install God first from its real Git source') -and
        $brickContractText.Contains('The user-facing package-management window and menu are named **Game Forge God**')
    Add-Check "God-first optional Commandments Companion boundary" $godFirstValid "God installs independently, exposes the optional Commandments Companion package through Game Forge God, and does not declare a reverse dependency in the catalogue."

    $installedMenusValid = $brickContractText.Contains('**Installed Brick Menus**') -and
        $brickContractText.Contains('Include installed disabled bricks and installed packages absent from the catalogue') -and
        $brickContractText.Contains('Recheck actual package installation before opening a panel') -and
        $brickContractText.Contains('missing, invalid, duplicated, unavailable or throws') -and
        $brickContractText.Contains('BrickEditorMenuAttribute') -and
        $brickContractText.Contains('minimum God dependency of **0.12.0**') -and
        $brickContractText.Contains('Never resolve executable types, methods or menu paths from remote catalogue fields')
    Add-Check "Installed brick menu contract" $installedMenusValid "Installed packages retain a local Editor opener or useful information, independent of catalogue/lifecycle state, with installation rechecks and no executable catalogue metadata."

    $godContentIntegrationValid = $brickContractText.Contains('Manual Update All cannot replace content') -and
        $companionTechniqueText.Contains('Package updates alone never replace Commandments, AI routes, saved consent or preferences') -and
        $companionTechniqueText.Contains('one cancel-default confirmation before archive acquisition, including on the first manual content installation') -and
        $companionTechniqueText.Contains('Missing/incompatible APIs report an actionable update explanation and never create a second implementation')
    $godAutomaticConsentValid = $brickContractText.Contains('off by default') -and
        $brickContractText.Contains('Package cancellation/failure stops the opening sequence') -and
        $companionTechniqueText.Contains('commandments_schema_3') -and
        $companionTechniqueText.Contains('Recheck live consent') -and
        $companionTechniqueText.Contains('no backup or rollback') -and
        $companionTechniqueText.Contains('never startup, a restored window or merely enabling an option/module')
    Add-Check "God automatic update consent" $godAutomaticConsentValid "Default-off saved consent bounds God-opening updates; manual confirmation, standalone offline startup and exact target ownership remain intact."
    $openingOptionsValid = $brickContractText.Contains('**Automatically update packages and documentation** and **Automatically refresh the catalogue** as independent checkboxes, both off by default') -and
        $brickContractText.Contains('using cached catalogue data') -and
        $brickContractText.Contains('Neither checkbox starts work when toggled') -and
        $brickContractText.Contains('without checking package sources or installing packages') -and
        $companionTechniqueText.Contains('separate default-off options')
    Add-Check "Independent God opening options" $openingOptionsValid "Catalogue refresh and installed-package/documentation updates have separate default-off consent; toggling and Unity startup do not start work."
    Add-Check "God documentation content integration" $godContentIntegrationValid "Package management stays separate from companion-owned content replacement, including first installation, with the same confirmation and graceful missing-companion behavior."

    $forbiddenPluginPaths = @($trackedPaths | Where-Object { [System.IO.Path]::GetFileName($_) -ceq "package.json" -or [System.IO.Path]::GetExtension($_) -in @(".cs", ".asmdef", ".asmref") })
    Add-Check "No Unity companion implementation in documentation source" ($forbiddenPluginPaths.Count -eq 0) $(if ($forbiddenPluginPaths.Count) { "Unity package implementation files are tracked here: " + ($forbiddenPluginPaths -join ", ") } else { "No package.json, C#, asmdef, or asmref implementation file is tracked in this documentation repository." })

    $companionActiveSurfaceText = @($companionTechniqueText, $manifestText, $aiReadFirstText, $readmeTextForPathTerms, $targetMigrationText) -join [Environment]::NewLine
    $startupMutationContradiction = $companionActiveSurfaceText -match '(?i)the companion automatically (?:checks?|refreshes?|downloads?|installs?|replaces?|repairs?|synchroni[sz]es?|mutates?)[^\r\n]{0,120}(?:at|during|on) Unity (?:project )?(?:launch|open|startup)' -or $companionActiveSurfaceText -match '(?i)(?:at|during|on) Unity (?:project )?(?:launch|open|startup),? the companion automatically (?:checks?|refreshes?|downloads?|installs?|replaces?|repairs?|synchroni[sz]es?|mutates?)'
    $companionStartupValid = $companionTechniqueText -match '(?i)On each normal Unity project launch or open[^\r\n]{0,180}must not check remote metadata' -and $companionTechniqueText -match '(?i)official repository.?s current `main` head commit' -and $companionTechniqueText -match '(?i)compares that remote commit ID with one (?:persistent )?companion-owned last-successful-installed commit value for this Unity project' -and $companionTechniqueText -match '(?i)held outside the Unity project filesystem and outside the installed UPM package' -and $companionTechniqueText -match '(?i)keyed by a Unity-provided project identity or normalized project-root path derived without reading project content' -and $companionTechniqueText -match '(?i)value for one project must never suppress availability in another' -and $companionTechniqueText -match '(?i)must not create a project file or project path for this value' -and $companionTechniqueText -match '(?i)Update is available when the last-successful-installed commit value is missing or differs' -and $companionTechniqueText -match '(?i)Matching values mean only that the authoritative source has not advanced' -and $companionTechniqueText -match '(?i)When the remote commit is unavailable, availability is unknown' -and $companionTechniqueText -match '(?i)must not download an archive, inspect the managed documentation copy, inspect any AI target, mutate a managed project target, execute setup work, or synchronize content' -and $companionTechniqueText -match '(?i)skipped, failed, or unavailable request is non-blocking' -and $companionTechniqueText -match '(?i)explicit Update action remains available in every state' -and $companionTechniqueText -match '(?i)Ordinary AI-session initialization performs no additional remote check' -and $companionTechniqueText -match '(?i)comparison-only, non-authoritative, and non-blocking' -and $companionTechniqueText -match '(?i)not a receipt, package-version record, compatibility state' -and $companionTechniqueText -match '(?i)write is attempted only after full managed-target success' -and -not $startupMutationContradiction
    Add-Check "Companion offline startup" $companionStartupValid "Unity startup and restored windows stay offline; explicit remote-head metadata comparison is non-blocking, keyed outside the project/package per Unity project; it never downloads, inspects, executes setup, or mutates."

    $companionUpdateSection = [regex]::Match($companionTechniqueText, '(?ms)^## 6\. Confirmed Update Sequence\s*(?<Body>.*?)(?=^## 7\.)')
    $companionUpdateBody = if ($companionUpdateSection.Success) { $companionUpdateSection.Groups["Body"].Value } else { "" }
    $companionUpdatePositions = @(
        $companionUpdateBody.IndexOf('Resolve the official repository''s current `main` head commit', [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf("Download an archive pinned to that exact commit", [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf("Perform basic pre-mutation validation", [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf('Delete any existing `<ProjectRoot>/GeurtsGameForgeCommandments/`', [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf("Directly replace each of the three AI target files", [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf("Verify that the complete documentation destination and all three mapped target files were written successfully", [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf("After every managed-target verification passes", [System.StringComparison]::Ordinal),
        $companionUpdateBody.IndexOf("Remove temporary acquisition content on a best-effort basis", [System.StringComparison]::Ordinal)
    )
    $companionUpdateOrderValid = $companionUpdateSection.Success -and $companionUpdatePositions[0] -ge 0
    for ($positionIndex = 1; $positionIndex -lt $companionUpdatePositions.Count; $positionIndex++) { if ($companionUpdatePositions[$positionIndex] -le $companionUpdatePositions[$positionIndex - 1]) { $companionUpdateOrderValid = $false } }
    $downloadedContractExpansionContradiction = $companionActiveSurfaceText -match '(?i)downloaded contract may (?:change|expand|add)[^\r\n]{0,100}(?:mutation|destination|effect|mapping|target)'
    $companionConfirmationValid = $companionTechniqueText -match '(?i)exposes exactly one lifecycle action' -and $companionTechniqueText.Contains("Update Geurts Game Forge Commandments") -and $companionTechniqueText -match '(?i)Selecting it immediately shows one confirmation dialog' -and $companionTechniqueText -match '(?i)There is no earlier preview, dry run, check phase, setup screen, or second confirmation' -and $companionTechniqueText -match '(?i)Cancel is the initially focused and default response' -and $companionTechniqueText -match '(?i)declining must cause no network or filesystem change' -and $companionTechniqueText -match '(?i)confirmation must identify all four destructive targets and no implied broader scope' -and $companionTechniqueText -match '(?i)every local change in those targets will be overwritten and lost' -and $companionTechniqueText -match '(?i)`Docs/GameDesign/` and every unlisted project path will not be accessed or changed' -and $companionTechniqueText -match '(?i)No archive acquisition or project mutation may begin before affirmative confirmation' -and $companionTechniqueText -match '(?i)confirmation occurs before archive acquisition[^\r\n]{0,220}must carry this exact supported destination, four-target list, and three template-to-target mappings' -and $companionTechniqueText -match '(?i)After confirmation and download[^\r\n]{0,120}parse the archive.?s contract' -and $companionTechniqueText -match '(?i)pre-approved source selection, destination, action, confirmation behavior[^\r\n]{0,180}mapping order before the first project mutation' -and $companionTechniqueText -match '(?i)earlier approval does not authorize a changed or expanded managed target set' -and -not $downloadedContractExpansionContradiction
    $comparisonStateFailureContradiction = $companionActiveSurfaceText -match '(?i)comparison-state (?:write|persistence) failure[^\r\n]{0,120}(?:reclassifies|invalidates|undoes|rolls back)[^\r\n]{0,80}(?:content|managed-target|replacement|Update)'
    $companionCompletionValid = $companionUpdateOrderValid -and $companionTechniqueText -match '(?i)exact resolved main-head commit' -and $companionTechniqueText -match '(?i)archive pinned to that exact commit' -and $companionTechniqueText -match '(?i)readability of every contract-listed validation entry' -and $companionTechniqueText -match '(?i)support for contract schema 3\.0\.0' -and $companionTechniqueText -match '(?i)equality between the contract and manifest package versions' -and $companionTechniqueText -match '(?i)directly materialize the complete validated archive tree' -and $companionTechniqueText -match '(?i)result contains no `\.git` metadata or continuing repository, worktree, branch, remote, or synchronization connection' -and $companionTechniqueText -match '(?i)After every managed-target verification passes, report the content Update as successful and attempt to write' -and $companionTechniqueText -match '(?i)comparison-state write fails, report a warning[^\r\n]{0,160}do not reclassify, undo, or repair the successful four-target replacement' -and $companionTechniqueText -match '(?i)reports failure plainly and never reports partial completion as success' -and $companionTechniqueText -match '(?i)no automatic repair or recovery flow' -and -not $comparisonStateFailureContradiction
    Add-Check "Companion confirmation and complete update" ($companionConfirmationValid -and $companionCompletionValid) "One cancel-default confirmation authorizes only the four listed replacements; content success requires all four targets, while later comparison-state persistence failure warns without undoing that success."

    $companionBoundaryValid = $companionTechniqueText -match '(?i)complete replacement of those three files from the exact template mappings' -and $companionTechniqueText -match '(?i)may create only the missing parent directories required to materialize the listed targets' -and $companionTechniqueText -match '(?i)preserve every unlisted file and directory within those parents' -and $companionTechniqueText -match '(?i)Every other project path is outside the lifecycle' -and $companionTechniqueText -match '(?i)must not enumerate, inspect, create, validate, hash, modify, or delete anything under' -and $companionTechniqueText.Contains("<ProjectRoot>/Docs/GameDesign/") -and $companionTechniqueText -match '(?i)must not discover additional work from repository contents' -and $companionTechniqueText -match '(?i)scan for or execute `\.bat`, `\.cmd`, `\.ps1`, or any other script from either the documentation package or the Unity project' -and $companionTechniqueText -match '(?i)complete documentation tree is copied as inert content' -and $companionTechniqueText -match '(?i)presence of tools within that tree does not authorize their execution'
    Add-Check "Companion bounded project and script boundary" $companionBoundaryValid "Only the managed documentation directory, three mapped files, and their missing parents are in scope; Docs/GameDesign and unlisted paths are uninspected, and package/project scripts remain inert."

    $requiredCompanionExclusions = @("preview", "dry run", "backup", "snapshot", "rollback", "quarantine", "journal", "recovery gate", "last-valid copy", "merge", "opt-out", "migration path")
    $companionForbiddenSection = [regex]::Match($companionTechniqueText, '(?ms)^## 7\. Forbidden Behavior\s*(?<Body>.*?)(?=^## 8\.)')
    $missingCompanionExclusions = if ($companionForbiddenSection.Success) { @($requiredCompanionExclusions | Where-Object { $companionForbiddenSection.Groups["Body"].Value.IndexOf($_, [System.StringComparison]::OrdinalIgnoreCase) -lt 0 }) } else { @("forbidden behavior section") }
    $affirmativeLifecycleContradiction = $companionActiveSurfaceText -match '(?i)\b(?:companion|Update) (?:provides|creates|uses|maintains|requires|offers) (?:an? )?(?:preview|dry run|backup|snapshot|rollback|quarantine|journal|recovery|migration)' -or $companionActiveSurfaceText -match '(?i)\b(?:companion|Update) (?:shows|requires|uses|offers) (?:an? )?second confirmation' -or $companionActiveSurfaceText -match '(?i)\b(?:companion|Update) (?:preserves|reconciles|merges) (?:local )?drift' -or $companionActiveSurfaceText -match '(?i)\b(?:companion|UPM package) (?:runs|executes|launches|requires|uses) (?:an? )?(?:external )?(?:\.bat|batch|bootstrap)' -or $companionActiveSurfaceText -match '(?i)\bcompanion scans (?:the )?(?:repository|project|documentation).*?(?:scripts?|\.bat)'
    $minimalLifecycleValid = $missingCompanionExclusions.Count -eq 0 -and -not $affirmativeLifecycleContradiction -and $companionTechniqueText -match '(?i)not a general setup-plan format, script manifest, extensible task engine, or permission catalogue' -and $companionTechniqueText -match '(?i)does not merge managed regions, preserve content in those files, honor a native-entry opt-out, migrate legacy content' -and $companionForbiddenSection.Groups["Body"].Value -match '(?i)inspect or preserve local drift' -and $companionTechniqueText -match '(?i)no external installer, Windows bootstrap, batch-driven setup' -and $companionTechniqueText -match '(?i)no automatic repair or recovery flow'
    Add-Check "Companion minimal lifecycle exclusions" $minimalLifecycleValid "The companion contract has no preview/dry-run, second confirmation, setup engine, external bootstrap, script execution, drift handling, backup, rollback, journal, quarantine, migration, or recovery machinery."

    $aiRoutingLimitationValid = $companionTechniqueText -match '(?i)do not make every AI product obey the documentation automatically' -and $companionTechniqueText -match '(?i)AI tool must support the applicable native instruction file or be explicitly instructed to read and follow `AI_READ_FIRST\.md`' -and $companionTechniqueText -match '(?i)Tools that ignore those instruction surfaces may not discover or follow the Geurts documentation' -and $companionTechniqueText -match '(?i)must not claim universal AI control or compliance'
    Add-Check "Companion AI-routing limitation" $aiRoutingLimitationValid "The contract accurately limits routing to tools that support the declared native files or are explicitly instructed to follow AI_READ_FIRST.md."

    $codexTechniquePath = Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsAgentTechnique.md"
    $codexTechnique = [System.IO.File]::ReadAllText($codexTechniquePath)
    $codexTemplate = [regex]::Matches($codexTechnique, '(?ms)^<!-- GEURTS-CODEX-GUIDE-BEGIN version="1\.1\.0" -->\r?\n```markdown\r?\n(?<Body>.*?)^```\r?\n<!-- GEURTS-CODEX-GUIDE-END -->')
    $codexValid = $codexTemplate.Count -eq 1 -and [regex]::Matches($codexTechnique, 'GEURTS-CODEX-GUIDE-BEGIN').Count -eq 1 -and [regex]::Matches($codexTechnique, 'GEURTS-CODEX-GUIDE-END').Count -eq 1 -and -not (Test-Path -LiteralPath (Join-Path $RepositoryRoot "AGENTS.md")) -and -not (Test-Path -LiteralPath (Join-Path $RepositoryRoot "AGENT.md")) -and -not (Test-Path -LiteralPath (Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/AGENTS.md"))
    if ($codexTemplate.Count -eq 1) {
        $codexBody = $codexTemplate[0].Groups["Body"].Value
        $codexValid = $codexValid -and [regex]::Matches($codexBody, [regex]::Escape('{{GEURTS_DOCUMENTATION_ENTRY_POINT}}')).Count -eq 1 -and $codexBody.Contains('GeurtsTechniqueManifest.md') -and $codexBody.Contains('Every update, however small') -and -not $codexBody.Contains('Documentation/AGENTS.md')
    }
    Add-Check "Codex guide template and retired routes" $codexValid "The sole technique template has one exact-entry placeholder and mandatory manifest/version guidance; deprecated standalone guides are absent."

    $portableTemplate = [regex]::Matches($codexTechnique, '(?ms)^<!-- GEURTS-CODEX-ROOT-TEMPLATE:BEGIN version="1\.0\.0" -->\r?\n```markdown\r?\n(?<Body>.*?)^```\r?\n<!-- GEURTS-CODEX-ROOT-TEMPLATE:END -->')
    $portableValid = $portableTemplate.Count -eq 1 -and $manifestText.Contains('| `GeurtsTechniques/GeurtsAgentTechnique.md` | 1.3.0 |') -and $codexTechnique.Contains('byte-for-byte') -and $codexTechnique.Contains('Reinstallation is idempotent') -and $codexTechnique.Contains('Never install on startup or as part of Commandments Update') -and $codexTechnique.Contains('Unsupported or duplicate markers') -and $codexTechnique.Contains('Recheck source/target bytes after review')
    if ($portableTemplate.Count -eq 1) {
        $body = $portableTemplate[0].Groups['Body'].Value
        $portableValid = $portableValid -and [regex]::Matches($body, [regex]::Escape('./GeurtsGameForgeCommandments/AI_READ_FIRST.md')).Count -eq 1 -and $body -notmatch '[A-Za-z]:[\\/]' -and $body.Contains('relative to the directory containing this AGENTS.md')
    }
    Add-Check "Portable root onboarding boundary" $portableValid "Portable routing is separately versioned, project-relative, preserving, explicit, cancel-default and outside Commandments Update."
    $automationPolicy = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsGameForgeAutomationTechnique.md'))
    $capabilityPolicy = $automationPolicy.Contains('ForgeCapabilities.json') -and $automationPolicy.Contains('exact package identity/version') -and $automationPolicy.Contains('Planned features never acquire supported operations') -and $automationPolicy.Contains('actual installed')
    # Installed observations, outcome vocabulary and the mandatory release gate are distinct requirements.
    $capabilityPolicy = $capabilityPolicy -and $automationPolicy.Contains('actual installed') -and $automationPolicy.Contains('partial') -and $automationPolicy.Contains('source fingerprints') -and $automationPolicy.Contains('documentation/capability gate') -and $automationPolicy.Contains('BigBang and the passive adapter remain independent')
    Add-Check "Supported operation and capability evidence" $capabilityPolicy "Owner operations, partial/unknown evidence, installed observations, planned-feature separation and compile-checked release gates are required."

    $nativeTemplates = @(
        "Tools/AIAgentInstructionTemplates/copilot-instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md",
        "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md"
    )
    $expectedTemplateVersion = "1.3.0"
    $expectedProjectRouteText = 'Before any Geurts Game Forge project work, read and follow `GeurtsGameForgeCommandments/AI_READ_FIRST.md`; it routes to the installed, manifest-selected documentation. Treat that documentation as the source of truth for the work.'
    $expectedManagedRegionHashes = @{
        "Tools/AIAgentInstructionTemplates/copilot-instructions.md|copilot-body" = "92e4a7ae1ff00f20480b217108a028bce40276a97d4caa3b614588fdf75874bc"
        "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md|unity-frontmatter" = "98e4fd786bbd1474e28d3800b91d749c29ff2acf94b89ef821d6860645829688"
        "Tools/AIAgentInstructionTemplates/instructions/geurts-unity.instructions.md|unity-body" = "206ef83ff9c5aa0ba24b363a8c6a5735793cb697435dbeb2dce90b8a117bef91"
        "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md|game-design-frontmatter" = "334b60274fe81a1891e1500785d29a249a0d4e32957bb665a770402163fa2cd4"
        "Tools/AIAgentInstructionTemplates/instructions/geurts-game-design.instructions.md|game-design-body" = "069e94f46d2860a040a8f9bbd5aa7a21e5bc888a38990c5e7d74a6b79d4982e4"
    }
    $routeFailures = New-Object System.Collections.Generic.List[string]
    $markerFailures = New-Object System.Collections.Generic.List[string]
    $seenManagedRegionKeys = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
    $htmlRegionPattern = '(?ms)^<!--\s*GEURTS-MANAGED-BEGIN\s+id="(?<Id>[^"]+)"\s+version="(?<Version>[0-9]+\.[0-9]+\.[0-9]+)"\s+sha256="(?<Hash>[0-9a-fA-F]{64})"\s*-->\r?\n(?<Body>.*?)^<!--\s*GEURTS-MANAGED-END\s+id="\k<Id>"\s*-->[^\S\r\n]*(?=\r?\n|\z)'
    $yamlRegionPattern = '(?ms)^#\s*GEURTS-MANAGED-BEGIN\s+id="(?<Id>[^"]+)"\s+version="(?<Version>[0-9]+\.[0-9]+\.[0-9]+)"\s+sha256="(?<Hash>[0-9a-fA-F]{64})"\s*\r?\n(?<Body>.*?)^#\s*GEURTS-MANAGED-END\s+id="\k<Id>"[^\S\r\n]*(?=\r?\n|\z)'
    foreach ($relative in $nativeTemplates) {
        $path = Join-Path $RepositoryRoot ($relative.Replace('/', [System.IO.Path]::DirectorySeparatorChar))
        $text = [System.IO.File]::ReadAllText($path)
        if ([regex]::Matches($text, [regex]::Escape($expectedProjectRouteText)).Count -ne 1) { $routeFailures.Add("$relative does not contain the exact approved project-wide route once") | Out-Null }
        if ($text.IndexOf("GeurtsGameForgeCommandments/AI_READ_FIRST.md", [System.StringComparison]::Ordinal) -lt 0 -or $text.IndexOf("GeurtsGameForgeCommandments/AGENTS.md", [System.StringComparison]::Ordinal) -ge 0) { $routeFailures.Add("$relative does not route first through direct AI_READ_FIRST.md") | Out-Null }
        if ($text.IndexOf("network efficiency", [System.StringComparison]::OrdinalIgnoreCase) -ge 0) { $routeFailures.Add("$relative duplicates implementation policy instead of remaining a concise route") | Out-Null }
        if ($text.IndexOf("installed, manifest-selected documentation", [System.StringComparison]::Ordinal) -lt 0 -or $text.IndexOf("owns the complete documentation chain", [System.StringComparison]::OrdinalIgnoreCase) -ge 0) {
            $routeFailures.Add("$relative does not defer authority to the installed, manifest-selected documentation") | Out-Null
        }
        $begins = [regex]::Matches($text, 'GEURTS-MANAGED-BEGIN').Count
        $ends = [regex]::Matches($text, 'GEURTS-MANAGED-END').Count
        $htmlMatches = @([regex]::Matches($text, $htmlRegionPattern))
        $yamlMatches = @([regex]::Matches($text, $yamlRegionPattern))
        $matches = $htmlMatches + $yamlMatches
        if ($begins -eq 0 -or $ends -ne $begins -or $matches.Count -ne $begins) { $markerFailures.Add("$relative has malformed markers") | Out-Null; continue }
        $managedIds = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        foreach ($region in $matches) { if (-not $managedIds.Add($region.Groups["Id"].Value)) { $markerFailures.Add("$relative has duplicate managed ID $($region.Groups['Id'].Value)") | Out-Null } }
        if ($yamlMatches.Count -gt 0) {
            $frontmatter = [regex]::Match($text, '(?s)\A---\r?\n.*?\r?\n---')
            foreach ($yamlMatch in $yamlMatches) {
                if (-not $frontmatter.Success -or $yamlMatch.Index -le 3 -or ($yamlMatch.Index + $yamlMatch.Length) -gt ($frontmatter.Index + $frontmatter.Length)) { $markerFailures.Add("$relative has a YAML marker outside frontmatter") | Out-Null }
            }
        }
        foreach ($region in $matches) {
            $regionKey = "$relative|$($region.Groups['Id'].Value)"
            if (-not $seenManagedRegionKeys.Add($regionKey)) { $markerFailures.Add("duplicate managed region $regionKey") | Out-Null }
            if ($region.Groups["Version"].Value -cne $expectedTemplateVersion) {
                $markerFailures.Add("$relative region $($region.Groups['Id'].Value) declares version $($region.Groups['Version'].Value) instead of $expectedTemplateVersion") | Out-Null
            }
            if (-not $expectedManagedRegionHashes.ContainsKey($regionKey)) {
                $markerFailures.Add("$relative contains unexpected managed region $($region.Groups['Id'].Value)") | Out-Null
            }
            elseif ($region.Groups["Hash"].Value.ToLowerInvariant() -cne $expectedManagedRegionHashes[$regionKey]) {
                $markerFailures.Add("$relative region $($region.Groups['Id'].Value) does not declare the approved hash") | Out-Null
            }
            if ((Get-TextHash -Text $region.Groups["Body"].Value) -cne $region.Groups["Hash"].Value.ToLowerInvariant()) {
                $markerFailures.Add("$relative region $($region.Groups['Id'].Value) has a bad hash") | Out-Null
            }
        }
    }
    foreach ($regionKey in $expectedManagedRegionHashes.Keys) { if (-not $seenManagedRegionKeys.Contains($regionKey)) { $markerFailures.Add("missing approved managed region $regionKey") | Out-Null } }
    Add-Check "Managed native routes" ($routeFailures.Count -eq 0) $(if ($routeFailures.Count) { "Invalid managed route: " + ($routeFailures -join ", ") } else { "Every native template contains the exact concise project-wide route through direct AI_READ_FIRST.md into the installed manifest-selected source of truth." })
    Add-Check "Managed template integrity" ($markerFailures.Count -eq 0 -and $seenManagedRegionKeys.Count -eq $expectedManagedRegionHashes.Count) $(if ($markerFailures.Count) { $markerFailures -join "; " } else { "All five approved v1.3.0 native managed regions and hashes are exact and valid." })

    $expectedCatalogRecords = @(
        ".github/copilot-instructions.md|copilot-instructions.md|0.4.0|d72006b497ed12ae97ef3d4ef9248f634af7159b7011434987ea3bd60cbd8da7",
        ".github/copilot-instructions.md|copilot-instructions.md|0.5.0|d72006b497ed12ae97ef3d4ef9248f634af7159b7011434987ea3bd60cbd8da7",
        ".github/copilot-instructions.md|copilot-instructions.md|0.6.0|cfeb6826447b74d391c7afa40f07e19171086ee0f6e8a107887360fa4e6fd7e3",
        ".github/instructions/geurts-unity.instructions.md|instructions/geurts-unity.instructions.md|0.4.0|27bff44e8cd8a26962b2b2890b3ca6c02a5a1ee6c0531c195514d70b9ffde92f",
        ".github/instructions/geurts-unity.instructions.md|instructions/geurts-unity.instructions.md|0.5.0|27bff44e8cd8a26962b2b2890b3ca6c02a5a1ee6c0531c195514d70b9ffde92f",
        ".github/instructions/geurts-unity.instructions.md|instructions/geurts-unity.instructions.md|0.6.0|799fe2cc0a720cd5e9f7f350b7480d219c0f92309a4a6201953e3a452faa0fa3",
        ".github/instructions/geurts-game-design.instructions.md|instructions/geurts-game-design.instructions.md|0.4.0|724549bbd75e2ed1f83167992747f5b56adac9d0b4e40886085b65d497cddbd9",
        ".github/instructions/geurts-game-design.instructions.md|instructions/geurts-game-design.instructions.md|0.5.0|724549bbd75e2ed1f83167992747f5b56adac9d0b4e40886085b65d497cddbd9",
        ".github/instructions/geurts-game-design.instructions.md|instructions/geurts-game-design.instructions.md|0.6.0|2805d6be2804eff71668625a83725d02338070a9b6988bde20bc521d455d17c0",
        ".github/copilot-instructions.md|copilot-instructions.md|1.1.0|6b727f9058bfe778592f11fd5b607d991d2f6538f1dbd66e6eedea15b3ec4835",
        ".github/instructions/geurts-unity.instructions.md|instructions/geurts-unity.instructions.md|1.1.0|f0e8da9d1189320c45f2c68b319e5c831e881077d95c75fc23d6d4835d0270e0",
        ".github/instructions/geurts-game-design.instructions.md|instructions/geurts-game-design.instructions.md|1.1.0|4f39c1f5c96ae35140643aee53d673630c2439639d4d6930d1be9dc3d4627a71",
        ".github/copilot-instructions.md|copilot-instructions.md|1.2.0|9ac2915513d05f9fa001d940f10c77f9cfd9ebda34de995559c91c72a2cf2614",
        ".github/instructions/geurts-unity.instructions.md|instructions/geurts-unity.instructions.md|1.2.0|3b7f63f87a4ef6779c7822ca2a9881f6c315ec9e5b4f0862f8c6c7c180057b9c",
        ".github/instructions/geurts-game-design.instructions.md|instructions/geurts-game-design.instructions.md|1.2.0|754b236b5072be504bdef384fd6896f3b91a34f1d91225d4484e0ae88f5c46cd"
    )
    $catalogFailures = New-Object System.Collections.Generic.List[string]
    try { $migrationCatalog = Get-Content -LiteralPath (Join-Path $RepositoryRoot "Tools/NativeEntryMigrationCatalog.json") -Raw | ConvertFrom-Json }
    catch { $migrationCatalog = $null; $catalogFailures.Add("catalog JSON is invalid") | Out-Null }
    if ($migrationCatalog) {
        if ([string]$migrationCatalog.schemaVersion -cne "2.0.0" -or [string]$migrationCatalog.normalization -cne "utf8-text-with-lf-newlines-and-terminal-lf" -or @($migrationCatalog.entries).Count -ne 3) { $catalogFailures.Add("catalog metadata or target count is invalid") | Out-Null }
        $actualCatalogRecords = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        foreach ($entry in @($migrationCatalog.entries)) {
            $expectedEntryFields = @("legacyFingerprints", "targetPath", "templatePath")
            $actualEntryFields = @($entry.PSObject.Properties | Select-Object -ExpandProperty Name | Sort-Object)
            if ($actualEntryFields.Count -ne $expectedEntryFields.Count) { $catalogFailures.Add("catalog entry property set is not generic") | Out-Null }
            else { for ($entryFieldIndex = 0; $entryFieldIndex -lt $expectedEntryFields.Count; $entryFieldIndex++) { if ([string]$actualEntryFields[$entryFieldIndex] -cne [string]$expectedEntryFields[$entryFieldIndex]) { $catalogFailures.Add("catalog entry property set is not generic") | Out-Null; break } } }
            foreach ($fingerprint in @($entry.legacyFingerprints)) {
                foreach ($version in @($fingerprint.versions)) {
                    $record = "{0}|{1}|{2}|{3}" -f [string]$entry.targetPath, [string]$entry.templatePath, [string]$version, ([string]$fingerprint.sha256).ToLowerInvariant()
                    if (-not $actualCatalogRecords.Add($record)) { $catalogFailures.Add("duplicate catalog record $record") | Out-Null }
                }
            }
        }
        $expectedCatalogSet = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
        foreach ($record in $expectedCatalogRecords) { [void]$expectedCatalogSet.Add($record) }
        if ($actualCatalogRecords.Count -ne $expectedCatalogSet.Count) { $catalogFailures.Add("catalog record count differs from the approved historical matrix") | Out-Null }
        foreach ($record in $expectedCatalogSet) { if (-not $actualCatalogRecords.Contains($record)) { $catalogFailures.Add("missing approved catalog record $record") | Out-Null } }
        foreach ($record in $actualCatalogRecords) { if (-not $expectedCatalogSet.Contains($record)) { $catalogFailures.Add("unexpected catalog record $record") | Out-Null } }
    }
    Add-Check "Migration catalog integrity" ($catalogFailures.Count -eq 0) $(if ($catalogFailures.Count) { $catalogFailures -join "; " } else { "The exact Geurts-owned historical native-entry fingerprints are valid, with no product-owned block migration data." })

    $gddTemplate = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/GameDesign/GameDesignManifest.md"))
    $gddReadmeTemplate = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/AIAgentInstructionTemplates/GameDesign/README.md"))
    $gddFields = @("ID", "Path", "Purpose", "Status", "Version", "Authority", "Tags", "SHA256")
    $gddValid = $gddTemplate.Contains('GEURTS-GDD-MANIFEST-BEGIN version="0.7.0"') -and @($gddFields | Where-Object { $gddTemplate -notmatch "\|\s*$([regex]::Escape($_))\s*\|" }).Count -eq 0 -and $gddReadmeTemplate.Contains('GEURTS-SCAFFOLD-BEGIN version="0.11.0"') -and $gddReadmeTemplate -match '(?i)project-local fetched Geurts documentation copy' -and $gddReadmeTemplate -match '(?i)missing information would establish or change player-facing design intent' -and $gddReadmeTemplate -match '(?i)reversible technical details that do not create or overwrite design facts'
    Add-Check "GDD scaffold contract" $gddValid "Managed GDD index retains its deterministic v0.7.0 format, while the v0.11.0 README separates project-authored GDD from the fetched copy, stops for missing design intent, and permits only reversible non-design assumptions."

    $definitionPath = Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureDefinition.json"
    $folderFailures = New-Object System.Collections.Generic.List[string]
    if (-not (Test-Path -LiteralPath $definitionPath -PathType Leaf)) {
        $folderFailures.Add("definition missing") | Out-Null
    }
    else {
        try { $definition = Get-Content -LiteralPath $definitionPath -Raw | ConvertFrom-Json }
        catch { $definition = $null; $folderFailures.Add("invalid JSON") | Out-Null }
        if ($definition) {
            $folders = @($definition.managedFolders)
            $topLevelExpected = @{
                schemaVersion = "1.0.0"
                definitionVersion = "0.13.0"
                packageVersion = "0.61.1"
                canonicalPath = "GeurtsTechniques/GeurtsFolderStructureDefinition.json"
                pathBase = "<ProjectRoot>"
                pathSeparator = "/"
                explanatoryAuthority = "GeurtsTechniques/GeurtsFolderStructureTechnique.md"
                automationAuthority = "GeurtsTechniques/GeurtsFolderStructureDefinition.json"
            }
            foreach ($name in $topLevelExpected.Keys) {
                if ([string]$definition.$name -cne [string]$topLevelExpected[$name]) { $folderFailures.Add("$name is not '$($topLevelExpected[$name])'") | Out-Null }
            }
            if ($folders.Count -ne 78 -or [int]$definition.managedFolderCount -ne 78) { $folderFailures.Add("managed folder count is not exactly 78") | Out-Null }
            if ([int]$definition.projectStructureFolderCount -ne 76) { $folderFailures.Add("projectStructureFolderCount is not 76") | Out-Null }

            $allowedCategories = @("documentation", "generated-content", "third-party-content", "tooling", "unity-project")
            $declaredCategories = @($definition.contentCategories | Sort-Object)
            if ($declaredCategories.Count -ne $allowedCategories.Count) { $folderFailures.Add("contentCategories does not contain exactly five entries") | Out-Null }
            else {
                for ($categoryIndex = 0; $categoryIndex -lt $allowedCategories.Count; $categoryIndex++) {
                    if ([string]$declaredCategories[$categoryIndex] -cne $allowedCategories[$categoryIndex]) { $folderFailures.Add("contentCategories differs from the five-value authority") | Out-Null; break }
                }
            }

            $expectedProfileOwners = @{
                "full-project-structure" = "folder-structure-tool"
                "native-entry" = "native-entry-manager"
                "gdd-scaffolding" = "native-entry-manager"
                "bootstrap" = "god-bootstrap"
            }
            $expectedProfileCounts = @{
                "full-project-structure" = 76
                "native-entry" = 2
                "gdd-scaffolding" = 2
                "bootstrap" = 8
            }
            $profileIds = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
            if (@($definition.creationProfiles).Count -ne 4) { $folderFailures.Add("creationProfiles does not contain exactly four entries") | Out-Null }
            foreach ($profile in @($definition.creationProfiles)) {
                $profileId = [string]$profile.id
                if (-not $profileIds.Add($profileId)) { $folderFailures.Add("duplicate creation profile '$profileId'") | Out-Null }
                if (-not $expectedProfileOwners.ContainsKey($profileId)) { $folderFailures.Add("unknown creation profile '$profileId'") | Out-Null }
                elseif ([string]$profile.owner -cne [string]$expectedProfileOwners[$profileId]) { $folderFailures.Add("profile '$profileId' has incorrect owner") | Out-Null }
                if ([string]::IsNullOrWhiteSpace([string]$profile.purpose)) { $folderFailures.Add("profile '$profileId' has no purpose") | Out-Null }
            }
            foreach ($profileId in $expectedProfileOwners.Keys) {
                if (-not $profileIds.Contains($profileId)) { $folderFailures.Add("missing creation profile '$profileId'") | Out-Null }
            }

            $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
            $seenIgnoreCase = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::OrdinalIgnoreCase)
            $profileCounts = @{}
            foreach ($profileId in $expectedProfileOwners.Keys) { $profileCounts[$profileId] = 0 }
            $folderTechniqueText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureTechnique.md"))
            foreach ($folder in $folders) {
                $folderPath = [string]$folder.path
                if ($folderPath -ceq "GeurtsGameForgeCommandments") { $folderFailures.Add("reserved documentation container appears in the managed creation registry") | Out-Null }
                if (-not (Test-SafeDefinitionPath -Path $folderPath)) { $folderFailures.Add("unsafe folder path '$folderPath'") | Out-Null }
                if (-not $seen.Add($folderPath) -or -not $seenIgnoreCase.Add($folderPath)) { $folderFailures.Add("duplicate folder path '$folderPath'") | Out-Null }
                if ($folder.requirement -notin @("required", "optional") -or [string]::IsNullOrWhiteSpace([string]$folder.purpose) -or [string]$folder.contentCategory -notin $allowedCategories) { $folderFailures.Add("$folderPath has invalid requirement, purpose, or category") | Out-Null }
                if (-not $folder.automation -or $folder.automation.mayCreate -isnot [bool] -or $folder.automation.mayRemove -isnot [bool] -or $folder.automation.mayCreate -ne $true -or $folder.automation.mayRemove -ne $false -or [string]::IsNullOrWhiteSpace([string]$folder.automation.owner)) {
                    $folderFailures.Add("$folderPath has an invalid create-only automation policy") | Out-Null
                    continue
                }

                $profiles = @($folder.automation.creationProfiles)
                if ($profiles.Count -eq 0) { $folderFailures.Add("$folderPath has no creation profile") | Out-Null }
                $expectedFolderProfiles = @(Get-ExpectedFolderProfiles -Path $folderPath | Sort-Object)
                $actualFolderProfiles = @($profiles | ForEach-Object { [string]$_ } | Sort-Object)
                $profileScopeValid = $actualFolderProfiles.Count -eq $expectedFolderProfiles.Count
                if ($profileScopeValid) {
                    for ($profileIndex = 0; $profileIndex -lt $expectedFolderProfiles.Count; $profileIndex++) {
                        if ($actualFolderProfiles[$profileIndex] -cne $expectedFolderProfiles[$profileIndex]) { $profileScopeValid = $false; break }
                    }
                }
                if (-not $profileScopeValid) { $folderFailures.Add("$folderPath differs from its exact v0.13.0 profile scope") | Out-Null }
                $folderDelegations = @{}
                if ($folder.automation.PSObject.Properties["delegatedOwners"]) {
                    foreach ($delegation in @($folder.automation.delegatedOwners.PSObject.Properties)) {
                        $delegatedProfile = [string]$delegation.Name
                        $delegatedOwner = [string]$delegation.Value
                        if (-not $expectedProfileOwners.ContainsKey($delegatedProfile) -or $profiles -notcontains $delegatedProfile -or $delegatedOwner -cne [string]$expectedProfileOwners[$delegatedProfile]) {
                            $folderFailures.Add("$folderPath has invalid delegation for '$delegatedProfile'") | Out-Null
                        }
                        $folderDelegations[$delegatedProfile] = $delegatedOwner
                    }
                    if (@($folder.automation.delegatedOwners.PSObject.Properties).Count -ne 1 -or (($folderPath -in @("Docs", "Docs/GameDesign")) -and -not $folderDelegations.ContainsKey("gdd-scaffolding")) -or (($folderPath -in @("Assets", "Assets/_Project", "Assets/_Project/Scenes", "Assets/_Project/Scenes/Boot", "Assets/_Project/Scenes/Frontend", "Assets/_Project/Scenes/Gameplay", "Assets/_Project/Scenes/Test", "Assets/_Project/Scenes/Sandbox")) -and -not $folderDelegations.ContainsKey("bootstrap")) -or ($folderPath -notin @("Docs", "Docs/GameDesign", "Assets", "Assets/_Project", "Assets/_Project/Scenes", "Assets/_Project/Scenes/Boot", "Assets/_Project/Scenes/Frontend", "Assets/_Project/Scenes/Gameplay", "Assets/_Project/Scenes/Test", "Assets/_Project/Scenes/Sandbox"))) {
                        $folderFailures.Add("$folderPath has an unauthorized delegation object") | Out-Null
                    }
                }
                elseif ($folderPath -in @("Docs", "Docs/GameDesign", "Assets", "Assets/_Project", "Assets/_Project/Scenes", "Assets/_Project/Scenes/Boot", "Assets/_Project/Scenes/Frontend", "Assets/_Project/Scenes/Gameplay", "Assets/_Project/Scenes/Test", "Assets/_Project/Scenes/Sandbox")) {
                    $folderFailures.Add("$folderPath is missing its gdd-scaffolding delegation") | Out-Null
                }

                foreach ($profileId in $profiles) {
                    $profileId = [string]$profileId
                    if (-not $expectedProfileOwners.ContainsKey($profileId)) { $folderFailures.Add("$folderPath references unknown profile '$profileId'") | Out-Null; continue }
                    $profileCounts[$profileId] = [int]$profileCounts[$profileId] + 1
                    $primaryMatches = ([string]$folder.automation.owner -ceq [string]$expectedProfileOwners[$profileId])
                    $delegationMatches = $folderDelegations.ContainsKey($profileId) -and ([string]$folderDelegations[$profileId] -ceq [string]$expectedProfileOwners[$profileId])
                    if (-not $primaryMatches -and -not $delegationMatches) { $folderFailures.Add("$folderPath is not authorized for profile '$profileId'") | Out-Null }
                }
            }

            foreach ($folder in $folders) {
                $folderPath = [string]$folder.path
                $parent = [string]$folder.parent
                if ($folderPath.Contains('/')) {
                    $expectedParent = $folderPath.Substring(0, $folderPath.LastIndexOf('/'))
                    if ($parent -cne $expectedParent -or -not $seen.Contains($parent)) { $folderFailures.Add("$folderPath has invalid parent '$parent'") | Out-Null }
                }
                elseif (-not [string]::IsNullOrWhiteSpace($parent)) { $folderFailures.Add("root folder $folderPath must not declare a parent") | Out-Null }
            }
            foreach ($profileId in $expectedProfileCounts.Keys) {
                if ([int]$profileCounts[$profileId] -ne [int]$expectedProfileCounts[$profileId]) { $folderFailures.Add("profile '$profileId' selects $($profileCounts[$profileId]) folders instead of $($expectedProfileCounts[$profileId])") | Out-Null }
                $selectedPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
                foreach ($selectedFolder in @($folders | Where-Object { @($_.automation.creationProfiles) -contains $profileId })) { [void]$selectedPaths.Add([string]$selectedFolder.path) }
                foreach ($selectedFolder in @($folders | Where-Object { @($_.automation.creationProfiles) -contains $profileId })) {
                    $parent = [string]$selectedFolder.parent
                    if (-not [string]::IsNullOrWhiteSpace($parent) -and -not $selectedPaths.Contains($parent)) { $folderFailures.Add("profile '$profileId' is not parent-closed at '$($selectedFolder.path)'") | Out-Null }
                }
            }

            $registryMatch = [regex]::Match($folderTechniqueText, '(?ms)<!-- GEURTS-FOLDER-PATHS:BEGIN -->\s*```text\s*(?<Paths>.*?)\s*```\s*<!-- GEURTS-FOLDER-PATHS:END -->')
            if (-not $registryMatch.Success -or [regex]::Matches($folderTechniqueText, 'GEURTS-FOLDER-PATHS:BEGIN').Count -ne 1 -or [regex]::Matches($folderTechniqueText, 'GEURTS-FOLDER-PATHS:END').Count -ne 1) {
                $folderFailures.Add("Markdown literal path registry is missing or malformed") | Out-Null
            }
            else {
                $documentedPaths = New-Object 'System.Collections.Generic.HashSet[string]' ([System.StringComparer]::Ordinal)
                foreach ($line in ($registryMatch.Groups["Paths"].Value -split '\r?\n')) {
                    $documentedPath = $line.Trim()
                    if ([string]::IsNullOrWhiteSpace($documentedPath)) { continue }
                    if (-not (Test-SafeDefinitionPath -Path $documentedPath) -or -not $documentedPaths.Add($documentedPath)) { $folderFailures.Add("invalid or duplicate Markdown registry path '$documentedPath'") | Out-Null }
                }
                if ($documentedPaths.Count -ne $seen.Count) { $folderFailures.Add("Markdown and JSON path counts differ") | Out-Null }
                foreach ($folderPath in $seen) { if (-not $documentedPaths.Contains($folderPath)) { $folderFailures.Add("JSON path '$folderPath' is absent from Markdown registry") | Out-Null } }
                foreach ($documentedPath in $documentedPaths) { if (-not $seen.Contains($documentedPath)) { $folderFailures.Add("Markdown path '$documentedPath' is absent from JSON") | Out-Null } }
            }
        }
    }
    $folderToolText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/CreateGeurtsFolderStructure.ps1"))
    $folderManagerText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/ManageGeurtsAgentInstructions.ps1"))
    $folderTechniqueVersion = Get-DeclaredVersion -Path (Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsFolderStructureTechnique.md")
    $folderDefinitionVersion = if ($definition) { [string]$definition.definitionVersion } else { $null }
    $folderVersionParityValid = $folderTechniqueVersion -ceq "0.16.6" -and $folderDefinitionVersion -ceq "0.13.0" -and $folderToolText.Contains('[string]$definition.definitionVersion -ne "0.13.0"') -and $folderToolText.Contains('Folder definition version must be 0.13.0') -and $folderManagerText.Contains('[string]$definition.definitionVersion -ne "0.13.0"') -and $folderManagerText.Contains('Managed setup requires folder definition v0.13.0')
    if (-not $folderVersionParityValid) { $folderFailures.Add("folder technique v0.16.6, JSON definition v0.13.0 and consuming tools do not agree") | Out-Null }
    if ($folderToolText.Contains('(Join-Path $ProjectRoot "GeurtsTechniques/GeurtsFolderStructureDefinition.json")')) { $folderFailures.Add("folder tool still discovers an unselected raw project-root definition") | Out-Null }
    $folderDirectoryBarrier = $folderToolText.IndexOf('Invoke-TestDirectoryBarrier -TargetPath $folder.TargetPath', [System.StringComparison]::Ordinal)
    $folderFinalContainment = if ($folderDirectoryBarrier -ge 0) { $folderToolText.IndexOf('Test-IsContainedPath -Candidate $finalTargetPath', $folderDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $folderFinalReparse = if ($folderDirectoryBarrier -ge 0) { $folderToolText.IndexOf('Test-HasReparsePoint -Candidate $finalTargetPath', $folderDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $folderExistingAcceptance = if ($folderDirectoryBarrier -ge 0) { $folderToolText.IndexOf('Test-Path -LiteralPath $finalTargetPath -PathType Container', $folderDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $folderDirectoryCreate = if ($folderDirectoryBarrier -ge 0) { $folderToolText.IndexOf('New-Item -ItemType Directory -Path $finalTargetPath', $folderDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $folderDirectoryGuardOrderValid = $folderDirectoryBarrier -ge 0 -and $folderFinalContainment -gt $folderDirectoryBarrier -and $folderFinalReparse -ge $folderFinalContainment -and $folderExistingAcceptance -gt $folderFinalReparse -and $folderDirectoryCreate -gt $folderExistingAcceptance
    $folderOwnerSafetyValid = $folderTechniqueTextForPathTerms -match '(?i)Unity project root itself must not be a junction, symbolic link, or other reparse point' -and $folderTechniqueTextForPathTerms -match '(?i)Immediately before accepting an existing managed directory or creating a missing one' -and $folderTechniqueTextForPathTerms -match '(?i)re-resolve containment below the validated project root' -and $folderTechniqueTextForPathTerms -match '(?i)complete path chain.*newly introduced reparse points' -and $folderTechniqueTextForPathTerms -match '(?i)must not create a descendant outside the project'
    if ($folderToolText -notmatch '(?is)function Assert-UnityProjectRoot.*?rootItem.*?FileAttributes\]::ReparsePoint') { $folderFailures.Add("folder tool does not reject a reparse-point Unity root") | Out-Null }
    if (-not $folderDirectoryGuardOrderValid) { $folderFailures.Add("folder tool does not recheck containment and the full reparse chain immediately before directory acceptance/creation") | Out-Null }
    if (-not $folderOwnerSafetyValid) { $folderFailures.Add("Folder Technique does not own the root and final directory reparse boundary") | Out-Null }
    Add-Check "Folder definition contract" ($folderFailures.Count -eq 0) $(if ($folderFailures.Count) { $folderFailures -join "; " } else { "Definition versions, 78 entries, owner-bound profiles, package-only resolution, and exact Markdown parity are valid; root and per-directory final reparse guards prevent creation outside the project." })

    $folderVersionGuard = "(?im)^\*\*Version:\*\*\s*0\.16\.6\s*$"
    Add-Check 'Folder technique reader version parity' ($folderToolText.Contains($folderVersionGuard) -and $folderTechniqueTextForPathTerms -match $folderVersionGuard) 'The folder creator accepts the registered Folder Technique 0.16.6; unsupported explanatory authority versions remain blocked.'

    $chatSubjectRow = [regex]::Match($manifestText, '(?m)^\| Chat-only response style and scope \| `(?<Path>[^`]+)` \| (?<Applicability>[^|]+) \|\r?$')
    $chatRegistryRow = [regex]::Match($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsAIResponseControlTechnique_V1\.1\.md` \| 1\.1 \| (?<Role>[^|]+) \|\r?$')
    $chatOnlyValid = $chatSubjectRow.Success -and $chatSubjectRow.Groups["Path"].Value -ceq "GeurtsTechniques/GeurtsAIResponseControlTechnique_V1.1.md" -and $chatSubjectRow.Groups["Applicability"].Value -match '(?i)compatible chat interface.*select' -and $chatSubjectRow.Groups["Applicability"].Value -match '(?i)never.*coding or architecture standard' -and $chatRegistryRow.Success -and $chatRegistryRow.Groups["Role"].Value -match '(?i)chat-only' -and $chatRegistryRow.Groups["Role"].Value -match '(?i)not an? implementation standard'
    Add-Check "Chat-only classification" $chatOnlyValid "Manifest applicability and registry role independently classify Response Control as explicitly selected chat-only behaviour, never an implementation standard."

    $technicalRelative = "GeurtsTechniques/GeurtsTechnicalTechnique.md"
    $technicalCoreText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $technicalRelative))
    $technicalTopicNames = @('Unity', 'Code', 'Authoring', 'Bootstrap', 'Audio', 'GameAI', 'Commands', 'Multiplayer')
    $topicTexts = @($technicalCoreText)
    $topicFailures = New-Object 'System.Collections.Generic.List[string]'
    foreach ($topic in $technicalTopicNames) {
        $topicRelative = 'GeurtsTechniques/Geurts' + $topic + 'Technique.md'
        if (-not $registrySet.Contains($topicRelative) -or -not $subjectOwners.Contains($topicRelative)) { $topicFailures.Add("Topic is not selected and registered: $topicRelative") | Out-Null }
        $topicPath = Join-Path $RepositoryRoot $topicRelative
        if (-not (Test-Path -LiteralPath $topicPath -PathType Leaf)) { $topicFailures.Add("Topic is missing: $topicRelative") | Out-Null; continue }
        $topicText = [IO.File]::ReadAllText($topicPath)
        $topicVersion = if ($topic -ceq 'Unity') { '0.3.1' } elseif ($topic -ceq 'Naming') { '0.1.6' } elseif ($topic -in @('GameAI','Multiplayer')) { '0.2.0' } else { '0.1.1' }
        if ($topicText -notmatch ('(?m)^\*\*Version:\*\* ' + [regex]::Escape($topicVersion) + '\r?$') -or $topicText -notmatch '(?m)^<!-- GEURTS-AUDIENCE: AI-READ -->\r?$') { $topicFailures.Add("Topic metadata is invalid: $topicRelative") | Out-Null }
        $topicTexts += $topicText
    }
    # Existing semantic guards now inspect the complete current technical owner chain.
    $technicalText = $topicTexts -join "`r`n"
    $codeText = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsCodeTechnique.md'))
    foreach ($rule in @('Every first-party public C# class', '/// <summary>', 'partial class', 'Major Component Help', '^[a-z0-9]+(?:_[a-z0-9]+)*$', '[Tooltip]', 'Every publicly accessible method')) {
        if (-not $codeText.Contains($rule)) { $topicFailures.Add("Code topic omits required rule: $rule") | Out-Null }
    }
    if ($technicalCoreText -notmatch '(?m)^\*\*Version:\*\* 0\.20\.3\r?$' -or $technicalCoreText.Length -gt 24000 -or
        -not $technicalCoreText.Contains('No-Code Module Use and Code Extensions') -or
        -not $technicalCoreText.Contains('every full absolute file and folder path below 260 characters') -or
        $technicalCoreText -match '(?m)^## (?:Game Audio and Sound Design|Command Rules|Multiplayer Efficiency Rule|Odin Inspector Usage)\r?$') {
        $topicFailures.Add('Technical core is oversized, missing shared rules or still embeds conditional topic policy') | Out-Null
    }
    $getFragments = {
        param([string]$Text)
        $seen = @{}
        foreach ($heading in [regex]::Matches($Text, '(?m)^#{1,6} (.+)\r?$')) {
            $id = $heading.Groups[1].Value.Trim().ToLowerInvariant() -replace '[^a-z0-9\s_-]', '' -replace '\s', '-'
            $fragment = $id
            if ($seen.ContainsKey($id)) { $seen[$id]++; $fragment += '-' + $seen[$id] } else { $seen[$id] = 0 }
            $fragment
        }
        foreach ($anchor in [regex]::Matches($Text, '<a id="([^"]+)"></a>')) { $anchor.Groups[1].Value }
    }
    $coreFragments = @(& $getFragments $technicalCoreText)
    $legacyFragments = @(
        'geurts-technical-technique', 'purpose', 'manifest-boundary', 'technical-priority-order', 'multiplayer-exception',
        'no-code-module-use-and-code-extensions', 'normal-use-through-the-editor', 'code-remains-a-supported-first-class-path',
        'special-exceptions', 'windows-development-and-build-workflow', 'absolute-path-length-and-workspace-roots',
        'combined-unity-cli-and-editor-workflow', 'unity-600063f1-compatibility-baseline', 'editor-and-dependency-selection',
        'c-and-net', 'current-api-choices', 'async-and-lifecycle', 'unity-66-migration-checks', 'verification-and-evidence',
        'required-project-scenes', 'bootstrap-scenes-and-runtime-persistence', 'reusable-framework-compliance-header',
        'selectively-adapted-engineering-guidance', 'provenance-and-authority', 'understand-inspect-and-reuse', 'codex-compatibility',
        'implement-integrate-and-handle-failure', 'verify-test-and-preserve-compatibility', 'technical-evidence-for-reporting',
        'boundaries-with-other-subjects', 'ai-integration-technique', 'coding-standards', 'asset-and-scene-object-names',
        'id-names', 'variables', 'enums', 'ui', 'game-audio-and-sound-design', 'code-documentation-standards', 'purpose-1',
        'major-component-help', 'public-classes', 'public-methods', 'private-methods', 'odin-inspector-usage',
        'runtime-debugging-and-logging', 'objective', 'runtime-console-integration',
        'required-quantum-console-library-and-optional-console-use', 'accessibility', 'command-rules', 'full-names-only',
        'naming-convention', 'help-commands', 'command-classification', 'cheat-commands', 'logging-standards',
        'performance-monitoring', 'objective-1', 'requirements', 'overlay-design', 'example-quantum-console-commands',
        'performance-trade-off-guidance-under-efficiency', 'multiplayer-efficiency-rule', 'definition-of-done-for-ai-created-or-modified-scripts'
    )
    foreach ($id in $legacyFragments) {
        if (@($coreFragments | Where-Object { $_ -ceq $id }).Count -ne 1) { $topicFailures.Add("Missing or duplicate legacy Technical fragment: $id") | Out-Null }
    }
    foreach ($redirect in [regex]::Matches($technicalCoreText, '<a id="[^"]+"></a>\[[^\]]+\]\((?<Path>[^#)]*)#(?<Id>[^)]+)\)')) {
        $target = $redirect.Groups['Path'].Value
        $targetText = if ($target.Length) { [IO.File]::ReadAllText((Join-Path (Join-Path $RepositoryRoot 'GeurtsTechniques') $target)) } else { $technicalCoreText }
        if ($redirect.Groups['Id'].Value -cnotin @(& $getFragments $targetText)) {
            $topicFailures.Add("Dangling legacy Technical redirect: $($redirect.Value)") | Out-Null
        }
    }
    Add-Check 'Technical topic routing and retained rules' ($topicFailures.Count -eq 0) $(if ($topicFailures.Count) { $topicFailures -join '; ' } else { 'The short Technical core preserves shared priorities and boundaries; eight registered conditional topics retain implementation, XML, IDs, Help and compatibility policy.' })

    $companionToolFailures = New-Object System.Collections.Generic.List[string]
    foreach ($text in @($companionTechniqueText)) {
        if (-not $text.Contains('requires separately installed licensed Odin Inspector and Quantum Console assemblies')) {
            $companionToolFailures.Add('God-owned Commandments must retain required licensed libraries') | Out-Null
        }
    }
    foreach ($text in @($technicalText, $aiReadFirstText)) {
        if (-not $text.Contains('GeurtsBrickContract.md#identity-and-dependencies')) {
            $companionToolFailures.Add('Entry and Technical must reference the dependency owner') | Out-Null
        }
    }
    if (-not $brickContractText.Contains('Odin Inspector and Quantum Console are required for God and dependent Unity bricks')) {
        $companionToolFailures.Add('Brick Contract must retain required licensed libraries') | Out-Null
    }
    $companionCatalogueEntries = @($brickCatalogue.bricks | Where-Object { $_.id -ceq 'com.geurts.gameforge.documentation' })
    if ($companionCatalogueEntries.Count -ne 1 -or @($companionCatalogueEntries[0].dependencies).Count -ne 0 -or
        @($companionCatalogueEntries[0].requiredTools).Count -ne 0 -or $companionCatalogueEntries[0].compatibilityOnly -ne $true -or
        'Odin Inspector' -cnotin @($godEntries[0].requiredTools) -or 'Quantum Console' -cnotin @($godEntries[0].requiredTools)) {
        $companionToolFailures.Add('God retains licensed tools; the passive adapter must be compatibility-only with no vendor or package dependencies') | Out-Null
    }
    Add-Check "Companion licensed tooling boundary" ($companionToolFailures.Count -eq 0) $(if ($companionToolFailures.Count) { $companionToolFailures -join '; ' } else { 'God owns licensed tooling requirements; only the passive compatibility adapter is exempt.' })

    $bigBangRelative = 'GeurtsTechniques/GeurtsBigBangTechnique.md'
    $bigBangText = [IO.File]::ReadAllText((Join-Path $RepositoryRoot $bigBangRelative))
    $bigBangFailures = New-Object System.Collections.Generic.List[string]
    foreach ($rule in @('com.geurts.gameforge.bigbang', '6000.6.3f1', 'stale `ODIN_INSPECTOR` symbol',
        'Do not implement `IBrick`, reference God/vendor assemblies or declare God in `package.json.dependencies`',
        'Ordinary God and dependent bricks retain their required licensed',
        'Runtime initialization and `SCN_BigBang` remain God-owned', 'Resolve the latest published compatible God release on every explicit Get Latest Git Source action and again immediately before installation',
        'Do not patch God or maintain a second dependency planner', 'UPM success alone never means God ready',
        'Unknown native outcomes must be inspected before Retry', 'Library/GeurtsGameForgeBigBang/',
        'Check prerequisites inspects local libraries, compilation and package inventory without starting a remote Git lookup',
        'Provide a separate **Get Latest Git Source** button', 'A successful current compilation must not be requested again just to discover source',
        'Use a normal incremental compilation request', 'A successful cached-only cycle must not wait for a script reload',
        'read inputs through supported extended-length paths', 'A fingerprint read failure leaves evidence Unknown and must show the affected path',
        'Removing BigBang through UPM must leave God and project content functional', 'missing coverage remains an explicit acceptance gap')) {
        if (-not $bigBangText.Contains($rule)) { $bigBangFailures.Add("BigBang requirement missing: $rule") | Out-Null }
    }
    if (-not $technicalText.Contains('[BigBang Technique](GeurtsBigBangTechnique.md)') -or
        -not $brickContractText.Contains('[BigBang Technique](GeurtsBigBangTechnique.md)')) {
        $bigBangFailures.Add('Technical and Brick Contract must select the narrow exception while retaining ordinary requirements') | Out-Null
    }
    $bigCrunchValid = $bigBangText.Contains('## BigCrunch whole-Forge uninstall') -and
        $bigBangText.Contains('Unity removal dry run before confirmation') -and
        $bigBangText.Contains('Retain installed non-Forge Registry and BuiltIn versions with exact pins') -and
        $bigBangText.Contains('Include those same frozen pins in both the dry run and confirmed grouped removal') -and
        $bigBangText.Contains('confirmation writes these pins to `Packages/manifest.json` and may make indirect dependencies direct') -and
        $bigBangText.Contains("Delete only confirmed removed packages' exact owned settings files after resolved-graph verification") -and
        $bigBangText.Contains('Save the self-removal result before releasing assembly reload') -and
        $bigBangText.Contains('external package dependents') -and
        $bigBangText.Contains('third-party package changes') -and
        $bigBangText.Contains('Escape cancels') -and
        $bigBangText.Contains('Preserve unknown or interrupted results without automatic redispatch') -and
        $bigBangText.Contains('Do not delete source folders, project folder trees or generated project assets') -and
        $brickContractText.Contains('separately confirmed **BigCrunch** whole-Forge uninstaller')
    Add-Check 'BigCrunch removal boundary' $bigCrunchValid 'Whole-Forge removal requires its own dry-run review, cancel-default confirmation, retained-content guards, verified exact-settings cleanup and durable self-removal result.'
    $bigBangThemeText = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsEditorUIThemeTechnique.md'))
    if (-not $bigBangThemeText.Contains('generator-produced dependency-free subset') -or
        -not $bigBangThemeText.Contains('Exclude all IMGUI/Odin/vendor integration regardless of define symbols')) {
        $bigBangFailures.Add('BigBang canonical subset generation or vendor exclusion is absent') | Out-Null
    }
    $bigBangCatalogueEntries = @($brickCatalogue.bricks | Where-Object { $_.id -ceq 'com.geurts.gameforge.bigbang' })
    if ($bigBangCatalogueEntries.Count -ne 1 -or @($bigBangCatalogueEntries[0].dependencies).Count -ne 0 -or
        @($bigBangCatalogueEntries[0].requiredTools).Count -ne 0 -or -not $bigBangCatalogueEntries[0].released -or
        $bigBangCatalogueEntries[0].developmentOnly -or $bigBangCatalogueEntries[0].sourceKind -cne 'git' -or
        $bigBangCatalogueEntries[0].source -cnotmatch '^https://github\.com/Geurtsy/GeurtsGameForgeBigBang\.git#[a-f0-9]{40}$') {
        $bigBangFailures.Add('BigBang catalogue must publish one immutable official Git source without God or external-tool dependencies') | Out-Null
    }
    Add-Check 'Independent BigBang initial-installer boundary' ($bigBangFailures.Count -eq 0) $(if ($bigBangFailures.Count) { $bigBangFailures -join '; ' } else { 'The manifest and immutable catalogue select the independent initial installer, explicit release resolution, frozen target, fresh compile/readback, recovery, canonical subset and acceptance gates without relaxing God/brick/Companion requirements.' })

    # Guard the declared standard and discovery chain. Rendered Unity conformance is validated in package workspaces.
    $themeRelative = "GeurtsTechniques/GeurtsEditorUIThemeTechnique.md"
    $themePath = Join-Path $RepositoryRoot $themeRelative
    $themeText = if (Test-Path -LiteralPath $themePath -PathType Leaf) { [System.IO.File]::ReadAllText($themePath) } else { "" }
    $themeRoutingFailures = New-Object System.Collections.Generic.List[string]
    $themeRegistryRows = @($listedRecords | Where-Object { $_.Path -ceq $themeRelative })
    if ($themeRegistryRows.Count -ne 1 -or $themeRegistryRows[0].Version -cne "1.5.4" -or -not $trackedSet.Contains($themeRelative)) {
        $themeRoutingFailures.Add("theme technique 1.5.4 must be registered exactly once and tracked") | Out-Null
    }
    $themeOwner = [regex]::Match($manifestText, '(?m)^\| Shared visual foundation for all existing and future Forge Editor UI \| `GeurtsTechniques/GeurtsEditorUIThemeTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    if (-not $themeOwner.Success -or $themeOwner.Groups['When'].Value -notmatch '(?i)Before creating, changing, reviewing or validating' -or
        $themeOwner.Groups['When'].Value -notmatch '(?i)Runtime and player-facing game UI are excluded' -or
        $manifestText -notmatch 'Technical; Unity; Steam Integration; Code; Authoring; Bootstrap; Audio; GameAI; Commands; Multiplayer; Naming; Brick Contract and then its Catalogue; Forge Setup Technique and its Contract; BigBang installation and BigCrunch removal; Editor UI Theme; Editor Appearance; Diagnostics;') {
        $themeRoutingFailures.Add("manifest must select the Editor-only standard after Brick Contract/Catalogue and before Diagnostics") | Out-Null
    }
    foreach ($subjectText in @($technicalText, $brickContractText)) {
        if ($subjectText -notmatch 'All existing and future[^\r\n]*Editor UI must' -or
            -not $subjectText.Contains('[Editor UI Theme Technique](GeurtsEditorUIThemeTechnique.md)')) {
            $themeRoutingFailures.Add("Technical and Brick Contract must require and link the shared standard for existing and future Editor UI") | Out-Null
        }
    }
    if (-not $readmeStatusText.Contains('[Editor UI Theme Technique](GeurtsTechniques/GeurtsEditorUIThemeTechnique.md)') -or
        $null -eq $companionContract -or $themeRelative -cnotin @($companionContract.validationEntries)) {
        $themeRoutingFailures.Add("README discovery and companion source completeness must include the theme technique") | Out-Null
    }
    Add-Check "Mandatory Editor UI theme routing" ($themeRoutingFailures.Count -eq 0) $(if ($themeRoutingFailures.Count) { $themeRoutingFailures -join "; " } else { "The manifest, Technical, Brick Contract, README and companion completeness contract select the mandatory Editor-only standard for all existing and future bricks." })

    $themeFailures = New-Object System.Collections.Generic.List[string]
    $expectedThemeTokens = [ordered]@{
        Background = '#0A1012'; Panel = '#121C1E'; Raised = '#172425'; Border = '#2B433F'; Accent = '#6EF29D'; Attention = '#FFAE57';
        Text = '#DEECE7'; Muted = '#8FA8A1'; Info = '#FFFFFF'; Warning = '#FFE66D'; Error = '#FF6B6B'
    }
    foreach ($token in $expectedThemeTokens.Keys) {
        $tokenPattern = '(?m)^\| ' + [regex]::Escape($token) + ' \| `(?<Color>#[0-9A-F]{6})` \|'
        $tokenRows = @([regex]::Matches($themeText, $tokenPattern))
        if ($tokenRows.Count -ne 1 -or $tokenRows[0].Groups['Color'].Value -cne $expectedThemeTokens[$token]) {
            $themeFailures.Add("required theme token '$token' is missing, duplicated or has drifted") | Out-Null
        }
    }
    foreach ($requiredThemeRule in @(
        'mandatory visual standard for **all existing and future Geurts Game Forge bricks and Forge-owned Editor tools**',
        'This standard is **Editor-only**', 'Do not access `Docs/GameDesign/`',
        'Color alone is insufficient', 'Explain unavailable actions visibly', 'actual reason and an actionable next step',
        'Keyboard focus must remain visible', 'Show a numeric percentage only when the operation supplies measurable progress',
        'God''s Editor assembly owns the canonical public **`ForgeEditorTheme`**',
        'All bricks that depend on God must reuse', 'Editor/ForgeEditorTheme.cs', 'Editor/ForgeEditorTheme.uss',
        'Geurts.GameForge.God.Editor', 'Scope()', 'ForgeEditorTheme.ApplyToolkit(root)', 'ForgeThemedEditor',
        'ForgeEditorTheme.OpenWindow<T>(Vector2 minimumSize, string title = null)',
        ('**1000 ' + [char]0x00D7 + ' 760 Editor points**'), 'Reopening an existing window preserves its size, position, docking layout and constraints',
        'God **0.14.0** introduces this API', 'Commandments must reuse God''s canonical theme directly',
        'passive Companion adapter has no independent dashboard or generated theme', 'Tools~/SyncEditorTheme.ps1',
        'Preserve meaningful Odin configuration', 'Use the shared USS and supported UI Toolkit controls for new custom Editor UI',
        'narrow docked size', 'light and dark host skins', 'normal and high display scaling',
        'not a claim of universal automatic enforcement'
    )) {
        if (-not $themeText.Contains($requiredThemeRule)) { $themeFailures.Add("theme requirement missing: $requiredThemeRule") | Out-Null }
    }
    if ($themeText -notmatch '(?im)^\*\*Version:\*\*\s*1\.5\.4\s*$' -or
        $themeText -notmatch '^<!-- GEURTS-AUDIENCE: AI-READ -->' -or
        -not $themeText.Contains('<!-- GEURTS-SECTION:BEGIN FORGE-DEVELOPMENT-ONLY -->')) {
        $themeFailures.Add("theme version or shared/Forge-development audience boundary is absent") | Out-Null
    }
    Add-Check "Editor UI theme contract" ($themeFailures.Count -eq 0) $(if ($themeFailures.Count) { $themeFailures -join "; " } else { "Exact dark/green tokens, semantic severity, actionable states, shared API/USS, independent generated companion, truthful progress and bounded visual review are required. This check does not certify rendered Unity UI." })

    # Validate the declared Appearance policy and discovery, never rendered Unity behavior.
    $appearanceRelative = 'GeurtsTechniques/GeurtsEditorAppearanceTechnique.md'
    $appearancePath = Join-Path $RepositoryRoot $appearanceRelative
    $appearanceText = if (Test-Path -LiteralPath $appearancePath -PathType Leaf) { [IO.File]::ReadAllText($appearancePath) } else { '' }
    $appearanceRoutingFailures = New-Object 'System.Collections.Generic.List[string]'
    $appearanceRows = @($listedRecords | Where-Object { $_.Path -ceq $appearanceRelative })
    if ($appearanceRows.Count -ne 1 -or $appearanceRows[0].Version -cne '0.1.6' -or -not $trackedSet.Contains($appearanceRelative)) {
        $appearanceRoutingFailures.Add('Appearance 0.1.6 must be registered exactly once and tracked') | Out-Null
    }
    $appearanceOwner = [regex]::Match($manifestText, '(?m)^\| Forge-owned Editor workflow presentation, tabs, collapsible sections, callouts and inline authoring validation \| `GeurtsTechniques/GeurtsEditorAppearanceTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    if (-not $appearanceOwner.Success -or $appearanceOwner.Groups['When'].Value -notmatch 'Before creating, changing, reviewing or validating' -or
        $appearanceOwner.Groups['When'].Value -notmatch 'standalone/God-embedded views' -or
        $appearanceOwner.Groups['When'].Value -notmatch 'Apply Theme then Appearance' -or
        $appearanceOwner.Groups['When'].Value -notmatch 'Excludes runtime and player-facing game UI' -or
        -not $resolverBody.Contains('Editor UI Theme; Editor Appearance; Diagnostics;')) {
        $appearanceRoutingFailures.Add('manifest must select the scoped Appearance owner after Theme and before Diagnostics') | Out-Null
    }
    foreach ($subjectText in @($technicalText, $brickContractText, $themeText)) {
        if (-not $subjectText.Contains('[Editor Appearance Technique](GeurtsEditorAppearanceTechnique.md)')) {
            $appearanceRoutingFailures.Add('Technical, Brick Contract and Theme must link the Appearance owner') | Out-Null
        }
    }
    if (-not $technicalText.Contains('Appearance is a quality gate within the existing technical priorities, not another priority list') -or
        -not $readmeStatusText.Contains('[Editor Appearance Technique](GeurtsTechniques/GeurtsEditorAppearanceTechnique.md)') -or
        $null -eq $companionContract -or $appearanceRelative -cnotin @($companionContract.validationEntries)) {
        $appearanceRoutingFailures.Add('quality gate, README discovery or archive completeness is missing') | Out-Null
    }
    $appearanceMigrationRelative = 'Migrations/v0.44.0.md'
    if (-not $registrySet.Contains($appearanceMigrationRelative) -or -not $trackedSet.Contains($appearanceMigrationRelative) -or
        -not $appearanceText.Contains('(../Migrations/v0.44.0.md)')) {
        $appearanceRoutingFailures.Add('tracked adoption note and Appearance link are missing') | Out-Null
    }
    Add-Check 'Editor Appearance routing' ($appearanceRoutingFailures.Count -eq 0) $(if ($appearanceRoutingFailures.Count) { $appearanceRoutingFailures -join '; ' } else { 'The manifest selects Appearance after Theme; existing owners, README, archive completeness and adoption guidance retain their own boundaries.' })

    $appearanceFailures = New-Object 'System.Collections.Generic.List[string]'
    if ($appearanceText -notmatch '(?m)^\*\*Version:\*\* 0\.1\.6\r?$' -or
        $appearanceText -notmatch '(?m)^\*\*Status:\*\* Normative mandatory standard\r?$' -or
        $appearanceText -notmatch '\A<!-- GEURTS-AUDIENCE: AI-READ -->') {
        $appearanceFailures.Add('Appearance version, normative status or shared AI audience is invalid') | Out-Null
    }
    foreach ($heading in @(
        '1. Scope and authority', '2. Appearance quality gate', '3. Shared visual foundation',
        '4. Meaningful Odin use and framework boundary', '5. Tabs and workflows',
        '6. Labelled, collapsible content sections', '7. Useful severity callouts',
        '8. Inline authoring findings and logging boundary', '9. Hidden findings, state and lifecycle',
        '10. Verification, adoption and Definition of Done'
    )) {
        if ($appearanceText -notmatch ('(?m)^## ' + [regex]::Escape($heading) + '\r?$')) { $appearanceFailures.Add("Appearance section missing: $heading") | Out-Null }
    }
    foreach ($rule in @(
        'first-class quality requirement and a Definition of Done gate',
        'does not add, duplicate or reorder technical priorities', 'change the multiplayer override',
        'sole owner of the palette, shared styling APIs, geometry, accessibility foundation and truthful operation status',
        'This standard is **Editor-only**', 'Do not access `Docs/GameDesign/`',
        'Use Odin Inspector extensively and meaningfully', 'New custom Editor UI retains the Technical Technique''s UI Toolkit baseline',
        'Odin Inspector validation is sufficient', 'Odin Validator product is not required',
        'This requirement must not introduce God or vendor dependencies into BigBang',
        'no dashboard, updater, menus or vendor references are added',
        'Use tabs extensively where they improve navigation', 'hide an important comparison across separate tabs',
        'Every content section must have a visible descriptive header and collapsible content',
        'Its header remains visible when collapsed', 'Use Odin `BoxGroup` extensively',
        'A BoxGroup alone is not collapsible', 'distinct hierarchical group paths',
        'Do not stack BoxGroup and FoldoutGroup at the same group path',
        'Provide many useful nearby information, warning and error callouts', 'There is no quota',
        'Each callout must include severity text and a distinct severity icon',
        'an information icon for information, a warning triangle for warnings and an error icon for errors',
        'Colour alone is insufficient', 'green branding must never replace warning/error styling',
        'Routine authoring validation findings must appear inline at the affected field or group',
        'Explain the problem and how to correct it', 'clear the finding when fixed',
        'Do not report routine invalid authoring data through Debug.Log, Debug.LogWarning or Debug.LogError',
        'Do not spam the Unity Console or Diagnostics on repaint, property drawing or OnValidate',
        'Genuine operational failures and unexpected exceptions still follow', 'no Unity fallback policy',
        'Do not suppress them', 'Finding presentation must not mutate serialized data',
        'Undo, dirty/prefab recording, multi-object handling, safe value guards',
        'Warnings and errors must remain visible on collapsed section headers', 'highest applicable severity',
        'Inactive tabs must expose warning/error indicators',
        'Evaluate relevant authoring rules independently of whether a section or tab has been opened',
        'Do not validate only drawn controls', 'clear stale findings',
        'Distinguish Not checked, Unavailable and genuinely checked/clean states',
        'standard Odin attributes', 'verify the actual behavior',
        'Inspect the actual native Unity UI', 'Text validation, source review and successful compilation do not establish rendered UI acceptance',
        'This standard does not authorize interactive desktop tests',
        'do not automatically rewrite scripts, assets, settings, layouts or user content',
        'it does not retrofit released bricks or certify their native appearance'
    )) {
        if (-not $appearanceText.Contains($rule)) { $appearanceFailures.Add("Appearance requirement missing: $rule") | Out-Null }
    }
    if ($appearanceText -match '#[0-9A-Fa-f]{6}\b' -or $appearanceText -match '(?m)^\| Token \|') {
        $appearanceFailures.Add('Appearance must reference the Theme palette instead of publishing a competing palette') | Out-Null
    }
    $appearanceExpectedContent = [regex]::Replace($appearanceText, '\A<!-- GEURTS-AUDIENCE: AI-READ -->\r?\n', '')
    foreach ($mode in @('GameUse', 'ForgeDevelopment')) {
        try {
            $appearanceRead = Read-GeurtsAudienceDocument -RepositoryRoot $RepositoryRoot -Document $appearanceRelative -Mode $mode
            if ($appearanceRead.SkippedLines -ne 0 -or $appearanceRead.Content -cne $appearanceExpectedContent) { $appearanceFailures.Add("Appearance rules or exceptions are hidden in $mode") | Out-Null }
        } catch { $appearanceFailures.Add("Appearance audience invalid: $($_.Exception.Message)") | Out-Null }
    }
    Add-Check 'Editor Appearance policy' ($appearanceFailures.Count -eq 0) $(if ($appearanceFailures.Count) { $appearanceFailures -join '; ' } else { 'Appearance specifies meaningful Odin/equivalents, tabs, collapsible headers, severity callouts, inline findings, hidden-problem discovery and native acceptance without new dependency, logging or priority owners. This is not rendered UI certification.' })

    $unityTargetFailures = New-Object System.Collections.Generic.List[string]
    foreach ($relative in @("README.md", "GeurtsTechniqueManifest.md", $technicalRelative)) {
        $targetText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative))
        $targetMatches = @([regex]::Matches($targetText, '(?m)^\*\*Unity target:\*\*\s*(?<Target>[^\r\n]+)\r?$'))
        if ($targetMatches.Count -ne 1 -or $targetMatches[0].Groups["Target"].Value.Trim() -cne "Unity 6.6 (6000.6.3f1)") {
            $unityTargetFailures.Add("$relative must declare exactly one Unity 6.6 (6000.6.3f1) target") | Out-Null
        }
    }
    $baselineSection = [regex]::Match($technicalText, '(?ms)^## Unity 6000\.6\.3f1 Compatibility Baseline\s*(?<Body>.*?)(?=^## )')
    $baselineBody = if ($baselineSection.Success) { $baselineSection.Groups["Body"].Value } else { "" }
    foreach ($requiredTerm in @(
        "ProjectSettings/ProjectVersion.txt", "Packages/manifest.json", "Packages/packages-lock.json",
        "6000.6.3f1", '"unity": "6000.6"', '"unityRelease": "3f1"', "newest stable package release verified compatible", "C# 9.0", ".NET Standard 2.1",
        ".NET Framework 4.8", "Input System", "Build Profiles", "UnityEngine.Awaitable",
        "Render Graph", "Edit Mode", "Play Mode", "IL2CPP", "do not certify separate game or companion repositories",
        "Odin Inspector and Quantum Console are required dependencies", "report that concrete blocker",
        "documentation-only repository", "Commandments Companion",
        "Never use a Unity or dependency API marked deprecated or obsolete", "FindObjectsByType", "FindObjectsSortMode"
    )) {
        if ($baselineBody.IndexOf($requiredTerm, [System.StringComparison]::Ordinal) -lt 0) {
            $unityTargetFailures.Add("Technical compatibility baseline omits '$requiredTerm'") | Out-Null
        }
    }
    Add-Check "Unity 6000.6.3f1 target" ($unityTargetFailures.Count -eq 0) $(if ($unityTargetFailures.Count) { $unityTargetFailures -join "; " } else { "README, manifest, and the Technical Technique agree on 6000.6.3f1; the technical owner declares dependency, language/API, migration, and verification requirements." })

    # This is a bounded lint of current Markdown examples, not a Unity compiler or API compatibility proof.
    $exampleFailures = New-Object System.Collections.Generic.List[string]
    $exampleCount = 0
    $unsupportedExamplePatterns = @(
        @{ Name = "obsolete object discovery"; Pattern = '\bFind(?:ObjectOfType|ObjectsOfType)\s*(?:<|\()' },
        @{ Name = "deprecated first-object discovery"; Pattern = '\bFindFirstObjectByType\s*(?:<|\()' },
        @{ Name = "deprecated sorted object discovery"; Pattern = '(?s)\bFindObjectsByType\s*(?:<[^>]+>)?\s*\([^;]*?FindObjectsSortMode' },
        @{ Name = "legacy input polling"; Pattern = '\b(?:UnityEngine\.)?Input\s*\.\s*Get(?:Axis(?:Raw)?|Button(?:Down|Up)?|Key(?:Down|Up)?|MouseButton(?:Down|Up)?)\s*\(' },
        @{ Name = "legacy Netcode RPC attribute"; Pattern = '\[\s*(?:Unity\.Netcode\.)?(?:ServerRpc|ClientRpc)(?:Attribute)?\b' },
        @{ Name = "legacy UXML factory or traits"; Pattern = '\b(?:UxmlFactory|UxmlTraits)\b' },
        @{ Name = "C# 10 file-scoped namespace"; Pattern = '(?m)^\s*namespace\s+[A-Za-z_][\w.]*\s*;' },
        @{ Name = "C# 10 global using"; Pattern = '(?m)^\s*global\s+using\s+' },
        @{ Name = "C# 10 record struct"; Pattern = '\brecord\s+struct\s+' }
    )
    $examplePaths = @($trackedPaths | Where-Object { $_ -like "*.md" -and $_ -notmatch '^(?:Migrations|Ideas)/' -and $_ -notmatch 'GeurtsGameForgeIntelligence(?:Technique|IntegrationContract)\.md$' })
    foreach ($relative in $examplePaths) {
        $exampleText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative))
        foreach ($fence in [regex]::Matches($exampleText, '(?ms)^```(?:csharp|cs|c#)[ \t]*\r?\n(?<Code>.*?)^```[ \t]*\r?$')) {
            $exampleCount++
            foreach ($rule in $unsupportedExamplePatterns) {
                if ([regex]::IsMatch($fence.Groups["Code"].Value, $rule.Pattern)) {
                    $line = 1 + [regex]::Matches($exampleText.Substring(0, $fence.Index), '\n').Count
                    $exampleFailures.Add("${relative}:${line} uses $($rule.Name)") | Out-Null
                }
            }
        }
    }
    Add-Check "Unity C# example patterns" ($exampleCount -gt 0 -and $exampleFailures.Count -eq 0) $(if ($exampleFailures.Count) { $exampleFailures -join "; " } else { "$exampleCount current C# fragments pass the bounded legacy-API and language-pattern lint; Unity compilation and player compatibility are not established by this check." })

    $priorityPattern = '(?ms)^1\.\s+\*\*Extendibility\*\*.*?^2\.\s+\*\*Efficiency\*\*.*?^3\.\s+\*\*Readability\*\*.*?^4\.\s+\*\*Updated\*\*.*?^5\.\s+\*\*Documented\*\*'
    $technicalPriorityMatches = @([regex]::Matches($technicalCoreText, $priorityPattern))
    $duplicatePriorityFiles = New-Object System.Collections.Generic.List[string]
    foreach ($relative in @("README.md", "AI_READ_FIRST.md", "GeurtsTechniqueManifest.md")) {
        if ([regex]::IsMatch([System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative)), $priorityPattern)) { $duplicatePriorityFiles.Add($relative) | Out-Null }
    }
    foreach ($technique in @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques") -Filter "*.md" -File)) {
        $relative = "GeurtsTechniques/" + $technique.Name
        if ($relative -ceq $technicalRelative -or $relative -ceq $legacyGfiRedirectRelative) { continue }
        if ([regex]::IsMatch([System.IO.File]::ReadAllText($technique.FullName), $priorityPattern)) { $duplicatePriorityFiles.Add($relative) | Out-Null }
    }
    $technicalOwnerRow = [regex]::Match($manifestText, '(?m)^\| Technical implementation and technical trade-offs \| `GeurtsTechniques/GeurtsTechnicalTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    $priorityValid = $technicalPriorityMatches.Count -eq 1 -and $duplicatePriorityFiles.Count -eq 0 -and $technicalOwnerRow.Success -and $technicalOwnerRow.Groups["When"].Value -match '(?i)sole package owner of the five technical priorities and multiplayer override' -and $technicalText -match '(?i)network efficiency overrides all other priorities' -and $technicalText -match '(?i)override applies regardless of the selected networking framework'
    Add-Check "Technical priority ownership" $priorityValid $(if ($duplicatePriorityFiles.Count) { "Competing full priority list: " + ($duplicatePriorityFiles -join ", ") } else { "The exact five priorities and framework-independent multiplayer override occur normatively only in the manifest-selected Technical Technique." })

    $technicalPolicyFailures = New-Object System.Collections.Generic.List[string]
    $odinSection = [regex]::Match($technicalText, '(?ms)^## Odin Inspector Usage\s*(?<Body>.*?)(?=^---\s*$)')
    $odinBody = if ($odinSection.Success) { $odinSection.Groups["Body"].Value } else { "" }
    if (-not $odinSection.Success -or $odinBody -notmatch '(?i)Odin Inspector is required within the implementation scope' -or $odinBody -notmatch '(?i)installed, licensed, and referenced by each applicable assembly definition' -or $odinBody -notmatch '(?i)Use Odin attributes as the default authoring layer' -or $odinBody -notmatch '(?i)declarative drawers, validation, buttons, tables, and grouping' -or $odinBody -notmatch '(?i)\[Required\].*\[MinValue\].*\[MaxValue\]' -or $odinBody -notmatch '(?i)\[ValidateInput\]' -or $odinBody -notmatch '(?i)\[ReadOnly\].*\[ShowInInspector\]' -or $odinBody -notmatch '(?i)\[OdinSerialize\]`? only when Odin serialization is required' -or $odinBody -notmatch '(?i)support Undo and dirty/prefab recording') { $technicalPolicyFailures.Add("Odin Inspector is not a required, licensed, meaningfully used implementation dependency") | Out-Null }
    $odinTokens = @([regex]::Matches($technicalText, '\[(?:OdinSerialize|BoxGroup|TabGroup|FoldoutGroup|Button|ValidateInput)(?:\(|\])'))
    foreach ($odinToken in $odinTokens) { if (-not $odinSection.Success -or $odinToken.Index -lt $odinSection.Index -or $odinToken.Index -ge ($odinSection.Index + $odinSection.Length)) { $technicalPolicyFailures.Add("Odin-specific attribute guidance appears outside its owned section") | Out-Null; break } }
    $quantumSection = [regex]::Match($technicalText, '(?ms)^### Required Quantum Console Library and Optional Console Use\s*(?<Body>.*?)(?=^### Accessibility)')
    $quantumBody = if ($quantumSection.Success) { $quantumSection.Groups["Body"].Value } else { "" }
    if (-not $quantumSection.Success -or $quantumBody -notmatch '(?i)Quantum Console remains a required licensed library' -or $quantumBody -notmatch '(?i)QFSW\.QC.*\[Command\].*\[CommandDescription\]' -or $quantumBody -notmatch '(?i)Play Mode and development builds' -or $quantumBody -notmatch '(?i)required EventSystem' -or $quantumBody -notmatch '(?i)SRP-compatible prefab/theme' -or $quantumBody -notmatch '(?i)integrate.*activate/deactivate events.*Input System' -or $quantumBody -notmatch '(?i)inspection, validation, tuning, recovery, performance, AI, and multiplayer diagnostics' -or $quantumBody -notmatch '(?i)logging facade') { $technicalPolicyFailures.Add("Quantum Console library dependency or selected optional-console integration is incomplete") | Out-Null }
    if ($technicalText -notmatch '(?i)Player and Developer tabs are freely switchable and are not an authentication boundary' -or $technicalText -notmatch '(?i)testing override is limited to Editor/designated internal builds and never bypasses host/server authority' -or $technicalText -notmatch 'Geurts|Diagnostics Technique') { $technicalPolicyFailures.Add("Diagnostics audience access or restricted testing-override boundary is incomplete") | Out-Null }
    if ($technicalText -notmatch '(?i)Missing dependencies are implementation blockers' -or $technicalText -notmatch '(?i)do not create a fallback inspector, serializer, command console, or parallel diagnostics framework' -or $technicalText -notmatch '(?i)Brick Contract.*identity-and-dependencies' -or $technicalText -match '(?i)Conditional Quantum Console Use|Odin Inspector is already installed') { $technicalPolicyFailures.Add("Required dependency scope, blocker behavior, fallback prohibition, or companion licensed-tool requirement is incomplete") | Out-Null }
    if ($technicalText -notmatch '(?i)Unity Netcode for GameObjects only when it is already installed or selected' -or $technicalText -notmatch '(?i)Do not introduce or install it merely because this technique mentions it') { $technicalPolicyFailures.Add("Netcode for GameObjects is not strictly project-selected") | Out-Null }
    if ($technicalText -notmatch '(?i)Use UI Toolkit for new Geurts UI work' -or $technicalText -notmatch '(?i)Inspect the existing UI before changing it' -or $technicalText -notmatch '(?i)explicit user/project requirements for a scoped integration or migration' -or $technicalText -notmatch '(?i)do not perform a destructive automatic conversion' -or $technicalText -match '(?i)Unity.?s new UI system|new UI system') { $technicalPolicyFailures.Add("UI Toolkit or safe existing-UI migration rule is invalid") | Out-Null }
    if ($technicalText -notmatch '(?i)reusable cross-game Geurts Game Forge framework, library, or tooling component' -or $technicalText -notmatch '(?i)Geurts Game Forge Bricks is a positive example' -or $technicalText -notmatch '(?i)project-specific 2D map generator does not receive this header' -or $technicalText -notmatch '(?i)AI authorship alone is insufficient' -or $technicalText -notmatch '(?i)third-party packages, vendored code, generated code, read-only files' -or $technicalText -notmatch '(?i)format/tooling surface that forbids the header') { $technicalPolicyFailures.Add("compliance-header reusable-framework scope is incomplete") | Out-Null }
    Add-Check "Required technical dependencies and policies" ($technicalPolicyFailures.Count -eq 0) $(if ($technicalPolicyFailures.Count) { $technicalPolicyFailures -join "; " } else { "Odin Inspector and Quantum Console are required and meaningfully used in scoped Geurts implementation; their blocker and independent-companion tooling boundaries, UI Toolkit, optional Netcode, player access, and compliance-header scope are explicit." })


    # Policy consistency complements payload/schema checks: reject contradictions between owners.
    $consistencyFailures = New-Object 'System.Collections.Generic.List[string]'
    $setupText = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsForgeSetupTechnique.md'))
    $setupContract = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsForgeSetupContract.json')) | ConvertFrom-Json
    $diagnosticsText = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsDiagnosticsTechnique.md'))
    $activeReadme = ($readmeStatusText -split '(?m)^## Changelog\r?$', 2)[0]
    if (-not $diagnosticsText.Contains('Ordinary Forge logs are dropped while the provider is unavailable') -or
        -not $diagnosticsText.Contains('Genuine failed operations remain independently visible') -or
        -not $diagnosticsText.Contains('Do not fall back to or mirror Unity logging')) {
        $consistencyFailures.Add('Diagnostics must own no-op logging with independently visible failures') | Out-Null
    }
    foreach ($text in @($technicalText, $appearanceText, $brickContractText, $diagnosticsText)) {
        if ($text -match '(?i)(?:must|should|may)\s+fall\s*back to Unity logging|unavailable-service Unity fallback|final output sink and unavailable-service fallback') {
            $consistencyFailures.Add('Active techniques must not authorize Unity logging fallback') | Out-Null
        }
    }
    if (-not $companionTechniqueText.Contains('Opening the Commandments menu or embedded view stays offline') -or
        $companionTechniqueText -match '(?i)deliberate Commandments Companion menu opening[^\r\n]{0,100}may request') {
        $consistencyFailures.Add('Commandments opening must remain offline with only the existing explicit/consented actions') | Out-Null
    }
    if (-not $setupText.Contains('God owns navigation and shared readiness, not execution of optional project tools') -or
        -not $activeReadme.Contains('Angels owns **Install Codex guide**') -or
        $activeReadme -match '(?i)God[^\r\n]{0,40}owns the separate \*\*Install Codex guide\*\*') {
        $consistencyFailures.Add('Angels must remain the explicit project-tool owner') | Out-Null
    }
    if (-not $setupText.Contains('automatic root guide installation') -or
        -not $setupText.Contains('user may explicitly select the project root') -or
        $setupText.Contains('No Execute All, automatic primary choice, source scan or root guide installation is allowed')) {
        $consistencyFailures.Add('Root guides are permitted only through explicit selected installation') | Out-Null
    }
    if (-not $diagnosticsText.Contains('including completed games') -or
        -not $technicalText.Contains('Installing or enabling a runtime developer console is optional') -or
        $technicalText.Contains('Every gameplay project must include a validated developer-console setup')) {
        $consistencyFailures.Add('Runtime console use must remain optional, separate from required libraries') | Out-Null
    }
    $expectedSetupStatuses = @('unknown', 'available', 'in-progress', 'ready', 'needs-action', 'blocked', 'disabled', 'failed', 'not-applicable')
    if (-not (Test-ExactStringSequence -Actual @($setupContract.statuses) -Expected $expectedSetupStatuses) -or
        [string]$setupContract.schemaVersion -cne '1.0.0' -or
        -not $setupText.Contains('unavailable is an explanation, not an additional status')) {
        $consistencyFailures.Add('Existing setup statuses must be preserved with an actionable unavailable reason') | Out-Null
    }
    foreach ($rule in @('green for verified working/ready', 'orange for needs attention', 'red for an error', 'retain neutral borders and precise text')) {
        if (-not $themeText.Contains($rule)) { $consistencyFailures.Add("Status outline rule missing: $rule") | Out-Null }
    }
    $catalogueRegistry = [regex]::Match($manifestText, '(?m)^\| `GeurtsTechniques/GeurtsBrickCatalogue\.json` \| [^|]+ \| (?<Role>[^|]+) \|\r?$')
    if ($catalogueRegistry.Groups['Role'].Value -match '\b\d+\.\d+\.\d+\b' -or
        -not $manifestText.Contains('single source for current published brick versions')) {
        $consistencyFailures.Add('Current brick versions belong in the catalogue, not parallel prose lists') | Out-Null
    }
    $migrationReferences = @([regex]::Matches($activeReadme, '(?m)^- `(?<Path>Migrations/[^`]+)` -'))
    if (@($migrationReferences | ForEach-Object { $_.Groups['Path'].Value } | Group-Object | Where-Object Count -gt 1).Count -gt 0) {
        $consistencyFailures.Add('README supporting migration references must not be duplicated') | Out-Null
    }
    Add-Check 'Resolved documentation policy consistency' ($consistencyFailures.Count -eq 0) $(if ($consistencyFailures.Count) { $consistencyFailures -join '; ' } else { 'Logging, offline consent, Angels ownership, explicit root guides, optional console, existing statuses, semantic outlines and catalogue-only current versions agree; historical guides and exact payloads retain their boundaries.' })

    $autoSortValid = $setupText.Contains('off by default') -and $setupText.Contains('explicit existing first-party folder below `Assets`') -and
        $setupText.Contains('ownership acknowledgement, string/path-loader review') -and $setupText.Contains('Missing, malformed or mismatched history pauses') -and
        $setupText.Contains('incoming user moves are queued') -and $setupText.Contains('process outside the import callback') -and
        $setupText.Contains('Destination folders must already exist') -and $setupText.Contains('Changed source-folder identity, saved policy or local guidance invalidates automatic consent') -and
        $setupText.Contains('Disabling drops queued work') -and $setupText.Contains('A reviewed first-party scope is not permission to process protected descendants')
    Add-Check 'Automatic import organization boundary' $autoSortValid 'Automatic imports require explicit scoped consent, a retained baseline and deferred guarded moves; protected descendants and existing assets remain excluded.'
    $autoRenameValid = $setupText.Contains('**Automatically rename new imports**, off by default and separate from sorting') -and
        $setupText.Contains('combine both changes into one exact move') -and $setupText.Contains('Preserve compliant names and their agreed categories') -and
        $setupText.Contains('Image and recording purposes default to Skip until chosen') -and $setupText.Contains('string/name/path lookups and external naming contracts') -and
        $setupText.Contains('Include naming guidance and saved rules in stale-consent validation') -and $setupText.Contains('Never overwrite existing assets') -and
        $setupText.Contains('Automatic enablement leaves existing content and reimports unchanged')
    Add-Check 'Automatic import naming boundary' $autoRenameValid 'Naming has separate default-off consent, explicit semantic choices, shared identity ownership, preservation and collision/drift guards.'
    $codexNamingValid = $setupText.Contains('## Optional Codex-assisted import naming') -and
        $setupText.Contains('exactly what content is sent, account usage and automatic application') -and
        $setupText.Contains('No whole-project or supporting-document scan') -and $setupText.Contains('Codex chooses Type, Category and Description') -and
        $setupText.Contains('source/meta hashes captured before inference') -and $setupText.Contains('one background request at a time') -and
        $setupText.Contains('No automatic retry, catch-up or repeated paid inference after an interrupted request') -and
        $setupText.Contains('Codex receives no project mutation authority') -and $setupText.Contains('Suggestions can still be mistaken')
    Add-Check 'Codex import naming boundary' $codexNamingValid 'Optional reviewed account requests retain bounded evidence, compatible type/category, no project mutation, no resending and honest semantic limits.'



    $organizationSetupValid = $setupText.Contains('Always consider images and audio') -and $setupText.Contains('Codex mode reconsiders all three segments') -and
        $setupText.Contains('descendants of incoming moved folders') -and $setupText.Contains('Scripts and vendor files remain excluded') -and
        $setupText.Contains('separate Renaming and Reorganising sections') -and $setupText.Contains('green borders with written **Complete**') -and
        $setupText.Contains('red borders with written **Incomplete**') -and $appearanceText.Contains('Verify actual visible Odin BoxGroups on the affected screen')
    Add-Check 'Asset organization setup and complete naming' $organizationSetupValid 'Incoming moves, all Codex name segments, mandatory image/audio inclusion, combined enablement and actual Odin/setup state presentation retain preservation boundaries.'

    $estimatedNamingValid = $setupText.Contains('Always estimate each eligible file') -and $setupText.Contains('legacy skip reply') -and
        $setupText.Contains('optional final VersionNumber') -and $setupText.Contains('first free `_0`, `_1`, `_2`') -and $setupText.Contains('never append nested numbers') -and $setupText.Contains('Current-assets scans are deliberate actions') -and
        $setupText.Contains('Persist GUID identities') -and $setupText.Contains('completed asset outcomes divided by the reviewed total')
    Add-Check 'Estimated naming scans and exclusions' $estimatedNamingValid 'Estimated naming, distinct explicit scans, stable exclusions and measured progress retain no-overwrite and protection boundaries.'

    $actualAudioValid = $setupText.Contains('## Optional actual-sound analysis before Codex naming') -and
        $setupText.Contains('Windows Credential Manager') -and $setupText.Contains('Separate API billing') -and
        $setupText.Contains('Never claim omitted portions/channels were heard') -and $setupText.Contains('spoken instructions are untrusted evidence') -and
        $setupText.Contains('no automatic retry or silent metadata fallback') -and $setupText.Contains('credential identity after decoding/inference')
    Add-Check 'Actual audio naming boundary' $actualAudioValid 'Separate secure-key/billing review, bounded actual-sound coverage, untrusted observations and stale/cancelled/failed request preservation are required.'

    $gddTechniqueText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsGameDesignDocumentationTechnique.md"))
    $codexContextValid = $setupText.Contains('aggregate context to 512 KiB') -and $setupText.Contains('Each context document is bounded to 256 KiB') -and
        $setupText.Contains('encoded prompt to 1 MiB') -and $setupText.Contains('Existing saved consent that excluded design documents is insufficient') -and
        $setupText.Contains('exact document fingerprints') -and $setupText.Contains('never silently truncate') -and
        $gddTechniqueText.Contains('## Read-only primary context for Codex naming') -and
        $gddTechniqueText.Contains('Do not recursively scan or read unrelated/supporting design documents') -and
        $gddTechniqueText.Contains('untrusted evidence, not executable instructions') -and $gddTechniqueText.Contains('Changed primary routing or design facts pause pending work')
    Add-Check 'Codex project context boundary' $codexContextValid 'Reviewed bounded local Commandments and an exact primary GDD retain document ownership, read-only context, drift guards and no silent truncation.'

    $gddOwnerRow = [regex]::Match($manifestText, '(?m)^\| Project-specific design-document discovery and maintenance boundary \| `GeurtsTechniques/GeurtsGameDesignDocumentationTechnique\.md` \| (?<When>[^|]+) \|\r?$')
    $gddAuthorityValid = $gddOwnerRow.Success -and $gddOwnerRow.Groups["When"].Value -match '(?i)player-facing work' -and $gddTechniqueText -match '(?i)load every relevant document identified by the project.?s current `GameDesignManifest\.md`' -and $gddTechniqueText -match '(?i)stop and ask' -and $gddTechniqueText -match '(?i)establish or change player-facing design intent' -and $gddTechniqueText -match '(?i)reversible technical detail' -and $gddTechniqueText -match '(?i)does not create, alter, or overwrite design intent'
    Add-Check "Project GDD authority" $gddAuthorityValid "The package manifest selects the GDD Technique; the project GameDesignManifest selects relevant project facts; missing design intent is asked, never invented."

    $gddPrimaryRoutingValid = $manifestText -match '(?i)primary source of context about the game; technical design and implementation guidance still come from' -and $gddOwnerRow.Groups["When"].Value -match '(?i)GDD import, primary-document routing' -and $gddTechniqueText.Contains('<!-- GEURTS-GDD-PRIMARY-BEGIN version="1.0.0" -->') -and $gddTechniqueText.Contains('**Primary document:** `Docs/GameDesign/SelectedDocument.md`') -and $gddTechniqueText.Contains('<!-- GEURTS-GDD-PRIMARY-END -->') -and $gddTechniqueText -match '(?i)outside the existing `GEURTS-GDD-MANIFEST-BEGIN` table' -and $gddTechniqueText -match '(?i)primary selection takes precedence over the managed table.s `Authority` field for choosing primary game context only' -and $gddTechniqueText -match '(?i)Technical design and implementation guidance remains authoritative in the manifest-selected techniques' -and $gddTechniqueText -match '(?i)A document does not need a table row' -and $gddTechniqueText -match '(?i)preserves the primary and imported-document sections byte-for-byte' -and $gddTechniqueText -match '(?i)must not retarget the primary pointer' -and $gddTechniqueText -match '(?i)preserve the selected source bytes' -and $gddTechniqueText -match '(?i)without silently overwriting any existing file' -and $gddTechniqueText -match '(?i)Do not scan unrelated design documents or invoke `UpdateGameDesignManifest.ps1`' -and $gddTechniqueText -match '(?i)Duplicate, malformed, unsupported or nested primary markers are conflicts' -and $gddTechniqueText -match '(?i)three project AI-route files' -and $folderTechniqueText -match '(?i)user-selected Angels \*\*Import selected documents\*\* or legacy \*\*Import primary Game Design Document\*\* action may create only missing `Docs/` and `Docs/GameDesign/` parents'
    Add-Check "Primary GDD import routing" $gddPrimaryRoutingValid "Explicit Markdown import selects project game context through an independent primary section, preserves source/table/user bytes, keeps technical authority in Geurts documentation, and does not expand the companion boundary."

    $gddMultipleImportsValid = $gddTechniqueText.Contains('<!-- GEURTS-GDD-IMPORTS-BEGIN version="1.0.0" -->') -and $gddTechniqueText.Contains('<!-- GEURTS-GDD-IMPORTS-END -->') -and $gddTechniqueText.Contains('Preflight every selected document') -and $gddTechniqueText.Contains('Later imports preserve the primary') -and $gddTechniqueText.Contains('unprovided classification and precedence') -and $gddTechniqueText.Contains('No recursive scan is permitted') -and $gddTechniqueText.Contains('Missing or invalid supporting documents remain visible')
    Add-Check "Multiple GDD import routing" $gddMultipleImportsValid "Explicit batches retain one selected primary, register supporting paths without inventing authority, preserve existing content, and do not scan unrelated files."

    $gddOverwriteValid = $gddTechniqueText.Contains('### Manual overwrite warning') -and $gddTechniqueText.Contains('**Cancel** is initially focused') -and $gddTechniqueText.Contains('**Overwrite documents** grants one-time consent') -and $gddTechniqueText.Contains('This consent is never saved') -and $gddTechniqueText.Contains('revalidate every source, destination and the original raw manifest bytes before any batch write') -and $gddTechniqueText.Contains('leaves selected files queued') -and $gddTechniqueText.Contains('without claiming the entire batch was rolled back')
    Add-Check "Manual GDD overwrite consent" $gddOverwriteValid "Only one-time explicit consent permits replacing named changed documents; cancellation is write-free, concurrent edits are preserved and partial failures report retained changes."

    $destructiveWarningValid = $gfiTechniqueText -match '(?i)destructive confirmation whose safe default is Cancel' -and $gfiTechniqueText -match '(?i)before any acquisition or project mutation begins' -and $gfiTechniqueText -match '(?i)Every local edit anywhere inside GeurtsGameForgeDocumentation will be overwritten and lost' -and $gfiTechniqueText -match '(?i)Project-authored Docs/GameDesign content and every other project file will remain untouched' -and $gfiTechniqueText -match '(?i)update has no rollback' -and $gfiTechniqueText -match '(?is)fails or is interrupted.{0,200}missing or incomplete' -and $gfiTechniqueText -match '(?i)Cancel must be the initially focused and default response' -and $gfiTechniqueText -match '(?i)Dismissing the warning, pressing Escape, closing the window[^\r\n]{0,160}no filesystem or network change'
    Add-Check "Frozen GFI v2 destructive warning" $destructiveWarningValid "The frozen released-consumer contract retains its cancel-default destructive-warning requirements."

    $manualUpdateSection = [regex]::Match($gfiTechniqueText, '(?ms)^## 4\. Explicit Manual Update\s*(?<Body>.*?)(?=^## 5\.)')
    $manualUpdateBody = if ($manualUpdateSection.Success) { $manualUpdateSection.Groups["Body"].Value } else { "" }
    $acquirePosition = $manualUpdateBody.IndexOf("Download or otherwise acquire", [System.StringComparison]::Ordinal)
    $validatePosition = $manualUpdateBody.IndexOf("Perform proportionate validation before deletion", [System.StringComparison]::Ordinal)
    $invalidateReceiptPosition = $manualUpdateBody.IndexOf("Immediately before the first destructive mutation of the live destination", [System.StringComparison]::Ordinal)
    $deletePosition = $manualUpdateBody.IndexOf('Delete the existing `<ProjectRoot>/GeurtsGameForgeDocumentation/`', [System.StringComparison]::Ordinal)
    $materializePosition = $manualUpdateBody.IndexOf("Materialize the validated complete tree", [System.StringComparison]::Ordinal)
    $writeReceiptPosition = $manualUpdateBody.IndexOf("Only then write a new current installed receipt", [System.StringComparison]::Ordinal)
    $cleanupPosition = $manualUpdateBody.IndexOf("Attempt to remove ephemeral acquisition residue", [System.StringComparison]::Ordinal)
    $replacementOrderValid = $acquirePosition -ge 0 -and $validatePosition -gt $acquirePosition -and $invalidateReceiptPosition -gt $validatePosition -and $deletePosition -gt $invalidateReceiptPosition -and $materializePosition -gt $deletePosition -and $writeReceiptPosition -gt $materializePosition -and $cleanupPosition -gt $writeReceiptPosition
    $completeReplacementValid = $manualUpdateSection.Success -and $replacementOrderValid -and $gfiTechniqueText -match '(?i)resolves the current head of `main`, captures that authoritative selected commit ID' -and $gfiTechniqueText -match '(?i)complete Git-tracked source tree' -and $gfiTechniqueText -match '(?i)selected Git tree[^\r\n]{0,120}defines the content set' -and $gfiTechniqueText -match '(?i)Preserve the tracked file bytes' -and $gfiTechniqueText -match '(?i)Reject unsafe paths, unsupported tracked object types, or an invalid package before deleting' -and $gfiTechniqueText -match '(?i)ephemeral location outside the live destination' -and $gfiTechniqueText -match '(?i)detached, writable content snapshot' -and $gfiTechniqueText -match '(?i)contains no `\.git` directory or file and no other Git metadata' -and $gfiTechniqueText -match '(?i)no repository, worktree, branch, remote, or continuing connection' -and $gfiTechniqueText -match '(?i)read-only file or directory attributes must be cleared' -and $gfiTechniqueText -match '(?i)cleanup failure or leftover ephemeral residue must never block a later' -and $gfiTechniqueText -match '(?i)best-effort basis'
    Add-Check "Frozen GFI v2 complete-tree replacement" $completeReplacementValid "The frozen released-consumer contract retains its internally coherent validated complete-tree replacement sequence."

    $receiptContradiction = $activeGfiContractSurfaceText -match '(?i)(?:historical|prior|former|older) receipt[^\r\n]{0,120}(?:may|can)\s+(?:continue to\s+)?(?:drive|supply|determine)' -or $activeGfiContractSurfaceText -match '(?i)package[- ]version(?: ordering| equality| inequality)?\s+(?:alone\s+)?(?:determines|may determine|can determine)[^\r\n]{0,120}(?:availability|Update is available)' -or $activeGfiContractSurfaceText -match '(?i)current installed receipt[^\r\n]{0,100}(?:retained|remains valid|kept)[^\r\n]{0,100}(?:through|after)[^\r\n]{0,60}(?:deletion|destructive mutation)' -or $activeGfiContractSurfaceText -match '(?i)(?:write|record)[^\r\n]{0,80}(?:new )?(?:current installed )?receipt[^\r\n]{0,100}before[^\r\n]{0,80}(?:copy|update).*(?:complete|success)'
    $receiptLifecycleValid = $replacementOrderValid -and $gfiTechniqueText -match '(?i)Every successful Update receipt records the authoritative selected commit ID' -and $gfiTechniqueText -match '(?i)also records the authoritative package version when the selected package exposes a valid version' -and $gfiTechniqueText -match '(?i)commit ID is the comparison baseline; the package version is display metadata' -and $gfiTechniqueText -match '(?i)historical receipt is diagnostic history only and must never drive the installed label or availability comparison' -and $gfiTechniqueText -match '(?i)report success only after that receipt is written' -and $gfiTechniqueText -match '(?i)Failure before receipt invalidation leaves the existing live copy and its current receipt unchanged' -and $gfiTechniqueText -match '(?i)Failure or interruption after receipt invalidation must leave the current receipt absent or invalid' -and $gfiTechniqueText -match '(?is)exact destination directory is absent.{0,160}UI shows `Not installed`.{0,200}directory exists there but the new copy did not complete successfully.{0,160}UI shows `Unknown`' -and $gfiTechniqueText -match '(?i)Do not restore or reuse a historical receipt' -and $gfiMigrationText -match '(?i)Immediately before destructive live deletion, it invalidates the current installed receipt' -and $gfiMigrationText -match '(?i)historical receipt must never drive the installed label or availability comparison afterward' -and $gfiMigrationText -match '(?i)new receipt is written only after complete success' -and -not $receiptContradiction
    Add-Check "Frozen GFI v2 receipt lifecycle" $receiptLifecycleValid "The frozen released-consumer contract retains its internally coherent commit-identity and current-receipt lifecycle."

    $aiBoundaryDelegates = $aiReadFirstText.Contains("<ProjectRoot>/GeurtsGameForgeCommandments/") -and $aiReadFirstText.Contains("<ProjectRoot>/Docs/GameDesign/") -and $aiReadFirstText -match '(?i)(?:membership|integration lifecycle)[^\r\n]{0,100}outside this router.?s subject' -and $aiReadFirstText -match '(?i)manifest selects the applicable owner'
    $folderBoundaryDelegates = $folderTechniqueTextForPathTerms -match '(?i)placement boundary for a detached, writable project-local fetched copy' -and $folderTechniqueTextForPathTerms -match '(?i)folder-structure tool has no creation, replacement, or lifecycle authority' -and $folderTechniqueTextForPathTerms -match '(?i)manifest-selected integration technique owns the explicit manual Update boundary'
    $strictOverwriteBoundaryValid = $gfiTechniqueText -match '(?i)only project path this documentation Update may delete or replace' -and $gfiTechniqueText -match '(?i)Every file and byte there, and every other project file outside `<ProjectRoot>/GeurtsGameForgeDocumentation/`, must remain untouched' -and $gfiTechniqueText -match '(?i)documentation Update changes only `<ProjectRoot>/GeurtsGameForgeDocumentation/`' -and $gfiTechniqueText -match '(?i)must not invoke native-entry setup, GDD scaffolding, GDD manifest maintenance, folder creation, or `\.gitignore` provisioning' -and $gfiTechniqueText -match '(?i)must not invent project-specific GDD facts' -and $gfiTechniqueText -match '(?i)overwrite project-authored GDD' -and $gfiTechniqueText -match '(?i)silently overwrite user-authored native entries' -and $gfiTechniqueText -match '(?i)alter a differing project-root `\.gitignore`' -and $activeGfiContractSurfaceText -notmatch '(?i)(?:may|must|shall|will)\s+(?:also\s+)?(?:delete(?:\s+and\s+replace)?|replace|overwrite)\s+(?:the\s+)?(?:project-authored\s+)?`?(?:<ProjectRoot>/)?Docs/GameDesign'
    Add-Check "Frozen GFI v2 overwrite boundary" $strictOverwriteBoundaryValid "The frozen released-consumer contract remains bounded to its historical GeurtsGameForgeCommandments-only replacement and never touches Docs/GameDesign."

    $requiredDiscardedTerms = @(
        "automatic documentation downloader or installer",
        "startup check that downloads or inspects local documentation",
        "activation transaction",
        "activation snapshot",
        "rollback system",
        "durable recovery journal",
        "recovery gate",
        "cleanup quarantine",
        "reset-recovery flow",
        "last-valid-copy mechanism",
        "local-drift preservation or override flow",
        "reintegration state machine",
        "backup/recovery state that blocks an update",
        "plugin-managed legacy installer migration"
    )
    $missingDiscardedTerms = @($requiredDiscardedTerms | Where-Object { $gfiTechniqueText.IndexOf($_, [System.StringComparison]::OrdinalIgnoreCase) -lt 0 })
    $activeGfiSurfaceText = $activeGfiContractSurfaceText
    $obsoleteAffirmativePhrases = @(
        "exactly one routine remote documentation check per Unity project launch or open",
        "acquire and stage an exact complete-tree candidate",
        "promote the candidate atomically",
        "combined rollback",
        "retain the validated candidate and last-valid evidence",
        "category/status=REINTEGRATION",
        "rerun integration reconciliation",
        "recognized prior package version may be migrated only through the plugin-owned transaction",
        '`contractFingerprint`'
    )
    $presentObsoleteAffirmative = @($obsoleteAffirmativePhrases | Where-Object { $activeGfiSurfaceText.IndexOf($_, [System.StringComparison]::OrdinalIgnoreCase) -ge 0 })
    $legacyEvidenceValid = $gfiTechniqueText.Contains("<ProjectRoot>/Library/GameForgeIntelligence/") -and $gfiTechniqueText -match '(?i)outside compatibility schema 2\.0\.0' -and $gfiTechniqueText -match '(?i)must not consult it, depend on it, or allow it to block documentation use or replacement' -and $gfiTechniqueText -match '(?i)leaves that legacy evidence untouched' -and $gfiTechniqueText -match '(?i)future cleanup requires a separate explicit operation and authority'
    $discardedLifecycleValid = $missingDiscardedTerms.Count -eq 0 -and $presentObsoleteAffirmative.Count -eq 0 -and $gfiTechniqueText -match '(?i)Do not recreate any of those mechanisms under different terminology' -and $legacyEvidenceValid
    Add-Check "Frozen GFI v2 discarded lifecycle exclusion" $discardedLifecycleValid $(if ($missingDiscardedTerms.Count) { "Missing explicit lifecycle exclusions: " + ($missingDiscardedTerms -join ", ") } elseif ($presentObsoleteAffirmative.Count) { "Obsolete affirmative lifecycle language reintroduced: " + ($presentObsoleteAffirmative -join ", ") } else { "The frozen v2 contract forbids its older automatic transaction/recovery system and leaves legacy Library evidence untouched and non-blocking." })

    $draftStatusValid = @(
        @{ Path = "GeurtsTechniques/GeurtsFolderStructureTechnique.md"; Registry = '(?m)^\| `GeurtsTechniques/GeurtsFolderStructureTechnique\.md` \| 0\.16\.6 \| Normative ' },
        @{ Path = "GeurtsTechniques/GeurtsGameDesignDocumentationTechnique.md"; Registry = '(?m)^\| `GeurtsTechniques/GeurtsGameDesignDocumentationTechnique\.md` \| 0\.16\.2 \| Normative ' },
        @{ Path = "GeurtsTechniques/GeurtsCommandmentsCompanionTechnique.md"; Registry = '(?m)^\| `GeurtsTechniques/GeurtsCommandmentsCompanionTechnique\.md` \| 3\.2\.5 \| Normative ' }
    ) | ForEach-Object { ([System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $_.Path)) -match '(?im)^\*\*Status:\*\* Draft normative technique\s*$') -and ($manifestText -match $_.Registry) } | Where-Object { -not $_ } | Measure-Object | Select-Object -ExpandProperty Count
    Add-Check "Normative status and registry roles" ($draftStatusValid -eq 0) "Folder, GDD, and Commandments Companion techniques consistently declare Draft normative status and normative manifest roles."

    $managerText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/ManageGeurtsAgentInstructions.ps1"))
    $managerSafetyMissing = @("Test-HasReparsePoint", "Test-NativeMigrationCatalog", "native-entry", "gdd-scaffolding", "IncludeGameDesignScaffolding", "UpdateGameDesignManifest", "frontmatter delimiters", "unsupported version", "no downgrade", "GEURTS-MANAGED-OPT-OUT", ".pre-v0.9.0.bak", "Read-ManagedTextFile", "Unsupported UTF-32 encoding", "UnicodeEncoding", "UTF8Encoding", "Get-ByteHash", "Get-FileByteHash", "ExpectedState", "ExpectedByteHash", "Convert-Newlines", "Get-NewlineConvention", "Target bytes changed after they were read", "Target appeared after preflight", ".ggf-backup-", "Backup target appeared after preflight") | Where-Object { $managerText.IndexOf($_, [System.StringComparison]::OrdinalIgnoreCase) -lt 0 } | Measure-Object | Select-Object -ExpandProperty Count
    $catalogText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/NativeEntryMigrationCatalog.json"))
    $managerScopeValid = $managerText -notmatch '(?i)SkipGameDesignManifestUpdate' -and $catalogText -notmatch '(?i)knownWholeFileSha256|beginMarker|endMarker'
    $managerWriterMatch = [regex]::Match($managerText, '(?ms)^function Write-AtomicText\(.*?^}\r?$')
    $managerWriterText = if ($managerWriterMatch.Success) { $managerWriterMatch.Value } else { "" }
    $managerWriterBarrier = $managerWriterText.IndexOf("Invoke-TestWriteBarrier", [System.StringComparison]::Ordinal)
    $managerWriterContainment = if ($managerWriterBarrier -ge 0) { $managerWriterText.IndexOf("Test-IsContainedPath", $managerWriterBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerWriterReparse = if ($managerWriterBarrier -ge 0) { $managerWriterText.IndexOf("Test-HasReparsePoint", $managerWriterBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerWriterState = $managerWriterText.IndexOf('if ($ExpectedState', [System.StringComparison]::Ordinal)
    $managerWriterMove = $managerWriterText.IndexOf("[System.IO.File]::Move", [System.StringComparison]::Ordinal)
    $managerWriterHash = $managerWriterText.IndexOf("Get-FileByteHash", [System.StringComparison]::Ordinal)
    $managerWriterReplace = $managerWriterText.IndexOf("[System.IO.File]::Replace", [System.StringComparison]::Ordinal)
    $managerWriterOrderValid = $managerWriterBarrier -ge 0 -and $managerWriterContainment -gt $managerWriterBarrier -and $managerWriterReparse -ge $managerWriterContainment -and $managerWriterState -gt $managerWriterReparse -and $managerWriterMove -gt $managerWriterState -and $managerWriterHash -gt $managerWriterState -and $managerWriterReplace -gt $managerWriterHash -and $managerWriterText.Contains('Join-Path $AllowedRoot') -and $managerWriterText.Contains('$parentIsRootOrContained') -and $managerWriterText.Contains('Atomic target parent must already exist safely below the validated project root') -and $managerWriterText.IndexOf('New-Item', [System.StringComparison]::OrdinalIgnoreCase) -lt 0
    $managerBackupMatch = [regex]::Match($managerText, '(?ms)^function New-Backup\(.*?^}\r?$')
    $managerBackupText = if ($managerBackupMatch.Success) { $managerBackupMatch.Value } else { "" }
    $managerBackupCapture = $managerBackupText.IndexOf("[System.IO.File]::Copy", [System.StringComparison]::Ordinal)
    $managerBackupBarrier = $managerBackupText.IndexOf("Invoke-TestWriteBarrier", [System.StringComparison]::Ordinal)
    $managerBackupContainment = if ($managerBackupBarrier -ge 0) { $managerBackupText.IndexOf("Test-IsContainedPath", $managerBackupBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerBackupReparse = if ($managerBackupBarrier -ge 0) { $managerBackupText.IndexOf("Test-HasReparsePoint", $managerBackupBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerBackupHash = if ($managerBackupBarrier -ge 0) { $managerBackupText.IndexOf("Get-FileByteHash", $managerBackupBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerBackupAbsent = if ($managerBackupBarrier -ge 0) { $managerBackupText.IndexOf('Test-Path -LiteralPath $finalBackup', $managerBackupBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerBackupMove = if ($managerBackupBarrier -ge 0) { $managerBackupText.IndexOf("[System.IO.File]::Move", $managerBackupBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerBackupOrderValid = $managerBackupText.Contains('Join-Path $root') -and $managerBackupCapture -ge 0 -and $managerBackupBarrier -gt $managerBackupCapture -and $managerBackupContainment -gt $managerBackupBarrier -and $managerBackupReparse -ge $managerBackupContainment -and $managerBackupHash -gt $managerBackupReparse -and $managerBackupAbsent -gt $managerBackupHash -and $managerBackupMove -gt $managerBackupAbsent
    $managerDirectoryBarrier = $managerText.IndexOf('Invoke-TestWriteBarrier -TargetPath $directory.Path', [System.StringComparison]::Ordinal)
    $managerDirectoryContainment = if ($managerDirectoryBarrier -ge 0) { $managerText.IndexOf('Test-IsContainedPath -Candidate $finalDirectoryPath', $managerDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerDirectoryReparse = if ($managerDirectoryBarrier -ge 0) { $managerText.IndexOf('Test-HasReparsePoint -Candidate $finalDirectoryPath', $managerDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerDirectoryAcceptance = if ($managerDirectoryBarrier -ge 0) { $managerText.IndexOf('Test-Path -LiteralPath $finalDirectoryPath -PathType Container', $managerDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerDirectoryCreate = if ($managerDirectoryBarrier -ge 0) { $managerText.IndexOf('New-Item -ItemType Directory -Path $finalDirectoryPath', $managerDirectoryBarrier, [System.StringComparison]::Ordinal) } else { -1 }
    $managerDirectoryOrderValid = $managerDirectoryBarrier -ge 0 -and $managerDirectoryContainment -gt $managerDirectoryBarrier -and $managerDirectoryReparse -ge $managerDirectoryContainment -and $managerDirectoryAcceptance -gt $managerDirectoryReparse -and $managerDirectoryCreate -gt $managerDirectoryAcceptance
    $setupTechniqueText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "GeurtsTechniques/GeurtsAIAgentSetupTechnique.md"))
    $managerOwnerSafetyValid = $setupTechniqueText -match '(?i)preserve bytes outside the managed region' -and $setupTechniqueText -match '(?i)UTF-8, UTF-8-BOM, UTF-16LE-BOM, or UTF-16BE-BOM' -and $setupTechniqueText -match '(?i)reject invalid text and UTF-32 without mutation' -and $setupTechniqueText -match '(?i)target managed region.?s newline convention' -and $setupTechniqueText -match '(?i)explicit expected target state.*absent.*exact raw-byte fingerprint' -and $setupTechniqueText -match '(?i)Immediately before promotion.*revalidates containment.*complete path chain.*reparse points' -and $setupTechniqueText -match '(?i)unexpected file or any byte drift.*conflict' -and $setupTechniqueText -match '(?i)backup does not authorize replacing concurrent user content' -and $setupTechniqueText -match '(?i)Before promoting an adjacent safety backup.*revalidates source and backup containment' -and $setupTechniqueText -match '(?i)both complete path chains.*expected raw-byte fingerprint.*expected absence' -and $setupTechniqueText -match '(?i)failed backup guard preserves the target and promotes no backup' -and $setupTechniqueText -match '(?i)final containment and full-chain reparse check applies immediately before.*accepts an existing delegated setup directory or creates a missing one'
    Add-Check "Native-entry safety contract" ($managerSafetyMissing -eq 0 -and $managerScopeValid -and $managerWriterOrderValid -and $managerBackupOrderValid -and $managerDirectoryOrderValid -and $managerOwnerSafetyValid) "Native entries use strict supported encodings, exact outside bytes, target-region newlines, byte-CAS expected state, root-owned write/backup artifacts, and final file/backup/directory containment plus reparse guards; backups never authorize overwrite."

    $explicitRootFailures = New-Object System.Collections.Generic.List[string]
    foreach ($relative in @("Tools/CreateGeurtsFolderStructure.ps1", "Tools/ManageGeurtsAgentInstructions.ps1", "Tools/UpdateGameDesignManifest.ps1")) {
        $toolText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative))
        $commonRootGuardInvalid = $toolText.IndexOf("ProjectRoot is required", [System.StringComparison]::OrdinalIgnoreCase) -lt 0 -or @(@("Assets", "Packages", "ProjectSettings") | Where-Object { $toolText.IndexOf($_, [System.StringComparison]::Ordinal) -lt 0 }).Count -gt 0 -or $toolText.IndexOf('$ProjectRoot = Split-Path -Parent $PSScriptRoot', [System.StringComparison]::Ordinal) -ge 0
        $containerGuardInvalid = $toolText.IndexOf("Assert-UnityProjectRoot", [System.StringComparison]::Ordinal) -lt 0 -or $toolText.IndexOf("documentation source or project-local fetched documentation copy", [System.StringComparison]::OrdinalIgnoreCase) -lt 0
        if ($commonRootGuardInvalid -or $containerGuardInvalid) {
            $explicitRootFailures.Add($relative) | Out-Null
        }
    }
    foreach ($relative in @("Tools/CreateAIAgentInstructionFiles.bat", "Tools/CreateGeurtsFolderStructure.bat")) {
        $launcherText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot $relative))
        if ($launcherText -notmatch '(?im)^rem Version: 0\.9\.0\s*$' -or $launcherText -notmatch '(?i)if /I not "%~1"=="-ProjectRoot"' -or $launcherText -notmatch '(?i)-ProjectRoot requires a Unity project path') { $explicitRootFailures.Add($relative) | Out-Null }
    }
    Add-Check "Explicit Unity project roots" ($explicitRootFailures.Count -eq 0) $(if ($explicitRootFailures.Count) { "Unsafe or ambiguous project-root handling: " + ($explicitRootFailures -join ", ") } else { "All project-mutating PowerShell tools and launchers require an explicit Unity root with Assets, Packages, and ProjectSettings; none derives it from the copied Tools location." })

    $usageFailures = New-Object System.Collections.Generic.List[string]
    $usageDocuments = @("README.md", "AI_READ_FIRST.md", "GeurtsTechniqueManifest.md", "Migrations/v0.11.0.md")
    $usageDocuments += @(Get-ChildItem -LiteralPath (Join-Path $RepositoryRoot "GeurtsTechniques") -Filter "*.md" -File | ForEach-Object { "GeurtsTechniques/" + $_.Name })
    $toolInvocationPattern = '(?i)(?:powershell|pwsh|\.bat).*?(?:ManageGeurtsAgentInstructions|CreateGeurtsFolderStructure|UpdateGameDesignManifest|CreateAIAgentInstructionFiles)'
    foreach ($relative in $usageDocuments) {
        $lineNumber = 0
        foreach ($line in [System.IO.File]::ReadAllLines((Join-Path $RepositoryRoot $relative))) {
            $lineNumber++
            if ($line -match $toolInvocationPattern -and $line.IndexOf("-ProjectRoot", [System.StringComparison]::OrdinalIgnoreCase) -lt 0) { $usageFailures.Add("$relative`:$lineNumber omits explicit -ProjectRoot") | Out-Null }
        }
    }
    $readmeText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "README.md"))
    $batchText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/CreateAIAgentInstructionFiles.bat"))
    foreach ($surface in @($setupTechniqueText, $readmeText)) {
        if ($surface.IndexOf("-IncludeGameDesignScaffolding", [System.StringComparison]::Ordinal) -lt 0 -or $surface.IndexOf("-UpdateGameDesignManifest", [System.StringComparison]::Ordinal) -lt 0 -or $surface -notmatch '(?i)(?:native-entry|native entries|manual manager|legacy manager).*?(?:does not implicitly create|never creates|handles native entries only|changes native entries only).*?Docs/GameDesign') { $usageFailures.Add("manager scope is not documented as native-only with two positive GDD opt-ins") | Out-Null }
    }
    if ($managerText.IndexOf("[switch]`$IncludeGameDesignScaffolding", [System.StringComparison]::Ordinal) -lt 0 -or $managerText.IndexOf("[switch]`$UpdateGameDesignManifest", [System.StringComparison]::Ordinal) -lt 0 -or $batchText.IndexOf("-IncludeGameDesignScaffolding", [System.StringComparison]::Ordinal) -lt 0 -or $batchText.IndexOf("-UpdateGameDesignManifest", [System.StringComparison]::Ordinal) -lt 0) { $usageFailures.Add("manager or launcher does not expose both positive GDD opt-ins") | Out-Null }
    Add-Check "Tool invocation and scope documentation" ($usageFailures.Count -eq 0) $(if ($usageFailures.Count) { $usageFailures -join "; " } else { "Every current/v0.11 manual-tool example passes explicit -ProjectRoot; native-only default, create-missing GDD scaffolding, and independent manifest maintenance match the CLI." })

    $gddToolText = [System.IO.File]::ReadAllText((Join-Path $RepositoryRoot "Tools/UpdateGameDesignManifest.ps1"))
    $gddSafetyMissing = @("Get-SafeDesignFiles", "Test-HasReparsePoint", "lockOwned", "Get-ExistingEntries", "Get-OrdinalSortedEntries", "required project path", "Manifest bytes changed after they were read", "no downgrade", "invalid version", "Read-ManagedTextFile", "Unsupported UTF-32 encoding", "UnicodeEncoding", "UTF8Encoding", "ByteHash", "ExpectedState", "ExpectedByteHash", "Invoke-TestWriteBarrier", "FileMode]::CreateNew", "FileOptions]::DeleteOnClose") | Where-Object { $gddToolText.IndexOf($_, [System.StringComparison]::OrdinalIgnoreCase) -lt 0 } | Measure-Object | Select-Object -ExpandProperty Count
    $gddWriterMatch = [regex]::Match($gddToolText, '(?ms)^function Write-AtomicText\(.*?^}\r?$')
    $gddWriterText = if ($gddWriterMatch.Success) { $gddWriterMatch.Value } else { "" }
    $gddWriterBarrier = $gddWriterText.IndexOf("Invoke-TestWriteBarrier", [System.StringComparison]::Ordinal)
    $gddWriterContainment = $gddWriterText.IndexOf("Test-IsContainedPath", [System.StringComparison]::Ordinal)
    $gddWriterReparse = $gddWriterText.IndexOf("Test-HasReparsePoint", [System.StringComparison]::Ordinal)
    $gddWriterState = $gddWriterText.IndexOf('if ($ExpectedState', [System.StringComparison]::Ordinal)
    $gddWriterMove = $gddWriterText.IndexOf("[System.IO.File]::Move", [System.StringComparison]::Ordinal)
    $gddWriterHash = $gddWriterText.IndexOf("Get-FileSha256", [System.StringComparison]::Ordinal)
    $gddWriterReplace = $gddWriterText.IndexOf("[System.IO.File]::Replace", [System.StringComparison]::Ordinal)
    $gddWriterOrderValid = $gddWriterBarrier -ge 0 -and $gddWriterContainment -gt $gddWriterBarrier -and $gddWriterReparse -ge $gddWriterContainment -and $gddWriterState -gt $gddWriterReparse -and $gddWriterMove -gt $gddWriterState -and $gddWriterHash -gt $gddWriterState -and $gddWriterReplace -gt $gddWriterHash -and $gddWriterText.Contains('Join-Path $AllowedRoot')
    $gddOwnerSafetyValid = $gddTechniqueText -match '(?i)preserving the exact bytes outside' -and $gddTechniqueText -match '(?i)UTF-8, UTF-8-BOM, UTF-16LE-BOM, or UTF-16BE-BOM' -and $gddTechniqueText -match '(?i)reject invalid text or UTF-32 without mutation' -and $gddTechniqueText -match '(?i)create-new, handle-owned delete-on-close semantics' -and $gddTechniqueText -match '(?i)pre-existing lock path.*conflict.*preserve its exact bytes' -and $gddTechniqueText -match '(?i)remove only the lock represented by its acquired handle' -and $gddTechniqueText -match '(?i)raw-byte fingerprint captured at read time' -and $gddTechniqueText -match '(?i)immediately before atomic promotion.*revalidate containment and the full path chain' -and $gddTechniqueText -match '(?i)reject any existence or byte drift instead of overwriting concurrent content'
    $gddRootArtifactsValid = $gddToolText.Contains('Join-Path $ProjectRoot ".ggf-manifest.lock"') -and $gddToolText.Contains('[System.IO.FileMode]::CreateNew') -and $gddToolText.Contains('[System.IO.FileOptions]::DeleteOnClose') -and $gddToolText -notmatch '\[System\.IO\.FileMode\]::OpenOrCreate' -and $gddToolText -notmatch 'Join-Path\s+\$designRoot\s+"\.ggf-manifest\.lock"' -and $gddWriterText.Contains('Join-Path $AllowedRoot')
    Add-Check "GDD maintenance safety contract" ($gddSafetyMissing -eq 0 -and $gddWriterOrderValid -and $gddOwnerSafetyValid -and $gddRootArtifactsValid) "GDD maintenance preserves supported encoding and exact outside bytes, rejects invalid/UTF-32 input, uses raw-byte expected-state protection, keeps ephemeral artifacts at ProjectRoot, and rechecks containment/reparse paths immediately before promotion."

    # Selected review resolutions are required in their sole current subject owners.
    $readme = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'README.md'))
    Add-Check 'Complete installation guide' ($readme.Contains('### BigBang installation') -and $readme.Contains('### Manual installation') -and $readme.Contains('Install **Steamworks.NET**') -and $readme.Contains('exact current catalogue source') -and -not $readme.Contains('passive 0.15.1 adapter')) 'Both installation routes include prerequisites, exact sources and the current passive-adapter handoff.'
    Add-Check 'Explicit update troubleshooting' ($companionTechniqueText.Contains('HTTP 403/429') -and $companionTechniqueText.Contains('potentially incomplete or mixed') -and $companionTechniqueText.Contains('new explicit action') -and $companionTechniqueText.Contains('Troubleshooting adds no network request')) 'Rate limits, offline/access failures and partial replacement retain the explicit consent and failure boundaries.'
    $brickRules = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsBrickContract.md'))
    Add-Check 'Damaged settings preservation' ($brickRules.Contains('Preserve the original bytes') -and $brickRules.Contains('stop the affected configuration-dependent action') -and $brickRules.Contains('must never be treated as missing') -and $brickRules.Contains('For manual repair/reset') -and $brickRules.Contains('unsupported format')) 'Invalid module settings are preserved with scoped manual repair/reset and no silent defaults or conversion.'
    Add-Check 'Capability graph and Editor exposure gate' ($brickRules.Contains('Every feature action reference must resolve to exactly one root operation') -and $brickRules.Contains('without executing them') -and $brickRules.Contains('EveryInstalledDeclarationMatchesRealOwnerOperations') -and $brickRules.Contains('confirmation flags')) 'Release shape/graph checks and real discovered Editor action parity remain distinct from execution/runtime readiness.'
    $networkRules = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsMultiplayerTechnique.md'))
    Add-Check 'Multiplayer fault acceptance' ($networkRules.Contains('latency/jitter/loss') -and $networkRules.Contains('disconnect/reconnect') -and $networkRules.Contains('invalid or unauthorized requests') -and $networkRules.Contains('budgets chosen') -and $networkRules.Contains('cannot pass the affected release gate')) 'Relevant multiplayer failures and project-specific network budgets require measured evidence.'
    $aiRules = [IO.File]::ReadAllText((Join-Path $RepositoryRoot 'GeurtsTechniques/GeurtsGameAITechnique.md'))
    Add-Check 'Repeatable game AI measurements' ($aiRules.Contains('warm-up') -and $aiRules.Contains('repeated runs') -and $aiRules.Contains('Compare the same workload before and after') -and $aiRules.Contains('project requirements') -and $aiRules.Contains('blocks the affected release')) 'Game-agent performance uses repeatable player workloads, actual budgets and truthful unverified coverage.'

    if ($PSBoundParameters.ContainsKey('SourceRepositories')) {
        $sourceScript = Join-Path $RepositoryRoot 'Tools/ValidateGeurtsBrickSources.ps1'
        $publishedSources = & $sourceScript -RepositoryRoot $RepositoryRoot -SourceRepositories $SourceRepositories -OutputFormat Json | ConvertFrom-Json
        $sourceExitCode = $LASTEXITCODE
        Add-Check 'Published package source parity' ($sourceExitCode -eq 0 -and $publishedSources.status -ceq 'VALID') $(if ($publishedSources.failures.Count) { $publishedSources.failures -join '; ' } else { "Verified $($publishedSources.checks.Count) pinned package/capability manifests and required Forge dependencies." })
    }

    if ($RunAutomationTests) {
        $testScript = Join-Path $RepositoryRoot "Tools/Tests/RunAutomationTests.ps1"
        $hostPath = (Get-Process -Id $PID).Path
        $testArguments = @("-NoProfile", "-File", $testScript, "-RepositoryRoot", $RepositoryRoot)
        if ($OutputFormat -eq "Json") { $testArguments += @("-OutputFormat", "Json") }
        $testOutput = @(& $hostPath @testArguments 2>&1)
        $testExitCode = $LASTEXITCODE
        if ($OutputFormat -eq "Text") {
            foreach ($line in $testOutput) { Write-Host ([string]$line) }
        }
        else {
            try { $automationTests = ($testOutput -join [Environment]::NewLine) | ConvertFrom-Json }
            catch {
                $automationTests = [pscustomobject]@{ status = "INVALID_OUTPUT"; exitCode = $testExitCode }
                $testExitCode = 1
            }
        }
        Add-Check "Automation test suite" ($testExitCode -eq 0) "Automation tests exited with code $testExitCode."
    }

    $passed = $failures.Count -eq 0
    if ($OutputFormat -eq "Json") {
        [pscustomobject]@{ status = $(if ($passed) { "VALID" } else { "INVALID" }); checks = $checks.ToArray(); failures = $failures.ToArray(); automationTests = $automationTests; publishedSources = $publishedSources } | ConvertTo-Json -Depth 9
    }
    if ($passed) { exit 0 }
    exit 1
}
catch {
    if ($OutputFormat -eq "Json") { [pscustomobject]@{ status = "FAILED"; message = $_.Exception.Message; checks = $checks.ToArray(); automationTests = $automationTests; publishedSources = $publishedSources } | ConvertTo-Json -Depth 9 }
    else { Write-Host "VALIDATION FAILED: $($_.Exception.Message)" -ForegroundColor Red }
    exit 1
}
