@echo off
setlocal DisableDelayedExpansion
title Geurts StandardsOnly Installer 1.0.0
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0InstallStandardsOnly.ps1" -ProjectRoot "%~1"
set "InstallResult=%ERRORLEVEL%"
echo.
pause
exit /b %InstallResult%
