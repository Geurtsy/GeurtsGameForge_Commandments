# Installer version: 1.0.0; Windows PowerShell 5.1 or later.
[CmdletBinding()]
param([string]$ProjectRoot, [switch]$ConfirmInstall)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$sourceCommit = '6f1454494e5f773633c2107154d3527fae9e8b15'
$documentationVersion = '0.61.1'
$utf8 = New-Object Text.UTF8Encoding($false, $true)
$staging = $null

function Assert-PlainPath([string]$Path) {
    $full = [IO.Path]::GetFullPath($Path)
    if ($full.Length -ge 260) { throw "Path is too long ($($full.Length) characters): $full. Use a shorter project/extraction location." }
    $cursor = $full
    while ($cursor) {
        if (Test-Path -LiteralPath $cursor) {
            $item = Get-Item -LiteralPath $cursor -Force
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { throw "Linked paths are not supported: $cursor" }
        }
        $parent = [IO.Path]::GetDirectoryName($cursor)
        if ($parent -eq $cursor) { break }
        $cursor = $parent
    }
}
function Get-Sha([string]$Path) {
    $algorithm = [Security.Cryptography.SHA256]::Create()
    $stream = [IO.File]::OpenRead($Path)
    try { return ([BitConverter]::ToString($algorithm.ComputeHash($stream))).Replace('-', '').ToLowerInvariant() }
    finally { $stream.Dispose(); $algorithm.Dispose() }
}
function Get-PlainFiles([string]$Directory) {
    Assert-PlainPath $Directory
    foreach ($item in Get-ChildItem -LiteralPath $Directory -Force) {
        Assert-PlainPath $item.FullName
        if ($item.PSIsContainer) { Get-PlainFiles $item.FullName } else { $item }
    }
}
function Assert-Snapshot([string]$Directory, $Records) {
    if (-not (Test-Path -LiteralPath $Directory -PathType Container)) { throw "Documentation directory is missing: $Directory" }
    $actual = @(Get-PlainFiles $Directory)
    if ($actual.Count -ne $Records.Count) { throw "Documentation differs from the bundled snapshot: $Directory. Existing content was preserved." }
    foreach ($record in $Records) {
        $path = Join-Path $Directory $record.path
        Assert-PlainPath $path
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or (Get-Sha $path) -cne $record.sha256) {
            throw "Documentation file is missing or changed: $path. Existing content was preserved."
        }
    }
}

try {
    Write-Host 'Geurts StandardsOnly Installer 1.0.0' -ForegroundColor Green
    Write-Host "Bundled documentation: $documentationVersion (offline installation)"
    if ([string]::IsNullOrWhiteSpace($ProjectRoot)) {
        if ($ConfirmInstall) { throw 'Supply -ProjectRoot when using -ConfirmInstall.' }
        Add-Type -AssemblyName System.Windows.Forms
        $picker = New-Object Windows.Forms.FolderBrowserDialog
        $picker.Description = 'Select the existing Unity project folder containing Assets, Packages and ProjectSettings.'
        $picker.ShowNewFolderButton = $false
        try {
            if ($picker.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { Write-Host 'Cancelled. No project files changed.'; exit 0 }
            $ProjectRoot = $picker.SelectedPath
        } finally { $picker.Dispose() }
    }
    $ProjectRoot = [IO.Path]::GetFullPath($ProjectRoot)
    Assert-PlainPath $ProjectRoot
    foreach ($folder in @('Assets', 'Packages', 'ProjectSettings')) {
        $path = Join-Path $ProjectRoot $folder
        Assert-PlainPath $path
        if (-not (Test-Path -LiteralPath $path -PathType Container)) { throw "Select the Unity project root. Required folder is missing: $path" }
    }
    $payload = Join-Path $PSScriptRoot 'Documentation'
    $inventoryPath = Join-Path $PSScriptRoot 'Snapshot.json'
    Assert-PlainPath $inventoryPath
    $inventory = [IO.File]::ReadAllText($inventoryPath) | ConvertFrom-Json
    if ($inventory.commit -cne $sourceCommit -or $inventory.documentationVersion -cne $documentationVersion) { throw 'The bundled snapshot metadata is incompatible with this installer.' }
    $records = @($inventory.files)
    if ($records.Count -lt 3) { throw 'Incomplete snapshot inventory.' }
    $seen = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
    foreach ($record in $records) {
        if ($record.path -notmatch '^[A-Za-z0-9_.-]+(/[A-Za-z0-9_.-]+)*$' -or @($record.path.Split('/') | Where-Object { $_ -eq '.' -or $_ -eq '..' }).Count -gt 0 -or -not $seen.Add($record.path) -or $record.sha256 -notmatch '^[0-9a-f]{64}$') { throw 'Invalid or duplicate snapshot path/hash.' }
    }
    foreach ($required in @('AI_READ_FIRST.md', 'GeurtsTechniqueManifest.md', 'GeurtsTechniques/GeurtsStandardsOnlyTechnique.md')) {
        if (-not $seen.Contains($required)) { throw "Snapshot omits $required" }
    }
    Assert-Snapshot $payload $records
    $destination = Join-Path $ProjectRoot 'GeurtsGameForgeCommandments'
    $guide = Join-Path $ProjectRoot 'AGENTS.md'
    Assert-PlainPath $destination
    Assert-PlainPath $guide
    if (Test-Path -LiteralPath (Join-Path $ProjectRoot 'AGENTS.override.md')) { throw 'AGENTS.override.md exists and may override routing. Reconcile that guide before installing; no project files changed.' }
    $existingDocumentation = Test-Path -LiteralPath $destination
    if ($existingDocumentation) { Assert-Snapshot $destination $records }
    $begin = '<!-- GEURTS-STANDARDS-ONLY:BEGIN 1.0.0 -->'
    $end = '<!-- GEURTS-STANDARDS-ONLY:END -->'
    $block = @'
<!-- GEURTS-STANDARDS-ONLY:BEGIN 1.0.0 -->
## Geurts development standards

Use GeurtsGameForge_Commandments in the StandardsOnly profile.
Before planning or modifying project work, read ./GeurtsGameForgeCommandments/AI_READ_FIRST.md relative to this AGENTS.md, then its sibling manifest and every technique selected for the task from that same documentation copy. If the entry is missing, report it before making changes.
Documentation version: 0.61.1. Source commit: 6f1454494e5f773633c2107154d3527fae9e8b15.
GameForge, Steam, Odin Inspector and Quantum Console are optional under this profile. Do not install or remove dependencies merely to adopt these standards.
Apply the standards to new and modified work. Preserve existing assets, references, behaviour and user instructions. Propose broader migrations before making them. Surface conflicting project instructions rather than silently overriding them.
Keep project-specific game design separate and access it only when the manifest and the user's task select it. Do not treat generic documentation as game-design authority.
<!-- GEURTS-STANDARDS-ONLY:END -->
'@
    $block = ($block -replace '\r?\n', "`r`n") + "`r`n"
    $guideExists = Test-Path -LiteralPath $guide
    $guideHash = $null
    $guideBytes = [byte[]]@()
    $guideText = ''
    if ($guideExists) {
        if (-not (Test-Path -LiteralPath $guide -PathType Leaf)) { throw 'AGENTS.md is a directory.' }
        if ((Get-Item -LiteralPath $guide).Length -gt 1MB) { throw 'AGENTS.md exceeds the supported 1 MiB size.' }
        $guideHash = Get-Sha $guide
        $guideBytes = [IO.File]::ReadAllBytes($guide)
        $guideText = $utf8.GetString($guideBytes)
        if ($guideText.Contains([char]0)) { throw 'AGENTS.md must be valid UTF-8 text; its current encoding is preserved.' }
    }
    $guideReady = $false
    if ($guideText.Contains('GEURTS-STANDARDS-ONLY:')) {
        $guideReady = ([regex]::Matches($guideText, 'GEURTS-STANDARDS-ONLY:BEGIN').Count -eq 1 -and [regex]::Matches($guideText, 'GEURTS-STANDARDS-ONLY:END').Count -eq 1 -and $guideText.Contains($block))
        if (-not $guideReady) { throw 'The existing StandardsOnly block was modified or uses another version. Reconcile it manually; it was preserved.' }
    } elseif ($guideText -match '(?i)GEURTS-MANAGED-OPT-OUT|GEURTS-CODEX|GeurtsGameForge|Geurts Game Forge') {
        throw 'AGENTS.md already contains another Geurts route or an opt-out. Reconcile it before installing; it was preserved.'
    }
    $suffix = if ($guideBytes.Length) { "`r`n`r`n" + $block } else { $block }
    $newGuideBytes = [byte[]]($guideBytes + $utf8.GetBytes($suffix))
    $token = [Guid]::NewGuid().ToString('N').Substring(0, 12)
    $staging = Join-Path $ProjectRoot ('.StandardsInstall-' + $token)
    $guideTemporary = Join-Path $ProjectRoot ('.StandardsGuide-' + $token + '.tmp')
    $backup = Join-Path $ProjectRoot ('AGENTS.md.before-standards-' + $token + '.bak')
    foreach ($path in @($staging, $guideTemporary, $backup)) { Assert-PlainPath $path; if (Test-Path -LiteralPath $path) { throw "Temporary path already exists: $path" } }
    foreach ($record in $records) { Assert-PlainPath (Join-Path $destination $record.path); Assert-PlainPath (Join-Path $staging $record.path) }
    Write-Host "Project: $ProjectRoot"
    Write-Host "Documentation: $destination"
    Write-Host "Instructions: $guide (existing text preserved; backup created if changed)"
    Write-Host 'No packages, assets, scenes, game-design documents or project settings will be changed.'
    if (-not $ConfirmInstall) {
        $answer = Read-Host 'Install StandardsOnly here? Type INSTALL to continue; Enter cancels'
        if ($answer -cne 'INSTALL') { Write-Host 'Cancelled. No project files changed.'; exit 0 }
    }
    Assert-PlainPath $ProjectRoot
    Assert-PlainPath $destination
    Assert-PlainPath $guide
    if ($guideExists) { if (-not (Test-Path -LiteralPath $guide -PathType Leaf) -or (Get-Sha $guide) -cne $guideHash) { throw 'AGENTS.md changed during review. Retry after reviewing its changes.' } }
    elseif (Test-Path -LiteralPath $guide) { throw 'AGENTS.md appeared during review. Retry.' }
    if ($existingDocumentation) { Assert-Snapshot $destination $records }
    else {
        if (Test-Path -LiteralPath $destination) { throw 'The documentation destination appeared during review. Retry.' }
        Assert-PlainPath $staging
        [void][IO.Directory]::CreateDirectory($staging)
        foreach ($record in $records) {
            $target = Join-Path $staging $record.path
            $source = Join-Path $payload $record.path
            Assert-PlainPath $source
            Assert-PlainPath $target
            [void][IO.Directory]::CreateDirectory([IO.Path]::GetDirectoryName($target))
            [IO.File]::Copy($source, $target, $false)
        }
        Assert-Snapshot $staging $records
        Assert-PlainPath $destination
        [IO.Directory]::Move($staging, $destination)
        $staging = $null
    }
    if (-not $guideReady) {
        Assert-PlainPath $guideTemporary
        $stream = [IO.File]::Open($guideTemporary, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write, [IO.FileShare]::None)
        try { $stream.Write($newGuideBytes, 0, $newGuideBytes.Length) } finally { $stream.Dispose() }
        Assert-PlainPath $guide
        Assert-PlainPath $guideTemporary
        Assert-PlainPath $backup
        if ($guideExists) {
            if ((Get-Sha $guide) -cne $guideHash -or (Test-Path -LiteralPath $backup)) { throw 'The guide or backup destination changed before installation. Existing content was preserved.' }
            [IO.File]::Replace($guideTemporary, $guide, $backup)
            Write-Host "Original guide backup: $backup"
        } else { [IO.File]::Move($guideTemporary, $guide) }
        if ([Convert]::ToBase64String([IO.File]::ReadAllBytes($guide)) -cne [Convert]::ToBase64String($newGuideBytes)) { throw 'Final guide verification failed. Review AGENTS.md and its backup.' }
    }
    Assert-Snapshot $destination $records
    Write-Host ''
    Write-Host 'StandardsOnly installed and verified.' -ForegroundColor Green
    Write-Host 'Open a new coding-agent session in this project. Ask it to read AGENTS.md and audit against StandardsOnly.'
    Write-Host 'Tools that do not read AGENTS.md need the documentation entry path supplied explicitly.'
    exit 0
} catch {
    Write-Host ("Installation stopped: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Existing documentation is never replaced. If documentation was copied before a later failure, it remains available; resolve the reported issue and rerun.'
    if ($staging -and (Test-Path -LiteralPath $staging)) { Write-Host "Incomplete staging folder retained for inspection: $staging" }
    exit 1
}
