Geurts StandardsOnly Installer 1.0.0
Bundled documentation: 0.61.1
Source: https://github.com/Geurtsy/GeurtsGameForge_Commandments/tree/6f1454494e5f773633c2107154d3527fae9e8b15

1. Extract the complete ZIP into a short folder such as C:\Tools\Standards.
2. Double-click InstallStandardsOnly.bat.
3. Select your Unity project ROOT: the folder containing Assets, Packages and ProjectSettings.
4. Review the destination and type INSTALL.
5. Start a new coding-agent session in that project and ask it to read AGENTS.md.

Keep all extracted files together. No administrator rights, internet, Git, GameForge,
Steam, Odin Inspector or Quantum Console are required. Windows PowerShell 5.1 is used.
You can also drag your Unity project folder onto the batch file.

The installer copies the complete pinned snapshot to GeurtsGameForgeCommandments
and appends a StandardsOnly routing block to the project-root AGENTS.md. Existing
UTF-8 instructions are preserved byte-for-byte and backed up before modification.
Review existing instructions for semantic conflicts; the installer cannot judge prose.
Existing Geurts routes/opt-outs and AGENTS.override.md require manual reconciliation.
Other agent tools may need the entry path supplied explicitly. Nested instructions
can still apply. No automatic project audit or asset migration is performed.

Re-running with the identical snapshot and unchanged routing block is idempotent.
A different or edited documentation copy is preserved and causes installation to stop.
This is an initial installer, not an updater. Future updates require a separately
reviewed snapshot and reconciliation of the existing copy.

Assets, Packages, ProjectSettings, scene files, game-design documents, Copilot routes,
Git settings and dependencies are not modified. No broad folder setup is performed.
The folder picker and confirmation are interactive; the installation engine can also
be invoked directly with -ProjectRoot and -ConfirmInstall for deliberate automation.
No machine-wide execution-policy setting is changed.

Recovery: a completed documentation copy may remain if guide installation fails.
Resolve the reported conflict and rerun. An incomplete .StandardsInstall-* directory
is reported and retained for inspection. Existing files are never recursively deleted.
To undo: remove only the GEURTS-STANDARDS-ONLY block from AGENTS.md (or restore its
backup if no later edits need preserving), then remove the installed documentation
folder only after checking that it contains no changes you need.

Snapshot.json records SHA-256 hashes to detect accidental payload changes. It is
not a digital signature. Documentation follows its original repository provenance.

Verification: 12 installation-engine checks passed on Windows PowerShell 5.1,
including preservation, idempotence and conflict rejection. Cancellation was also
verified to leave the project unchanged. The graphical folder picker was not
interactively tested; linked-path checks are implemented but junction fixtures
were unavailable in the test environment.

The batch launcher also passed an end-to-end install using a project path with spaces.
